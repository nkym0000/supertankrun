class_name GameUI
extends CanvasLayer
## 全部界面（代码构建）：标题、HUD、车库、结算、暂停。通过信号与 main.gd 通信。
## 风格：N64 / 90s-00s 主机——圆润粗体字 + 粗黑描边、光泽九宫格按钮、分段仪表。

signal clicked
signal play_pressed
signal classic_pressed
signal garlic_pressed
signal battle_pressed
signal garage_pressed
signal title_pressed
signal retry_pressed
signal resume_pressed
signal skin_preview(id: String)
signal skin_buy(id: String)
signal skin_equip(id: String)
signal upgrade_buy(id: String)

const C_YELLOW := Color("#ffe03a")
const C_ORANGE := Color("#ff8a1f")
const C_RED := Color("#ee3a3a")
const C_CYAN := Color("#46e6ff")
const C_GREEN := Color("#5be86a")
const C_BLUE := Color("#3a86f0")
const C_PURPLE := Color("#8a5be8")


## 分段仪表（Mario 64 血量条风格）
class SegBar extends Control:
	var value := 1.0
	var color := Color("#46e6ff")
	var segs := 14

	func set_value(v: float) -> void:
		if absf(v - value) > 0.001:
			value = v
			queue_redraw()

	func _draw() -> void:
		var w := size.x
		var h := size.y
		draw_rect(Rect2(-4, -4, w + 8, h + 8), Color(0.02, 0.02, 0.06, 0.95))
		var gap := 3.0
		var sw := (w - gap * (segs - 1)) / segs
		for i in segs:
			var x := i * (sw + gap)
			var on := (float(i) + 0.5) / segs <= value
			var c := color.lerp(Color.WHITE, float(i) / segs * 0.45) if on else Color(0.2, 0.22, 0.3, 0.9)
			draw_rect(Rect2(x, 0, sw, h), c)
			if on:
				draw_rect(Rect2(x, 0, sw, h * 0.35), Color(1, 1, 1, 0.35))


## 炮弹格：满格是金色炮弹，正在装填的那一格按进度填充
class AmmoBar extends Control:
	var count := 3
	var total := 3
	var frac := 0.0

	func set_ammo(c: int, t: int, f: float) -> void:
		if c != count or t != total or absf(f - frac) > 0.02:
			count = c
			total = t
			frac = f
			queue_redraw()

	func _draw() -> void:
		var w := 20.0
		var gap := 6.0
		var h := size.y
		for i in total:
			var x := float(i) * (w + gap)
			draw_rect(Rect2(x - 3, -3, w + 6, h + 6), Color(0.02, 0.02, 0.06, 0.95))
			if i < count:
				draw_rect(Rect2(x, h * 0.28, w, h * 0.72), Color("#e8c23a"))
				draw_rect(Rect2(x, 0, w, h * 0.3), Color("#c2922a")) # 弹头
				draw_rect(Rect2(x, h * 0.28, w * 0.35, h * 0.72), Color(1, 1, 1, 0.3))
			elif i == count and frac > 0.0:
				var fh := h * frac
				draw_rect(Rect2(x, h - fh, w, fh), Color(0.55, 0.45, 0.14, 0.9))
			else:
				draw_rect(Rect2(x, 0, w, h), Color(0.2, 0.22, 0.3, 0.9))


## 大蒜模式的失误格：剩余的画成蒜头，用掉的打红叉
class StrikeBar extends Control:
	var used := 0
	var total := 3

	func set_strikes(u: int, t: int) -> void:
		if u != used or t != total:
			used = u
			total = t
			queue_redraw()

	func _draw() -> void:
		var step := 40.0
		var x0 := size.x - float(total) * step + 20.0
		for i in total:
			var c := Vector2(x0 + float(i) * step, 24.0)
			var alive := i >= used
			draw_circle(c, 15.0, Color(0.03, 0.03, 0.08, 0.92))
			draw_circle(c, 12.5, Color("#ece2ea") if alive else Color(0.26, 0.28, 0.33))
			# 蒜瓣分界 + 蒜梗（配色对上场上的紫皮蒜）
			var line_c := Color("#8e5a88") if alive else Color(0.2, 0.22, 0.26)
			draw_line(c + Vector2(0, -10), c + Vector2(0, 10), line_c, 2.0)
			draw_line(c + Vector2(-7, -8), c + Vector2(-7, 8), line_c, 1.5)
			draw_line(c + Vector2(7, -8), c + Vector2(7, 8), line_c, 1.5)
			draw_line(c + Vector2(0, -12), c + Vector2(0, -21),
				Color("#9fae5e") if alive else Color(0.22, 0.24, 0.28), 5.0)
			if not alive:
				draw_line(c + Vector2(-11, -11), c + Vector2(11, 11), Color("#ff4a3a"), 4.5)
				draw_line(c + Vector2(11, -11), c + Vector2(-11, 11), Color("#ff4a3a"), 4.5)


## 敌方坦克头顶的血条。一个 Control 一次性画完所有，不为每辆车建节点。
class EnemyBars extends Control:
	var bars: Array = [] # [[screen_pos: Vector2, frac: float, tint: Color], ...]

	func set_bars(b: Array) -> void:
		bars = b
		queue_redraw()

	func _draw() -> void:
		for e in bars:
			var ev: Array = e
			var p: Vector2 = ev[0]
			var frac: float = clampf(float(ev[1]), 0.0, 1.0)
			var tint: Color = ev[2]
			var w := 74.0
			var h := 11.0
			var r := Rect2(p.x - w * 0.5, p.y - h * 0.5, w, h)
			draw_rect(r.grow(3.0), Color(0.02, 0.02, 0.06, 0.92))
			draw_rect(Rect2(r.position, Vector2(w, h)), Color(0.22, 0.09, 0.09, 0.95))
			var c := Color("#4ce05a") if frac > 0.55 else (Color("#ffc12a") if frac > 0.25 else Color("#ff4a3a"))
			draw_rect(Rect2(r.position, Vector2(w * frac, h)), c)
			draw_rect(Rect2(r.position, Vector2(w * frac, h * 0.4)), Color(1, 1, 1, 0.28))
			# 左侧一小块涂装色，方便分辨是哪辆车
			draw_rect(Rect2(r.position + Vector2(-11, 0), Vector2(8, h)), Color(0.02, 0.02, 0.06, 0.92))
			draw_rect(Rect2(r.position + Vector2(-10, 1), Vector2(6, h - 2)), tint)


## 准星：画在炮口指向的位置
class Reticle extends Control:
	var col := Color("#ff5f4a")
	var hot := true

	func _draw() -> void:
		var c := col if hot else Color(0.6, 0.62, 0.68)
		var o := Color(0.03, 0.03, 0.08)
		var r := 15.0
		var th := 4.0
		for d in [Vector2(1, 0), Vector2(-1, 0), Vector2(0, 1), Vector2(0, -1)]:
			var dv: Vector2 = d
			var a := dv * r
			var b := dv * (r + 11.0)
			draw_line(a, b, o, th + 3.0)
			draw_line(a, b, c, th)
		draw_circle(Vector2.ZERO, 3.0, o)
		draw_circle(Vector2.ZERO, 1.8, c)


var font: Font
var sys_font: SystemFont
var title_screen: Control
var garage_screen: Control
var hud: Control
var results_screen: Control
var pause_screen: Control
var floats: Control
var msg_lbl: Label
var fade: ColorRect

var score_lbl: Label
var time_lbl: Label
var best_lbl: Label
var combo_lbl: Label
var combo_box: Control
var combo_bar: SegBar
var boost_bar: SegBar
var ammo_bar: AmmoBar
var ammo_lbl: Label
var reticle: Reticle
var strike_bar: StrikeBar
var strike_lbl: Label
var flash_rect: ColorRect
var enemy_bars: EnemyBars
var hp_box: Control
var hp_bar: SegBar
var hp_lbl: Label
var kills_lbl: Label

var garage_coins: Label
var list_box: VBoxContainer
var tab_btns: Array = []
var title_info: Label
var res_title: Label
var res_body: Label
var res_record: Label

var tab := 0
var preview_id := ""
var _shown_score := 0.0
var _target_score := 0
var _combo_last := 0
var _box_cache: Dictionary = {}


func _init() -> void:
	layer = 10


func _ready() -> void:
	sys_font = SystemFont.new()
	sys_font.font_names = PackedStringArray(["PingFang SC", "Microsoft YaHei", "Noto Sans CJK SC", "Arial Rounded MT Bold", "Arial Black"])
	sys_font.font_weight = 900
	var ff: Font = load("res://assets/fonts/LuckiestGuy.woff")
	if ff != null:
		ff.fallbacks = [sys_font]
		font = ff
	else:
		font = sys_font
	floats = Control.new()
	floats.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_full(floats)
	add_child(floats)
	_build_title()
	_build_hud()
	_build_garage()
	_build_results()
	_build_pause()
	msg_lbl = _lbl("", 130, C_YELLOW, 18)
	_full(msg_lbl)
	msg_lbl.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	msg_lbl.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	msg_lbl.mouse_filter = Control.MOUSE_FILTER_IGNORE
	msg_lbl.pivot_offset = Vector2(640, 360)
	add_child(msg_lbl)
	flash_rect = ColorRect.new()
	flash_rect.color = Color(1, 1, 1, 0)
	flash_rect.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_full(flash_rect)
	add_child(flash_rect)
	fade = ColorRect.new()
	fade.color = Color(0, 0, 0, 0)
	fade.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_full(fade)
	add_child(fade)
	show_screen("title")


func _process(delta: float) -> void:
	if hud.visible:
		_shown_score = move_toward(_shown_score, float(_target_score), maxf(300.0, absf(_target_score - _shown_score) * 6.0) * delta)
		score_lbl.text = _fmt(int(_shown_score))


# ---------- 公共接口 ----------
func fade_to(cb: Callable, dur: float = 0.2) -> void:
	fade.mouse_filter = Control.MOUSE_FILTER_STOP
	var tw := create_tween()
	tw.tween_property(fade, "color:a", 1.0, dur)
	tw.tween_callback(cb)
	tw.tween_property(fade, "color:a", 0.0, dur)
	tw.tween_callback(func(): fade.mouse_filter = Control.MOUSE_FILTER_IGNORE)


func show_screen(which: String) -> void:
	title_screen.visible = which == "title"
	garage_screen.visible = which == "garage"
	hud.visible = which in ["hud", "pause"]
	results_screen.visible = which == "results"
	pause_screen.visible = which == "pause"
	if which != "hud" and which != "pause":
		msg_lbl.text = ""
	if reticle != null and which != "hud":
		reticle.visible = false
	if which == "title":
		title_info.text = "BEST  %s     ◎ %s" % [_fmt(SaveGame.best), _fmt(SaveGame.coins)]


func set_message(text: String, size: int = 130, color: Color = C_YELLOW) -> void:
	msg_lbl.text = text
	msg_lbl.add_theme_font_size_override("font_size", size)
	msg_lbl.add_theme_color_override("font_color", color)
	if text != "":
		msg_lbl.scale = Vector2(1.8, 1.8)
		var tw := msg_lbl.create_tween()
		tw.tween_property(msg_lbl, "scale", Vector2.ONE, 0.25).set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)


func reset_hud() -> void:
	_shown_score = 0.0
	_target_score = 0
	_combo_last = 0


func set_hud(score: int, time_left: float, combo: int, mult: int, combo_frac: float, boost_frac: float) -> void:
	_target_score = score
	time_lbl.text = str(ceili(time_left))
	var low := time_left <= 10.0
	time_lbl.add_theme_color_override("font_color", Color("#ff5050") if (low and int(time_left * 3.0) % 2 == 0) else Color.WHITE)
	best_lbl.text = "BEST  " + _fmt(maxi(SaveGame.best, score))
	combo_box.visible = combo > 0
	if combo > 0:
		combo_lbl.text = "COMBO ×%d" % mult
		var tint := C_YELLOW
		if mult >= 6:
			tint = Color("#ff5fe0")
		elif mult >= 3:
			tint = C_ORANGE
		combo_lbl.add_theme_color_override("font_color", tint)
		combo_bar.color = tint
		combo_bar.set_value(combo_frac)
		if combo != _combo_last:
			combo_lbl.pivot_offset = Vector2(combo_lbl.size.x * 0.5, combo_lbl.size.y * 0.5)
			combo_lbl.scale = Vector2(1.3, 1.3)
			var tw := combo_lbl.create_tween()
			tw.tween_property(combo_lbl, "scale", Vector2.ONE, 0.16).set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)
	_combo_last = combo
	boost_bar.set_value(boost_frac)


func set_ammo(cur: int, total: int, reload_frac: float) -> void:
	ammo_bar.set_ammo(cur, total, reload_frac)
	ammo_bar.custom_minimum_size.x = float(total) * 26.0
	ammo_lbl.add_theme_color_override("font_color", C_YELLOW if cur > 0 else Color("#ff6a5a"))


func set_strikes(used: int, total: int, show_it: bool) -> void:
	strike_bar.visible = show_it
	strike_lbl.visible = show_it
	if show_it:
		strike_bar.set_strikes(used, total)


func set_battle(on: bool, hp_frac: float, kills: int, alive: int, bars: Array) -> void:
	if not on:
		if hp_box.visible:
			hp_box.visible = false
			enemy_bars.visible = false
			combo_box.visible = false
		return
	hp_box.visible = true
	enemy_bars.visible = true
	combo_box.visible = false
	hp_bar.color = Color("#4ce05a") if hp_frac > 0.55 else (Color("#ffc12a") if hp_frac > 0.25 else Color("#ff4a3a"))
	hp_bar.set_value(hp_frac)
	hp_lbl.add_theme_color_override("font_color", Color("#ff6a5a") if hp_frac <= 0.25 else Color("#ff8a7a"))
	kills_lbl.text = "击毁 %d    剩余 %d" % [kills, alive]
	enemy_bars.set_bars(bars)


## 全屏闪一下（踩到大蒜）
func flash(col: Color) -> void:
	flash_rect.color = col
	var tw := create_tween()
	tw.tween_property(flash_rect, "color:a", 0.0, 0.38).set_trans(Tween.TRANS_SINE)


func set_reticle(pos: Vector2, show_it: bool) -> void:
	reticle.visible = show_it
	if show_it:
		reticle.position = pos
		reticle.hot = true
		reticle.queue_redraw()


func add_float(text: String, pos: Vector2, color: Color, size: int = 40) -> void:
	if floats.get_child_count() > 22:
		floats.get_child(0).queue_free()
	var l := _lbl(text, size, color, 12)
	l.custom_minimum_size = Vector2(300, 0)
	l.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	l.position = pos - Vector2(150, 34)
	l.pivot_offset = Vector2(150, 34)
	l.mouse_filter = Control.MOUSE_FILTER_IGNORE
	l.scale = Vector2(0.4, 0.4)
	floats.add_child(l)
	var tw := l.create_tween()
	tw.tween_property(l, "scale", Vector2(1.25, 1.25), 0.1)
	tw.tween_property(l, "scale", Vector2.ONE, 0.08)
	tw.set_parallel(true)
	tw.tween_property(l, "position:y", l.position.y - 80.0, 0.8).set_ease(Tween.EASE_OUT)
	tw.tween_property(l, "modulate:a", 0.0, 0.3).set_delay(0.55)
	tw.chain().tween_callback(l.queue_free)


func show_results(d: Dictionary) -> void:
	show_screen("results")
	var garlic := bool(d.get("garlic", false))
	var battle := bool(d.get("battle", false))
	res_title.text = "BATTLE RESULTS" if battle else ("GARLIC RESULTS" if garlic else "RESULTS")
	var lines: Array = []
	if battle:
		if bool(d.get("won", false)):
			lines.append("最后的幸存者！  +%s" % _fmt(GameData.BATTLE_WIN_BONUS))
		elif not bool(d.get("survived", true)):
			lines.append("你被击毁了")
		else:
			lines.append("时间到")
		lines.append("击毁坦克 %d 辆" % int(d.get("kills", 0)))
	if garlic:
		var st := int(d["strikes"])
		if bool(d.get("perfect", false)):
			lines.append("完美通过！ 零大蒜  +%s" % _fmt(GameData.GARLIC_PERFECT_BONUS))
		else:
			lines.append("压到大蒜 %d / %d" % [st, GameData.GARLIC_STRIKES])
	lines.append("SCORE   %s" % _fmt(int(d["score"])))
	lines.append("BEST    %s" % _fmt(int(d["best"])))
	if not battle:
		lines.append("压扁 %d      最大连击 %d" % [int(d["squashed"]), int(d["max_combo"])])
		var by: Dictionary = d["by_kind"]
		var parts: Array = []
		for k in by.keys():
			var info: Dictionary = GameData.FRUITS[k]
			parts.append("%s×%d" % [info["name"], int(by[k])])
		if parts.size() > 0:
			lines.append("  ".join(parts))
	lines.append("")
	lines.append("COINS  +%s" % _fmt(int(d["coins"])))
	res_body.text = "\n".join(lines)
	res_record.visible = bool(d["record"])


# ---------- 构建工具 ----------
func _fmt(n: int) -> String:
	var s := str(absi(n))
	var out := ""
	var cnt := 0
	for i in range(s.length() - 1, -1, -1):
		out = s[i] + out
		cnt += 1
		if cnt % 3 == 0 and i > 0:
			out = "," + out
	return ("-" if n < 0 else "") + out


func _lbl(text: String, size: int, color: Color, outline: int = 8,
		outline_col: Color = Color(0.03, 0.03, 0.1)) -> Label:
	var l := Label.new()
	l.text = text
	l.add_theme_font_override("font", font)
	l.add_theme_font_size_override("font_size", size)
	l.add_theme_color_override("font_color", color)
	l.add_theme_color_override("font_outline_color", outline_col)
	l.add_theme_constant_override("outline_size", outline)
	l.add_theme_color_override("font_shadow_color", Color(0, 0, 0, 0.45))
	l.add_theme_constant_override("shadow_offset_x", 0)
	l.add_theme_constant_override("shadow_offset_y", maxi(2, size / 18))
	return l


func _tex_box(t: Texture2D, margin: int = 20, content: int = 14) -> StyleBoxTexture:
	var s := StyleBoxTexture.new()
	s.texture = t
	s.texture_margin_left = margin
	s.texture_margin_right = margin
	s.texture_margin_top = margin
	s.texture_margin_bottom = margin
	s.content_margin_left = content + 4
	s.content_margin_right = content + 4
	s.content_margin_top = content - 2
	s.content_margin_bottom = content - 2
	return s


func _btn_box(c: Color) -> StyleBoxTexture:
	var key := "b" + c.to_html()
	if not _box_cache.has(key):
		_box_cache[key] = _tex_box(Tex.ui_button_image(c), 20, 12)
	return _box_cache[key]


func _btn(text: String, size: int = 30, accent: Color = C_ORANGE) -> Button:
	var b := Button.new()
	b.text = text
	b.focus_mode = Control.FOCUS_NONE
	b.add_theme_font_override("font", font)
	b.add_theme_font_size_override("font_size", size)
	b.add_theme_color_override("font_color", Color.WHITE)
	b.add_theme_color_override("font_hover_color", Color("#fffbd0"))
	b.add_theme_color_override("font_pressed_color", Color("#dddddd"))
	b.add_theme_color_override("font_disabled_color", Color(1, 1, 1, 0.5))
	b.add_theme_color_override("font_outline_color", Color(0.03, 0.03, 0.1))
	b.add_theme_constant_override("outline_size", 8)
	b.add_theme_stylebox_override("normal", _btn_box(accent))
	b.add_theme_stylebox_override("hover", _btn_box(accent.lightened(0.18)))
	b.add_theme_stylebox_override("pressed", _btn_box(accent.darkened(0.25)))
	b.add_theme_stylebox_override("disabled", _btn_box(Color("#6b7080")))
	b.pressed.connect(func(): clicked.emit())
	return b


func _panel_box(top: Color = Color("#2347a8"), bottom: Color = Color("#10206a")) -> StyleBoxTexture:
	var key := "p" + top.to_html() + bottom.to_html()
	if not _box_cache.has(key):
		_box_cache[key] = _tex_box(Tex.ui_panel_image(top, bottom, Color("#a9c8ff")), 20, 16)
	return _box_cache[key]


func _panel(minimum: Vector2 = Vector2.ZERO) -> PanelContainer:
	var p := PanelContainer.new()
	p.add_theme_stylebox_override("panel", _panel_box())
	p.custom_minimum_size = minimum
	return p


func _full(c: Control) -> void:
	c.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)


## N64 主机时代的标题字：每个字母一种原色字面 + 金色倒角 + 厚挤出侧面 + 轻微歪斜。
## 改标题只要换 _build_title 里传给 _logo3d 的字符串。
const LOGO_COLS: Array = [
	Color("#e5342a"), Color("#2f6fd0"), Color("#30a24b"), Color("#f2c21a"), Color("#ef7a18"), Color("#8a4fd0")]
const LOGO_GOLD := Color("#ffd957")
const LOGO_GOLD_DK := Color("#a8760f")


func _char3d(ch: String, size: int, face: Color, depth: int, tilt: float, dy: float) -> Control:
	var holder := Control.new()
	var w := font.get_string_size(ch, HORIZONTAL_ALIGNMENT_LEFT, -1, size).x
	holder.custom_minimum_size = Vector2(w, size * 1.35)
	holder.mouse_filter = Control.MOUSE_FILTER_IGNORE
	var inner := Control.new()
	inner.mouse_filter = Control.MOUSE_FILTER_IGNORE
	inner.position = Vector2(0, dy)
	inner.pivot_offset = Vector2(w * 0.5, size * 0.6)
	inner.rotation = deg_to_rad(tilt)
	holder.add_child(inner)
	# 挤出的金色侧面：从深到浅叠出厚度
	for d in range(depth, 0, -1):
		var t := float(d) / float(depth)
		var side := LOGO_GOLD_DK.darkened(0.45 * t)
		inner.add_child(_set_pos(_lbl(ch, size, side, 15, side.darkened(0.45)), Vector2(d * 0.85, d * 1.15)))
	# 金色倒角（比字面胖一圈）
	inner.add_child(_lbl(ch, size, LOGO_GOLD, 17, LOGO_GOLD_DK))
	# 彩色字面
	inner.add_child(_lbl(ch, size, face, 4, Color("#6b4406")))
	return holder


func _set_pos(c: Control, p: Vector2) -> Control:
	c.position = p
	return c


func _logo3d(text: String, size: int, start_idx: int) -> Control:
	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", -maxi(2, size / 13))
	row.mouse_filter = Control.MOUSE_FILTER_IGNORE
	var depth := maxi(7, size / 7)
	var i := 0
	for ch in text:
		if ch == " ":
			var sp := Control.new()
			sp.custom_minimum_size = Vector2(size * 0.28, 1)
			sp.mouse_filter = Control.MOUSE_FILTER_IGNORE
			row.add_child(sp)
			i += 1
			continue
		var face: Color = LOGO_COLS[(start_idx + i) % LOGO_COLS.size()]
		var tilt := -4.5 + float((i * 37) % 10)
		var dy := (float((i * 53) % 5) - 2.0) * size * 0.012
		row.add_child(_char3d(ch, size, face, depth, tilt, dy))
		i += 1
	return row


# ---------- 标题 ----------
func _build_title() -> void:
	title_screen = Control.new()
	_full(title_screen)
	add_child(title_screen)
	var margin := MarginContainer.new()
	_full(margin)
	for s in ["left", "top", "bottom"]:
		margin.add_theme_constant_override("margin_" + s, 30)
	margin.add_theme_constant_override("margin_right", 640)
	title_screen.add_child(margin)
	var vb := VBoxContainer.new()
	vb.add_theme_constant_override("separation", 0)
	margin.add_child(vb)
	var logo := VBoxContainer.new()
	logo.add_theme_constant_override("separation", -14)
	logo.rotation = deg_to_rad(-3.0)
	logo.pivot_offset = Vector2(280, 150)
	vb.add_child(logo)
	var l1 := _logo3d("SUPER", 72, 0)
	var l2 := _logo3d("TANK RUN", 82, 2)
	var c1 := CenterContainer.new()
	c1.add_child(l1)
	var c2 := CenterContainer.new()
	c2.add_child(l2)
	logo.add_child(c1)
	logo.add_child(c2)
	var tw := logo.create_tween().set_loops()
	tw.tween_property(logo, "rotation", deg_to_rad(-1.5), 1.1).set_trans(Tween.TRANS_SINE)
	tw.tween_property(logo, "rotation", deg_to_rad(-4.0), 1.1).set_trans(Tween.TRANS_SINE)
	var rib := PanelContainer.new()
	var rb := _tex_box(Tex.ui_button_image(C_RED), 20, 6)
	rib.add_theme_stylebox_override("panel", rb)
	var rl := _lbl("★ 水果大碾压 ★", 34, Color.WHITE, 8)
	rl.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	rib.add_child(rl)
	var rc := CenterContainer.new()
	rc.add_child(rib)
	vb.add_child(rc)
	var sp := Control.new()
	sp.size_flags_vertical = Control.SIZE_EXPAND_FILL
	vb.add_child(sp)
	var bb := VBoxContainer.new()
	bb.add_theme_constant_override("separation", 12)
	vb.add_child(bb)
	var b1 := _btn("▶  开始游戏", 40, C_ORANGE)
	b1.custom_minimum_size = Vector2(420, 62)
	b1.pressed.connect(func(): classic_pressed.emit())
	var bg := _btn("大蒜模式  GARLIC", 31, C_GREEN)
	bg.custom_minimum_size = Vector2(420, 52)
	bg.pressed.connect(func(): garlic_pressed.emit())
	var bw := _btn("战场对战  BATTLE", 31, C_RED)
	bw.custom_minimum_size = Vector2(420, 52)
	bw.pressed.connect(func(): battle_pressed.emit())
	var b2 := _btn("车库  GARAGE", 31, C_BLUE)
	b2.custom_minimum_size = Vector2(420, 52)
	b2.pressed.connect(func(): garage_pressed.emit())
	for b in [b1, bg, bw, b2]:
		var c := CenterContainer.new()
		c.add_child(b)
		bb.add_child(c)
	var press := _lbl("PRESS  START", 32, Color.WHITE, 9)
	press.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	vb.add_child(press)
	var ptw := press.create_tween().set_loops()
	ptw.tween_property(press, "modulate:a", 0.12, 0.5).set_trans(Tween.TRANS_SINE)
	ptw.tween_property(press, "modulate:a", 1.0, 0.5).set_trans(Tween.TRANS_SINE)
	title_info = _lbl("", 34, C_YELLOW, 10)
	title_info.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	vb.add_child(title_info)
	var hint := _lbl("WASD 驾驶   Shift 加速   鼠标 瞄准 / 左键 开炮   P 暂停   M 音乐", 19, Color.WHITE, 7)
	hint.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	vb.add_child(hint)


# ---------- HUD ----------
func _build_hud() -> void:
	hud = Control.new()
	_full(hud)
	hud.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(hud)
	var top := HBoxContainer.new()
	top.set_anchors_and_offsets_preset(Control.PRESET_TOP_WIDE)
	top.offset_left = 28
	top.offset_right = -28
	top.offset_top = 10
	top.mouse_filter = Control.MOUSE_FILTER_IGNORE
	hud.add_child(top)
	# 分数
	var left := HBoxContainer.new()
	left.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	left.add_theme_constant_override("separation", 8)
	top.add_child(left)
	left.add_child(_lbl("★", 64, C_YELLOW, 12))
	score_lbl = _lbl("0", 76, Color.WHITE, 14)
	left.add_child(score_lbl)
	# 计时
	var mid := CenterContainer.new()
	mid.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	top.add_child(mid)
	var tp := PanelContainer.new()
	tp.add_theme_stylebox_override("panel", _panel_box(Color("#ee4a3a"), Color("#8a1620")))
	mid.add_child(tp)
	var tv := VBoxContainer.new()
	tv.add_theme_constant_override("separation", -10)
	tp.add_child(tv)
	var tl := _lbl("TIME", 24, Color("#ffe9a8"), 6)
	tl.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	tv.add_child(tl)
	time_lbl = _lbl("60", 78, Color.WHITE, 12)
	time_lbl.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	time_lbl.custom_minimum_size = Vector2(110, 0)
	tv.add_child(time_lbl)
	var right := VBoxContainer.new()
	right.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	top.add_child(right)
	best_lbl = _lbl("BEST 0", 34, C_YELLOW, 10)
	best_lbl.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	right.add_child(best_lbl)
	# 大蒜模式的失误格（只在该模式显示）
	strike_lbl = _lbl("别压大蒜！", 24, Color("#cfe85a"), 7)
	strike_lbl.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	strike_lbl.visible = false
	right.add_child(strike_lbl)
	strike_bar = StrikeBar.new()
	strike_bar.custom_minimum_size = Vector2(0, 48)
	strike_bar.visible = false
	strike_bar.mouse_filter = Control.MOUSE_FILTER_IGNORE
	right.add_child(strike_bar)
	# 连击
	combo_box = VBoxContainer.new()
	combo_box.set_anchors_and_offsets_preset(Control.PRESET_CENTER_RIGHT)
	combo_box.offset_left = -360
	combo_box.offset_right = -28
	combo_box.offset_top = -50
	combo_box.mouse_filter = Control.MOUSE_FILTER_IGNORE
	hud.add_child(combo_box)
	combo_lbl = _lbl("COMBO ×1", 62, C_YELLOW, 14)
	combo_lbl.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	combo_box.add_child(combo_lbl)
	combo_bar = SegBar.new()
	combo_bar.segs = 10
	combo_bar.color = C_YELLOW
	combo_bar.custom_minimum_size = Vector2(300, 16)
	combo_box.add_child(combo_bar)
	# 加速槽
	var bot := VBoxContainer.new()
	bot.set_anchors_and_offsets_preset(Control.PRESET_BOTTOM_LEFT)
	bot.offset_left = 30
	bot.offset_right = 470
	bot.offset_top = -86
	bot.offset_bottom = -26
	bot.mouse_filter = Control.MOUSE_FILTER_IGNORE
	hud.add_child(bot)
	bot.add_child(_lbl("BOOST  ⚡Shift", 26, C_CYAN, 8))
	boost_bar = SegBar.new()
	boost_bar.segs = 16
	boost_bar.custom_minimum_size = Vector2(420, 22)
	bot.add_child(boost_bar)
	# 弹药
	var ab := VBoxContainer.new()
	ab.set_anchors_and_offsets_preset(Control.PRESET_BOTTOM_RIGHT)
	ab.offset_left = -400
	ab.offset_right = -30
	ab.offset_top = -92
	ab.offset_bottom = -26
	ab.alignment = BoxContainer.ALIGNMENT_END
	ab.mouse_filter = Control.MOUSE_FILTER_IGNORE
	hud.add_child(ab)
	ammo_lbl = _lbl("CANNON  左键 / E", 26, C_YELLOW, 8)
	ammo_lbl.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	ab.add_child(ammo_lbl)
	var arow := HBoxContainer.new()
	arow.alignment = BoxContainer.ALIGNMENT_END
	arow.mouse_filter = Control.MOUSE_FILTER_IGNORE
	ab.add_child(arow)
	ammo_bar = AmmoBar.new()
	ammo_bar.custom_minimum_size = Vector2(240, 30)
	ammo_bar.mouse_filter = Control.MOUSE_FILTER_IGNORE
	arow.add_child(ammo_bar)
	# 对战模式：自己的装甲条 + 击毁数（放在加速槽上方）
	hp_box = VBoxContainer.new()
	hp_box.set_anchors_and_offsets_preset(Control.PRESET_BOTTOM_LEFT)
	hp_box.offset_left = 30
	hp_box.offset_right = 470
	hp_box.offset_top = -170
	hp_box.offset_bottom = -96
	hp_box.mouse_filter = Control.MOUSE_FILTER_IGNORE
	hp_box.visible = false
	hud.add_child(hp_box)
	var hrow := HBoxContainer.new()
	hrow.add_theme_constant_override("separation", 14)
	hrow.mouse_filter = Control.MOUSE_FILTER_IGNORE
	hp_box.add_child(hrow)
	hp_lbl = _lbl("ARMOR", 26, Color("#ff8a7a"), 8)
	hrow.add_child(hp_lbl)
	kills_lbl = _lbl("", 26, C_YELLOW, 8)
	hrow.add_child(kills_lbl)
	hp_bar = SegBar.new()
	hp_bar.segs = 10
	hp_bar.color = Color("#ff4a3a")
	hp_bar.custom_minimum_size = Vector2(420, 26)
	hp_box.add_child(hp_bar)
	# 敌方血条（世界坐标投影过来的）
	enemy_bars = EnemyBars.new()
	enemy_bars.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_full(enemy_bars)
	enemy_bars.visible = false
	hud.add_child(enemy_bars)
	# 准星
	reticle = Reticle.new()
	reticle.mouse_filter = Control.MOUSE_FILTER_IGNORE
	reticle.visible = false
	hud.add_child(reticle)


# ---------- 车库 ----------
func _build_garage() -> void:
	garage_screen = Control.new()
	_full(garage_screen)
	add_child(garage_screen)
	var panel := _panel()
	panel.set_anchors_and_offsets_preset(Control.PRESET_LEFT_WIDE)
	panel.offset_left = 22
	panel.offset_top = 22
	panel.offset_bottom = -110
	panel.offset_right = 580
	garage_screen.add_child(panel)
	var vb := VBoxContainer.new()
	vb.add_theme_constant_override("separation", 10)
	panel.add_child(vb)
	var head := HBoxContainer.new()
	vb.add_child(head)
	var ht := _lbl("GARAGE", 54, C_YELLOW, 12)
	ht.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	head.add_child(ht)
	head.add_child(_lbl("◎ ", 44, C_YELLOW, 10))
	garage_coins = _lbl("0", 50, Color.WHITE, 10)
	head.add_child(garage_coins)
	var tabs := HBoxContainer.new()
	tabs.add_theme_constant_override("separation", 8)
	vb.add_child(tabs)
	var names := ["改装", "涂装"]
	for i in 2:
		var t := _btn(names[i], 30, C_BLUE)
		t.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		var idx := i
		t.pressed.connect(func():
			tab = idx
			refresh_garage())
		tabs.add_child(t)
		tab_btns.append(t)
	var sc := ScrollContainer.new()
	sc.size_flags_vertical = Control.SIZE_EXPAND_FILL
	sc.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	vb.add_child(sc)
	list_box = VBoxContainer.new()
	list_box.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	list_box.add_theme_constant_override("separation", 8)
	sc.add_child(list_box)
	var foot := HBoxContainer.new()
	foot.set_anchors_and_offsets_preset(Control.PRESET_BOTTOM_LEFT)
	foot.offset_left = 22
	foot.offset_top = -92
	foot.offset_bottom = -22
	foot.offset_right = 580
	foot.add_theme_constant_override("separation", 14)
	garage_screen.add_child(foot)
	var back := _btn("◀ 返回", 34, C_PURPLE)
	back.custom_minimum_size = Vector2(180, 66)
	back.pressed.connect(func(): title_pressed.emit())
	foot.add_child(back)
	var go := _btn("出击！ ▶", 42, C_ORANGE)
	go.custom_minimum_size = Vector2(360, 66)
	go.pressed.connect(func(): play_pressed.emit())
	foot.add_child(go)


func refresh_garage() -> void:
	garage_coins.text = _fmt(SaveGame.coins)
	for c in list_box.get_children():
		list_box.remove_child(c)
		c.queue_free()
	if tab == 0:
		_build_upgrades()
	else:
		_build_skins()


func _row(selected: bool = false) -> PanelContainer:
	var p := PanelContainer.new()
	if selected:
		p.add_theme_stylebox_override("panel", _panel_box(Color("#4a74d8"), Color("#2447a8")))
	else:
		p.add_theme_stylebox_override("panel", _panel_box(Color("#2a4fb8"), Color("#14287c")))
	return p


func _build_upgrades() -> void:
	for u in GameData.UPGRADES:
		var ud: Dictionary = u
		var id: String = ud["id"]
		var lv: int = int(SaveGame.up.get(id, 0))
		var mx: int = int(ud["max"])
		var row := _row()
		var hb := HBoxContainer.new()
		hb.add_theme_constant_override("separation", 10)
		row.add_child(hb)
		var vb := VBoxContainer.new()
		vb.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		vb.add_theme_constant_override("separation", -2)
		hb.add_child(vb)
		vb.add_child(_lbl(str(ud["name"]), 27, Color.WHITE, 7))
		var pips := ""
		for i in mx:
			pips += "★" if i < lv else "☆"
		vb.add_child(_lbl(pips, 19, C_YELLOW, 5))
		var dl := _lbl(str(ud["desc"]), 16, Color("#cfe0ff"), 4)
		dl.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
		dl.custom_minimum_size = Vector2(300, 0)
		vb.add_child(dl)
		var cost := GameData.upgrade_cost(ud, lv)
		var b: Button
		if lv >= mx:
			b = _btn("MAX", 28, C_GREEN)
			b.disabled = true
		else:
			b = _btn("◎ %s" % _fmt(cost), 28, C_ORANGE)
			b.disabled = SaveGame.coins < cost
			b.pressed.connect(func(): upgrade_buy.emit(id))
		b.custom_minimum_size = Vector2(120, 48)
		b.size_flags_vertical = Control.SIZE_SHRINK_CENTER
		hb.add_child(b)
		list_box.add_child(row)


func _build_skins() -> void:
	for s in GameData.SKINS:
		var sd: Dictionary = s
		var id: String = sd["id"]
		var owned := SaveGame.skins_owned.has(id)
		var equipped := SaveGame.skin == id
		var row := _row(preview_id == id)
		row.mouse_filter = Control.MOUSE_FILTER_STOP
		row.gui_input.connect(func(ev: InputEvent):
			if ev is InputEventMouseButton and ev.pressed and ev.button_index == MOUSE_BUTTON_LEFT:
				preview_id = id
				skin_preview.emit(id)
				refresh_garage())
		var hb := HBoxContainer.new()
		hb.add_theme_constant_override("separation", 12)
		hb.mouse_filter = Control.MOUSE_FILTER_IGNORE
		row.add_child(hb)
		var sw := HBoxContainer.new()
		sw.add_theme_constant_override("separation", 0)
		sw.mouse_filter = Control.MOUSE_FILTER_IGNORE
		for key in ["body", "turret", "accent"]:
			var cr := ColorRect.new()
			cr.color = Color.html(str(sd[key]))
			cr.custom_minimum_size = Vector2(22, 44)
			cr.mouse_filter = Control.MOUSE_FILTER_IGNORE
			sw.add_child(cr)
		hb.add_child(sw)
		var nl := _lbl(str(sd["name"]), 34, Color.WHITE, 8)
		nl.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		nl.mouse_filter = Control.MOUSE_FILTER_IGNORE
		hb.add_child(nl)
		var b: Button
		if equipped:
			b = _btn("已装备", 26, C_GREEN)
			b.disabled = true
		elif owned:
			b = _btn("装备", 28, C_GREEN)
			b.pressed.connect(func(): skin_equip.emit(id))
		else:
			var price: int = int(sd["price"])
			b = _btn("◎ %s" % _fmt(price), 28, C_ORANGE)
			b.disabled = SaveGame.coins < price
			b.pressed.connect(func(): skin_buy.emit(id))
		b.custom_minimum_size = Vector2(150, 54)
		hb.add_child(b)
		list_box.add_child(row)


# ---------- 结算 / 暂停 ----------
func _build_results() -> void:
	results_screen = Control.new()
	_full(results_screen)
	add_child(results_screen)
	var dim := ColorRect.new()
	dim.color = Color(0, 0, 0, 0.35)
	_full(dim)
	results_screen.add_child(dim)
	var cc := CenterContainer.new()
	_full(cc)
	results_screen.add_child(cc)
	var p := _panel(Vector2(660, 0))
	cc.add_child(p)
	var vb := VBoxContainer.new()
	vb.add_theme_constant_override("separation", 10)
	p.add_child(vb)
	res_title = _lbl("RESULTS", 70, C_YELLOW, 14)
	res_title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	vb.add_child(res_title)
	res_record = _lbl("★ NEW RECORD ★", 44, C_ORANGE, 10)
	res_record.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	vb.add_child(res_record)
	res_body = _lbl("", 36, Color.WHITE, 9)
	res_body.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	vb.add_child(res_body)
	var hb := HBoxContainer.new()
	hb.alignment = BoxContainer.ALIGNMENT_CENTER
	hb.add_theme_constant_override("separation", 12)
	vb.add_child(hb)
	var b1 := _btn("再来一局", 32, C_ORANGE)
	b1.pressed.connect(func(): retry_pressed.emit())
	var b2 := _btn("车库", 32, C_BLUE)
	b2.pressed.connect(func(): garage_pressed.emit())
	var b3 := _btn("标题", 32, C_PURPLE)
	b3.pressed.connect(func(): title_pressed.emit())
	for b in [b1, b2, b3]:
		b.custom_minimum_size = Vector2(180, 64)
		hb.add_child(b)


func _build_pause() -> void:
	pause_screen = Control.new()
	_full(pause_screen)
	add_child(pause_screen)
	var dim := ColorRect.new()
	dim.color = Color(0, 0, 0, 0.5)
	_full(dim)
	pause_screen.add_child(dim)
	var cc := CenterContainer.new()
	_full(cc)
	pause_screen.add_child(cc)
	var vb := VBoxContainer.new()
	vb.add_theme_constant_override("separation", 14)
	cc.add_child(vb)
	var l := _lbl("PAUSE", 110, C_YELLOW, 18)
	l.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	vb.add_child(l)
	var b1 := _btn("继续", 40, C_ORANGE)
	b1.custom_minimum_size = Vector2(320, 68)
	b1.pressed.connect(func(): resume_pressed.emit())
	var b2 := _btn("退出到标题", 32, C_PURPLE)
	b2.custom_minimum_size = Vector2(320, 60)
	b2.pressed.connect(func(): title_pressed.emit())
	vb.add_child(b1)
	vb.add_child(b2)
