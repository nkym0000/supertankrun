class_name TankAI
extends RefCounted
## 对战模式的电脑坦克大脑。只做决策，不碰场景——每帧返回一组"按键"给 main.gd。
##
## 行为：挑最近的活着的对手 -> 保持中距离绕圈 -> 躲开障碍和场地边缘 -> 对准了且弹道干净就开火。

const RETARGET := 1.8      # 多久重新挑一次目标
const RANGE_WANT := 26.0   # 希望保持的交战距离
const RANGE_DEAD := 13.0   # 比这个还近就倒车
const TANK_CLEAR := 15.0   # 与其它坦克保持的最小间距
const FIRE_CONE := 0.09    # 炮口对准目标的角度容差（弧度）
const FIRE_RANGE := 62.0

var tank: Tank
var skill := 1.0           # 0..1，影响预判精度、反应和开火频率

var target: Tank = null
var _retarget_t := 0.0
var _strafe := 1.0
var _strafe_t := 0.0
var _fire_cd := 0.0
var _aim := 0.0
var _aim_err := 0.0
var ammo := 3
var reload_t := 0.0


var range_want := RANGE_WANT


func _init(t: Tank, s: float) -> void:
	tank = t
	skill = s
	_aim = t.heading
	_strafe = 1.0 if randf() < 0.5 else -1.0
	# 每辆车偏好的交战距离略有不同，免得所有人挤在同一个圈上
	range_want = RANGE_WANT + randf_range(-7.0, 10.0)
	# 错开第一枪，开局才不会六辆车同时齐射
	_fire_cd = randf_range(1.0, 3.5)
	_roll_aim_error()


## 每打一发重掷一次瞄准偏差：技能越低偏得越多
func _roll_aim_error() -> void:
	_aim_err = randf_range(-1.0, 1.0) * (1.0 - skill) * 0.30


func _pick_target(all: Array) -> void:
	var best: Tank = null
	var bd := 1e9
	# 必须打乱再比。出生点在圆周上均分，相邻两辆到自己的距离完全相等，
	# 按列表顺序比大小会让下标 0（也就是玩家）稳定赢得平局 —— 开局就被两辆车同时盯上。
	var cands := all.duplicate()
	cands.shuffle()
	for o in cands:
		var other: Tank = o
		if other == tank or not other.alive:
			continue
		# 纯粹挑最近的——这是混战，不是围攻玩家。偏向玩家会变成 5 打 1。
		var d := Vector2(other.position.x - tank.position.x, other.position.z - tank.position.z).length()
		if d < bd:
			bd = d
			best = other
	target = best


## 障碍物、其它坦克与边界的排斥力（XZ 平面）
func _avoid(obstacles: Array, all: Array) -> Vector2:
	var push := Vector2.ZERO
	var p := Vector2(tank.position.x, tank.position.z)
	for o in obstacles:
		var ov: Vector3 = o
		var d := p - Vector2(ov.x, ov.z)
		var dl := d.length()
		var reach := ov.y + 9.0
		if dl < reach and dl > 0.01:
			push += d / dl * (reach - dl) / reach
	# 别的坦克也要躲开，否则大家会挤成一团贴脸互殴
	for t in all:
		var other: Tank = t
		if other == tank or not other.alive:
			continue
		var d2 := p - Vector2(other.position.x, other.position.z)
		var dl2 := d2.length()
		if dl2 < TANK_CLEAR and dl2 > 0.01:
			push += d2 / dl2 * (TANK_CLEAR - dl2) / TANK_CLEAR * 2.0
	# 场地边缘
	var edge := GameData.arena_radius - 8.0
	if p.length() > edge:
		push += -p.normalized() * ((p.length() - edge) / 8.0) * 2.5
	return push


## 炮弹飞到目标要多久 -> 提前量
func _lead(tgt: Tank, shell_speed: float) -> Vector3:
	var d := tgt.position - tank.position
	var t := d.length() / maxf(shell_speed, 1.0)
	return tgt.position + tgt.vel * t * skill


## 弹道上有没有障碍挡着（避免对着掩体开火）
func _line_blocked(to: Vector3, obstacles: Array) -> bool:
	var a := Vector2(tank.position.x, tank.position.z)
	var b := Vector2(to.x, to.z)
	var ab := b - a
	var len_ab := ab.length()
	if len_ab < 0.01:
		return false
	var dir := ab / len_ab
	for o in obstacles:
		var ov: Vector3 = o
		var c := Vector2(ov.x, ov.z) - a
		var proj := c.dot(dir)
		if proj <= 1.5 or proj >= len_ab - 1.0:
			continue
		if (c - dir * proj).length() < ov.y + 0.7:
			return true
	return false


## 返回 {"throttle","steer","boost","aim","fire"}
func think(dt: float, all: Array, obstacles: Array, stats: Dictionary) -> Dictionary:
	var out := {"throttle": 0.0, "steer": 0.0, "boost": false, "aim": _aim, "fire": false}
	if not tank.alive:
		return out
	# 装填
	var cap := int(stats["ammo_max"])
	if ammo < cap:
		reload_t -= dt
		if reload_t <= 0.0:
			ammo += 1
			reload_t = float(stats["reload"])
	_fire_cd = maxf(0.0, _fire_cd - dt)
	_retarget_t -= dt
	if _retarget_t <= 0.0 or target == null or not target.alive:
		_retarget_t = RETARGET
		_pick_target(all)
	_strafe_t -= dt
	if _strafe_t <= 0.0:
		_strafe_t = randf_range(1.6, 3.4)
		_strafe = -_strafe
	var avoid := _avoid(obstacles, all)
	if target == null:
		# 没目标就在场地里晃
		var wander := Vector2(cos(tank.heading), sin(tank.heading)) + avoid
		out["steer"] = clampf(angle_difference(tank.heading, atan2(wander.x, wander.y)) * 1.8, -1.0, 1.0)
		out["throttle"] = 0.45
		out["aim"] = _aim
		return out

	var to := Vector2(target.position.x - tank.position.x, target.position.z - tank.position.z)
	var dist := to.length()
	var dir := to / maxf(dist, 0.001)
	# 想去的方向：保持距离 + 横向绕圈 + 躲障碍
	var want := Vector2.ZERO
	if dist > range_want + 6.0:
		want = dir
	elif dist < RANGE_DEAD:
		want = -dir
	else:
		want = Vector2(-dir.y, dir.x) * _strafe + dir * 0.15
	want += avoid * 1.6
	if want.length() < 0.01:
		want = dir
	want = want.normalized()

	var target_h := atan2(want.x, want.y)
	var diff := angle_difference(tank.heading, target_h)
	out["steer"] = clampf(diff * 2.4, -1.0, 1.0)
	# 车头没对上就少给油，免得一直打转
	out["throttle"] = 1.0 if absf(diff) < 1.2 else 0.35
	if dist < RANGE_DEAD:
		out["throttle"] = -0.8
	out["boost"] = dist > range_want + 18.0 and absf(diff) < 0.4

	# 瞄准：提前量 + 每发重新掷一次的偏差。偏差必须按"发"算而不是连续抖动，
	# 否则炮塔只会围着准确值轻微摆动，几乎弹无虚发。
	var aim_pt := _lead(target, float(stats["shell_speed"]))
	_aim = atan2(aim_pt.x - tank.position.x, aim_pt.z - tank.position.z) + _aim_err
	out["aim"] = _aim
	# 开火条件：弹药、冷却、对准、在射程内、弹道没被掩体挡住
	if ammo > 0 and _fire_cd <= 0.0 and dist < FIRE_RANGE:
		var off := absf(angle_difference(tank.turret_world, _aim))
		if off < FIRE_CONE and not _line_blocked(target.position, obstacles):
			out["fire"] = true
			ammo -= 1
			_fire_cd = lerpf(2.8, 1.4, skill)
			_roll_aim_error()
	return out
