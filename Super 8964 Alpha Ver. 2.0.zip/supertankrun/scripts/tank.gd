class_name Tank
extends Node3D
## 低多边形坦克：模型由代码生成；包含驾驶物理（带侧滑）、加速槽、眩晕。
## 模型朝向 +Z；heading=0 时车头朝 +Z。

var stats: Dictionary = GameData.stats({})
var heading := 0.0
var vel := Vector3.ZERO
var fwd_speed := 0.0
var boost := 100.0
var boost_idle := 0.0
var boosting := false
var stun := 0.0
var skin_id := "olive"
var last_steer := 0.0

# 对战模式
var hp := GameData.TANK_HP
var hp_max := GameData.TANK_HP
var alive := true
var hurt_t := 0.0         # 受击闪白计时
var is_enemy := false

# 主炮
var aim_world := 0.0      # 期望的炮塔世界朝向（弧度）
var turret_world := 0.0   # 当前炮塔世界朝向
var traverse := 2.4       # 炮塔转速 rad/s（由升级决定）
var recoil := 0.0         # 后坐，0..1

var body: Node3D
var turret: Node3D
var flag: MeshInstance3D
var shadow: MeshInstance3D
var wheels: Array = []
var cleats: Array = []
var _hull_mi: MeshInstance3D
var _tread_mi: MeshInstance3D
var _turret_mi: MeshInstance3D
var _barrel_mi: MeshInstance3D
var _body_mat: ShaderMaterial
var _decal_body: MeshInstance3D
var _decal_turret: MeshInstance3D
var _cleat_off := 0.0
var _pitch := 0.0
var _roll := 0.0
var _t := 0.0
var _prev_vf := 0.0


func _init() -> void:
	body = Node3D.new()
	add_child(body)
	shadow = MeshInstance3D.new()
	shadow.mesh = MB.ground_quad(1.0, 1.0)
	shadow.material_override = Mats.shadow()
	shadow.position = Vector3(0, 0.05, 0)
	shadow.scale = Vector3(3.2, 1.0, 4.0)
	add_child(shadow)
	_hull_mi = _mi(body)
	_tread_mi = _mi(body, Mats.lp("tread", "tread", 1, 0.9))
	turret = Node3D.new()
	turret.position = Vector3(0, 1.65, -0.2)
	body.add_child(turret)
	_turret_mi = _mi(turret)
	_barrel_mi = _mi(turret) # 独立节点，开炮时沿 Z 后坐
	flag = _mi(turret)
	_decal_body = _mi(body, null)
	_decal_turret = _mi(turret, null)
	flag.position = Vector3(0.55, 2.45, -0.45)
	for side in [-1.0, 1.0]:
		for i in 5:
			var w := _mi(body)
			w.position = Vector3(side * 1.32, 0.42, -1.5 + i * 0.75)
			wheels.append(w)
		var c := _mi(body)
		c.position = Vector3(side * 1.32, 0.0, 0.0)
		cleats.append(c)
	apply_skin("olive")


func _mi(parent: Node3D, mat: Material = null) -> MeshInstance3D:
	var m := MeshInstance3D.new()
	m.material_override = mat if mat != null else Mats.lp("tank", "metal", 1, 0.55)
	parent.add_child(m)
	return m


## 顶点色 alpha 的约定（配合 lowpoly.gdshader 的 tex_mode 1）：
##   a=1 -> 取 tex_a（迷彩贴图，彩色，顶点色应为白）
##   a=0 -> 取 tex_b（metal 明度图，由顶点色上色）= 纯色细节
static func _solid(c: Color) -> Color:
	return Color(c.r, c.g, c.b, 0.0)


static func _skinned(c: Color) -> Color:
	return Color(c.r, c.g, c.b, 1.0)


func apply_skin(id: String) -> void:
	skin_id = id
	var s: Dictionary = GameData.skin_by_id(id)
	var camo := bool(s.get("camo", false))
	var cb := Color.html(str(s["body"]))
	var ct := Color.html(str(s["trim"]))
	var cu := Color.html(str(s["turret"]))
	var ca := Color.html(str(s["accent"]))
	# 迷彩皮肤：车体/炮塔顶点色设为白，颜色完全由 camo 贴图提供
	var shared: ShaderMaterial = Mats.lp("tank_camo", "camo", 1, 0.2, "metal") if camo else Mats.lp("tank", "metal", 1, 0.55)
	# 每辆坦克一份独立材质，受击闪白才不会互相串
	var body_mat: ShaderMaterial = shared.duplicate()
	_body_mat = body_mat
	_hull_mi.material_override = body_mat
	_turret_mi.material_override = body_mat
	if camo:
		cb = Color.WHITE
		ct = Color.WHITE
		cu = Color.WHITE
	var pb := _skinned(cb)
	var pt := _skinned(ct)
	var pu := _skinned(cu)
	# 纯色细节件
	var gun := _solid(Color("#46532e") if camo else ct)
	var hatch := _solid(Color("#38412a") if camo else ct.darkened(0.2))
	var lamp := _solid(Color("#fff6b0"))
	var pipe := _solid(Color("#2b2b22") if camo else Color("#3a3a44"))
	var muzzle := _solid(Color("#333d22") if camo else ca)
	var track_c := Color("#1f201a") if camo else Color("#4a4a52")
	var wheel_c := Color("#2b2f22") if camo else Color("#8a8a94")
	var hub_c := Color("#3e462c") if camo else ca
	var cleat_c := Color("#17180f") if camo else Color("#2a2a30")
	# 车体
	var h := MB.new()
	h.wedge(MB.xf(0, 0.8, 0), Vector3(2.0, 0.8, 3.6), 0.75, pb)
	h.wedge(MB.xf(0, 1.42, -0.25), Vector3(1.7, 0.45, 2.6), 0.45, pt)
	for sx in [-1.0, 1.0]:
		h.box(MB.xf(sx * 1.32, 1.0, 0.0), Vector3(1.0, 0.1, 3.95), pt)
		h.box(MB.xf(sx * 0.7, 0.72, 1.5), Vector3(0.32, 0.22, 0.14), lamp)
	h.cyl(MB.xf(0.72, 1.35, -1.9), 0.11, 0.11, 0.5, 6, pipe, true)
	# 车首舱盖
	h.box(MB.xf(0, 1.67, -1.33), Vector3(0.56, 0.1, 0.46), hatch)
	_hull_mi.mesh = h.build()
	# 履带
	var tr := MB.new()
	for sx in [-1.0, 1.0]:
		tr.box(MB.xf(sx * 1.32, 0.45, 0.0), Vector3(0.85, 0.9, 3.9), track_c)
	_tread_mi.mesh = tr.build()
	# 车轮（轴向 X）
	var wb := MB.new()
	wb.cyl(Transform3D(Basis(Vector3(0, 0, 1), PI / 2.0), Vector3.ZERO), 0.42, 0.42, 0.98, 10, wheel_c, true)
	wb.box(MB.xf(), Vector3(1.0, 0.12, 0.7), hub_c)
	wb.box(MB.xf(), Vector3(1.0, 0.7, 0.12), hub_c)
	var wmesh := wb.build()
	for w in wheels:
		(w as MeshInstance3D).mesh = wmesh
	# 履带齿（顶面滚动）
	var cb2 := MB.new()
	for k in 13:
		cb2.box(MB.xf(0, 0.91, -1.68 + k * 0.28), Vector3(0.92, 0.08, 0.17), cleat_c)
	var cmesh := cb2.build()
	for c in cleats:
		(c as MeshInstance3D).mesh = cmesh
		(c as MeshInstance3D).material_override = Mats.lp("tread", "tread", 1, 0.9)
	# 炮塔
	var tb := MB.new()
	tb.cyl(MB.xf(0, 0.1, 0), 0.95, 0.8, 0.5, 10, pu, true)
	tb.wedge(MB.xf(0, 0.58, 0.05), Vector3(1.35, 0.45, 1.6), 0.45, pu)
	tb.box(MB.xf(0, 0.45, 0.95), Vector3(0.7, 0.55, 0.4), gun) # 炮盾（不后坐）
	tb.cyl(MB.xf(-0.35, 0.85, -0.3), 0.3, 0.3, 0.12, 8, hatch, true)
	tb.cyl(MB.xf(0.55, 1.45, -0.45), 0.025, 0.025, 2.0, 4, pipe)
	_turret_mi.mesh = tb.build()
	# 炮管（后坐件）
	var gb := MB.new()
	gb.cyl(Transform3D(Basis(Vector3.RIGHT, PI / 2.0), Vector3(0, 0.45, 2.3)), 0.15, 0.13, 2.6, 8, gun, true)
	gb.cyl(Transform3D(Basis(Vector3.RIGHT, PI / 2.0), Vector3(0, 0.45, 3.55)), 0.21, 0.21, 0.45, 8, muzzle, true)
	_barrel_mi.mesh = gb.build()
	_barrel_mi.material_override = body_mat
	var fb := MB.new()
	fb.box(MB.xf(0, 0, -0.25), Vector3(0.03, 0.32, 0.5), _solid(ca))
	flag.mesh = fb.build()
	# 星星贴花（迷彩涂装不贴）
	if camo:
		_decal_turret.mesh = MB.new().build()
		_decal_body.mesh = MB.new().build()
		return
	var dm := Mats.fx("star", false, ca)
	var dt := MB.new()
	var q := 0.3
	for sgn in [1.0, -1.0]:
		var x: float = sgn * 0.688
		if sgn > 0.0:
			dt.quad_uv(Vector3(x, 0.58 - q, 0.05 + q), Vector3(x, 0.58 - q, 0.05 - q), Vector3(x, 0.58 + q, 0.05 - q), Vector3(x, 0.58 + q, 0.05 + q), Color.WHITE,
				Vector2(0, 1), Vector2(1, 1), Vector2(1, 0), Vector2(0, 0))
		else:
			dt.quad_uv(Vector3(x, 0.58 - q, 0.05 - q), Vector3(x, 0.58 - q, 0.05 + q), Vector3(x, 0.58 + q, 0.05 + q), Vector3(x, 0.58 + q, 0.05 - q), Color.WHITE,
				Vector2(0, 1), Vector2(1, 1), Vector2(1, 0), Vector2(0, 0))
	_decal_turret.mesh = dt.build()
	_decal_turret.material_override = dm
	var db := MB.new()
	var y := 1.66
	db.quad_uv(Vector3(-0.22, y, -1.53), Vector3(-0.22, y, -1.13), Vector3(0.22, y, -1.13), Vector3(0.22, y, -1.53), Color.WHITE,
		Vector2(0, 1), Vector2(0, 0), Vector2(1, 0), Vector2(1, 1))
	_decal_body.mesh = db.build()
	_decal_body.material_override = dm


## 驾驶一步。返回撞击强度（撞墙/障碍时 > 0）。
func drive(dt: float, throttle: float, steer: float, want_boost: bool, obstacles: Array) -> float:
	var impact := 0.0
	if stun > 0.0:
		stun -= dt
		throttle = 0.0
		steer = 0.0
		want_boost = false
	last_steer = steer
	var fwd := Vector3(sin(heading), 0.0, cos(heading))
	var side := Vector3(fwd.z, 0.0, -fwd.x)
	boosting = want_boost and boost > 1.0 and throttle > 0.0
	if boosting:
		boost = maxf(0.0, boost - 34.0 * dt)
		boost_idle = 0.0
	else:
		boost_idle += dt
		if boost_idle > 0.8:
			boost = minf(float(stats["boost_max"]), boost + float(stats["boost_regen"]) * dt)
	var vf := vel.dot(fwd)
	var vl := vel.dot(side)
	var max_s: float = float(stats["max_speed"]) * (float(stats["boost_mul"]) if boosting else 1.0)
	var target := 0.0
	if throttle > 0.0:
		target = max_s * throttle
	elif throttle < 0.0:
		target = max_s * 0.5 * throttle
	var rate: float = float(stats["accel"]) * (1.6 if boosting else 1.0)
	if throttle == 0.0:
		rate = 12.0
	elif signf(target) != signf(vf) and absf(vf) > 0.5:
		rate *= 1.8
	vf = move_toward(vf, target, rate * dt)
	vl *= exp(-float(stats["grip"]) * dt)
	vel = fwd * vf + side * vl
	var speed_frac := clampf(absf(vf) / float(stats["max_speed"]), 0.0, 1.0)
	var turn_rate: float = float(stats["turn"]) * (0.5 + 0.5 * speed_frac) * (0.8 if boosting else 1.0)
	heading += steer * turn_rate * dt
	position += vel * dt
	# 场地边界
	var lim := GameData.arena_radius - 1.8
	var flat := Vector3(position.x, 0.0, position.z)
	if flat.length() > lim:
		var n := flat.normalized()
		position.x = n.x * lim
		position.z = n.z * lim
		var vn := vel.dot(n)
		if vn > 0.0:
			impact = maxf(impact, vn)
			vel -= n * vn * 1.4
	# 障碍物
	var rr: float = float(stats["radius"]) * 0.85
	for o in obstacles:
		var ov: Vector3 = o
		var d := Vector3(position.x - ov.x, 0.0, position.z - ov.z)
		var dist := d.length()
		var min_d := rr + ov.y
		if dist < min_d and dist > 0.001:
			var n2 := d / dist
			position.x = ov.x + n2.x * min_d
			position.z = ov.z + n2.z * min_d
			var vn2 := vel.dot(n2)
			if vn2 < 0.0:
				impact = maxf(impact, -vn2)
				vel -= n2 * vn2 * 1.3
	fwd_speed = vel.dot(Vector3(sin(heading), 0.0, cos(heading)))
	return impact


func update_visuals(dt: float) -> void:
	_t += dt
	rotation.y = heading
	var vf := fwd_speed
	for w in wheels:
		(w as Node3D).rotation.x += vf * dt / 0.42
	_cleat_off = fposmod(_cleat_off + vf * dt, 0.28)
	for c in cleats:
		(c as Node3D).position.z = _cleat_off
	var acc := (vf - _prev_vf) / maxf(dt, 0.0001)
	_prev_vf = vf
	var sf := clampf(absf(vf) / maxf(float(stats["max_speed"]), 1.0), 0.0, 1.5)
	var k := 1.0 - exp(-8.0 * dt)
	_pitch = lerpf(_pitch, clampf(-acc * 0.0035, -0.07, 0.07), k)
	_roll = lerpf(_roll, clampf(last_steer * sf * 0.05, -0.06, 0.06), k)
	body.rotation = Vector3(_pitch, 0.0, _roll)
	body.position.y = absf(sin(_t * 16.0)) * 0.025 * sf
	# 炮塔以固定角速度转向目标；被炸晕时乱转
	if stun > 0.0:
		turret_world += dt * 18.0
	else:
		var diff := angle_difference(turret_world, aim_world)
		var step := traverse * dt
		turret_world = wrapf(turret_world + clampf(diff, -step, step), -PI, PI)
	turret.rotation.y = wrapf(turret_world - heading, -PI, PI)
	recoil = maxf(0.0, recoil - dt * 4.2)
	_barrel_mi.position.z = -recoil * 0.6
	if hurt_t > 0.0:
		hurt_t = maxf(0.0, hurt_t - dt)
		_apply_hurt_flash()
	flag.rotation.y = sin(_t * 9.0) * 0.35 + clampf(sf, 0.0, 1.0) * 0.3


## 扣血；返回 true 表示这一下打爆了
func take_damage(amount: float) -> bool:
	if not alive:
		return false
	hp = maxf(0.0, hp - amount)
	hurt_t = 0.22
	if hp <= 0.0:
		alive = false
		return true
	return false


func reset_health() -> void:
	hp = GameData.TANK_HP
	hp_max = GameData.TANK_HP
	alive = true
	hurt_t = 0.0


## 受击时整车闪白。注意 Mats.lp 返回的是共享缓存材质，所以每辆坦克必须自己复制一份，
## 否则一辆挨打会让全场坦克一起闪。
func _apply_hurt_flash() -> void:
	if _body_mat != null:
		_body_mat.set_shader_parameter("flash", clampf(hurt_t / 0.22, 0.0, 1.0) * 0.5)


## 炮口朝向（水平）
func turret_fwd() -> Vector3:
	return Vector3(sin(turret_world), 0.0, cos(turret_world))


## 炮口世界坐标（含车身俯仰/侧倾与悬挂抖动）
func muzzle_pos() -> Vector3:
	return turret.global_transform * Vector3(0.0, 0.45, 3.95)


## 车尾排气口世界坐标（冒烟/涡轮火焰）
func exhaust_pos() -> Vector3:
	var fwd := Vector3(sin(heading), 0.0, cos(heading))
	var side := Vector3(fwd.z, 0.0, -fwd.x)
	return position - fwd * 1.95 + side * 0.72 + Vector3(0, 1.45, 0)


func rear_pos(side_sign: float) -> Vector3:
	var fwd := Vector3(sin(heading), 0.0, cos(heading))
	var side := Vector3(fwd.z, 0.0, -fwd.x)
	return position - fwd * 1.9 + side * side_sign * 1.3 + Vector3(0, 0.15, 0)
