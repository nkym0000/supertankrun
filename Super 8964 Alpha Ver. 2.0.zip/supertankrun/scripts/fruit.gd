class_name Fruit
extends Node3D
## 会滚动的水果/道具：樱桃、苹果、橙子、香蕉、西瓜、金苹果、地雷。

var kind := "apple"
var info: Dictionary = {}
var r := 0.5
var vel := Vector3.ZERO
var age := 0.0
var life := 30.0
var state := 0 # 0 活着  1 被压扁  2 淡出消失
var die_t := 0.0
var fade_t := 0.0
var cooldown := 0.0
var done := false
var frozen := false # 仅用于展示/截图
var inner: Node3D
var _wander := 0.0
var _shadow: MeshInstance3D

static var _mesh_cache: Dictionary = {}


func setup(k: String) -> void:
	kind = k
	info = GameData.FRUITS[k]
	r = float(info["r"])
	life = float(info["life"])
	inner = Node3D.new()
	inner.position.y = r
	add_child(inner)
	var mi := MeshInstance3D.new()
	mi.mesh = Fruit.mesh_for(k)
	mi.material_override = Fruit.mat_for(k)
	inner.add_child(mi)
	_shadow = MeshInstance3D.new()
	_shadow.mesh = MB.ground_quad(1.0, 1.0)
	_shadow.material_override = Mats.shadow()
	_shadow.position.y = 0.05
	_shadow.scale = Vector3(r * 2.4, 1.0, r * 2.4)
	add_child(_shadow)
	scale = Vector3.ONE * 0.01


func is_bad() -> bool:
	return info.get("bad", false)


func is_heavy() -> bool:
	return info.get("heavy", false)


## 大蒜模式的禁忌目标：碰到或炸到都算一次失误
func is_garlic() -> bool:
	return info.get("garlic", false)


func squash() -> void:
	state = 1
	die_t = 0.0
	_shadow.visible = false


func step(dt: float, tank_pos: Vector3, obstacles: Array, difficulty: float, ambient: bool) -> void:
	age += dt
	cooldown = maxf(0.0, cooldown - dt)
	if state == 1:
		die_t += dt
		var p := clampf(die_t / 0.18, 0.0, 1.0)
		scale = Vector3(1.0 + 1.3 * p, 1.0 - 0.9 * p, 1.0 + 1.3 * p)
		if die_t > 0.22:
			done = true
		return
	if state == 2:
		fade_t += dt
		scale = Vector3.ONE * clampf(1.0 - fade_t / 0.4, 0.0, 1.0)
		if fade_t >= 0.4:
			done = true
		return
	if age < 0.3:
		scale = Vector3.ONE * clampf(age / 0.3, 0.01, 1.0)
	else:
		scale = Vector3.ONE
	if frozen:
		_animate(dt, 0.0)
		return
	if age > life:
		state = 2
		return
	# 速度调节 + 游走
	var want: float = float(info["speed"]) * (1.0 + 0.25 * difficulty)
	var sp := vel.length()
	if sp < 0.1:
		vel = Vector3.RIGHT.rotated(Vector3.UP, randf() * TAU) * want
		sp = want
	var nsp := lerpf(sp, want, 1.0 - exp(-0.8 * dt))
	_wander = clampf(_wander + randf_range(-1.0, 1.0) * dt * 3.0, -0.8, 0.8)
	vel = vel.rotated(Vector3.UP, _wander * dt).normalized() * nsp
	# 金苹果会逃跑
	if info.get("flee", false) and not ambient:
		var d := position - tank_pos
		d.y = 0.0
		var dist := d.length()
		if dist < 16.0 and dist > 0.01:
			vel += d / dist * 70.0 * dt * (1.0 - dist / 16.0)
	position += vel * dt
	# 场地边界反弹
	var flat := Vector3(position.x, 0.0, position.z)
	var lim := GameData.arena_radius - 1.0 - r
	if flat.length() > lim:
		var n := flat.normalized()
		position.x = n.x * lim
		position.z = n.z * lim
		var vn := vel.dot(n)
		if vn > 0.0:
			vel -= 2.0 * vn * n
	# 障碍物反弹
	for o in obstacles:
		var ov: Vector3 = o
		var dd := Vector3(position.x - ov.x, 0.0, position.z - ov.z)
		var dl := dd.length()
		if dl < ov.y + r and dl > 0.001:
			var n2 := dd / dl
			position.x = ov.x + n2.x * (ov.y + r)
			position.z = ov.z + n2.z * (ov.y + r)
			var vn2 := vel.dot(n2)
			if vn2 < 0.0:
				vel -= 2.0 * vn2 * n2
	_animate(dt, nsp)


func _animate(dt: float, sp: float) -> void:
	var hop := 0.0
	if kind == "banana":
		inner.rotate_y(dt * 6.0)
		hop = 0.05
	elif kind == "mine":
		var axis := Vector3(vel.z, 0.0, -vel.x)
		if axis.length() > 0.001:
			inner.basis = (Basis(axis.normalized(), sp * dt / r * 0.5) * inner.basis).orthonormalized()
		inner.scale = Vector3.ONE * (1.0 + 0.06 * sin(age * 8.0))
	else:
		var axis2 := Vector3(vel.z, 0.0, -vel.x)
		if axis2.length() > 0.001:
			inner.basis = (Basis(axis2.normalized(), sp * dt / r) * inner.basis).orthonormalized()
	if kind == "gold":
		hop = absf(sin(age * 7.0)) * 0.35
		inner.visible = age < life - 3.0 or int(age * 8.0) % 2 == 0
	inner.position.y = r + hop


# ---------- 模型 ----------
static func mat_for(k: String) -> Material:
	if k == "banana":
		return Mats.lp("fruit_banana", "", 0)
	return Mats.lp("fruit_" + k, k, 2)


static func mesh_for(k: String) -> ArrayMesh:
	if _mesh_cache.has(k):
		return _mesh_cache[k]
	var m := _build_mesh(k)
	_mesh_cache[k] = m
	return m


## 顶点色 alpha：1 = 贴球面贴图，0 = 只用顶点色（茎/叶/刺）
static func _build_mesh(k: String) -> ArrayMesh:
	var b := MB.new()
	var tx := Color(1, 1, 1, 1)
	match k:
		"cherry":
			b.ico(MB.xf(), 0.5, 2, tx, 0.0, Callable(), true)
			b.cyl(Transform3D(Basis(Vector3(0, 0, 1), 0.4), Vector3(0.1, 0.62, 0)), 0.04, 0.04, 0.5, 5, Color(0.25, 0.65, 0.2, 0), true)
		"apple":
			b.ico(Transform3D(Basis.from_scale(Vector3(1.0, 0.92, 1.0)), Vector3.ZERO), 0.65, 2, tx, 0.0, Callable(), true)
			b.cyl(MB.xf(0, 0.66, 0), 0.045, 0.045, 0.3, 5, Color(0.4, 0.25, 0.12, 0), true)
			b.box(MB.xf(0.14, 0.72, 0), Vector3(0.26, 0.04, 0.14), Color(0.3, 0.75, 0.2, 0))
		"orange":
			b.ico(MB.xf(), 0.75, 2, tx, 0.0, Callable(), true)
			b.cyl(MB.xf(0, 0.76, 0), 0.09, 0.06, 0.1, 6, Color(0.3, 0.7, 0.2, 0), true)
		"banana":
			b.arc_tube(MB.xf(0, 0, -0.7), 0.9, 0.22, 1.9, 6, 9, Color("#ffd93a"), Color("#6b4a1a"))
		"melon":
			b.ico(MB.xf(), 1.25, 2, tx, 0.0, Callable(), true)
			b.cyl(MB.xf(0, 1.27, 0), 0.09, 0.07, 0.18, 6, Color(0.4, 0.28, 0.12, 0), true)
		"gold":
			b.ico(Transform3D(Basis.from_scale(Vector3(1.0, 0.92, 1.0)), Vector3.ZERO), 0.8, 2, tx, 0.0, Callable(), true)
			b.cyl(MB.xf(0, 0.82, 0), 0.05, 0.05, 0.3, 5, Color(0.55, 0.35, 0.1, 0), true)
			b.box(MB.xf(0.16, 0.9, 0), Vector3(0.3, 0.04, 0.16), Color(1.0, 0.95, 0.5, 0))
		"garlic":
			# 蒜头：扁球主体 + 一圈蒜瓣鼓包 + 顶部蒜梗 + 底部须根
			b.ico(Transform3D(Basis.from_scale(Vector3(1.0, 0.86, 1.0)), Vector3.ZERO), 0.7, 2, tx, 0.0, Callable(), true)
			for i in 6:
				var ga := TAU * i / 6.0
				var gt := Transform3D(Basis.from_scale(Vector3(0.58, 0.98, 0.58)),
					Vector3(cos(ga) * 0.34, 0.0, sin(ga) * 0.34))
				b.ico(gt, 0.62, 1, tx, 0.0, Callable(), true)
			b.cyl(MB.xf(0, 0.72, 0), 0.12, 0.025, 0.46, 6, Color(0.84, 0.81, 0.66, 0), true)
			b.cyl(MB.xf(0, -0.6, 0), 0.1, 0.02, 0.18, 5, Color(0.78, 0.74, 0.6, 0), true)
		"mine":
			b.ico(MB.xf(), 0.7, 2, tx, 0.0, Callable(), true)
			for v in MB.ico_verts():
				var dir: Vector3 = v
				var q := Quaternion(Vector3.UP, dir)
				b.cyl(Transform3D(Basis(q), dir * 0.88), 0.17, 0.0, 0.5, 6, Color(0.95, 0.2, 0.2, 0), true)
	return b.build()
