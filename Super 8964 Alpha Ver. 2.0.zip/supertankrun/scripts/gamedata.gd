class_name GameData
extends RefCounted
## 静态数据：涂装、升级、水果；以及由升级等级换算出的坦克数值。

## 天安门广场（经典 / 大蒜模式）的半径
const ARENA_RADIUS := 56.0
## 战场模式的半径（更大，容得下 6 辆坦克互殴）
const WAR_RADIUS := 88.0
## 当前这局实际使用的半径；开局时由 main.gd 按模式设置。
## 坦克/炮弹/水果的边界判定都读这个值。
static var arena_radius: float = ARENA_RADIUS

# ---- 战场模式数值 ----
const TANK_HP := 180.0
const SHELL_DAMAGE := 24.0        # 直击 8 发打爆一辆：被两辆车集火时还来得及脱离
const RAM_MIN_SPEED := 5.0        # 低于这个相对速度的碰撞不造成伤害
const RAM_DAMAGE := 3.2           # 每超出 1 单位相对速度的伤害
const RAM_DAMAGE_MAX := 40.0
const BATTLE_ENEMIES := 5         # 正好用上玩家之外的 5 种涂装
const BATTLE_TIME := 150.0
const BATTLE_KILL_SCORE := 1500
const BATTLE_WIN_BONUS := 5000
const BATTLE_SURVIVE_SCORE := 20  # 每存活一秒

## 大蒜模式：碰到/炸到几瓣大蒜就结束本局
const GARLIC_STRIKES := 3
## 每次压到/炸到大蒜扣的秒数
const GARLIC_TIME_PENALTY := 5.0
## 大蒜模式全程零失误的奖励分
const GARLIC_PERFECT_BONUS := 2000

const SKINS: Array = [
	{"id": "olive", "name": "数码迷彩", "price": 0, "camo": true, "body": "#4a5a2d", "trim": "#2d3a1c", "turret": "#7e7146", "accent": "#55482c"},
	{"id": "desert", "name": "沙漠黄", "price": 300, "body": "#c9a96a", "trim": "#9a7c44", "turret": "#d9bd7f", "accent": "#7a3b1d"},
	{"id": "arctic", "name": "极地白", "price": 650, "body": "#e6edf2", "trim": "#98adbf", "turret": "#f6fafc", "accent": "#2f7be0"},
	{"id": "pink", "name": "少女粉", "price": 1100, "body": "#ff7fb6", "trim": "#d9468a", "turret": "#ffa6cd", "accent": "#fff36b"},
	{"id": "cyber", "name": "赛博蓝", "price": 1800, "body": "#1d2a78", "trim": "#0a1145", "turret": "#2b3ca8", "accent": "#00f0ff"},
	{"id": "gold", "name": "土豪金", "price": 3500, "body": "#f2c230", "trim": "#b88a12", "turret": "#ffd95a", "accent": "#ff3b3b"},
]

# base: 1 级价格；每级 x1.5
const UPGRADES: Array = [
	{"id": "engine", "name": "发动机", "desc": "每级：最高速度 +7%，加速度 +10%", "base": 120, "max": 6},
	{"id": "tread", "name": "履带", "desc": "每级：转向 +7%，抓地力 +12%", "base": 100, "max": 6},
	{"id": "weight", "name": "压路辊", "desc": "每级：碾压范围 +5%，压碎西瓜所需速度 -0.9", "base": 140, "max": 6},
	{"id": "boost", "name": "涡轮增压", "desc": "每级：加速槽 +20%，回复 +15%，推力 +4%", "base": 130, "max": 6},
	{"id": "combo", "name": "连击计时器", "desc": "每级：连击窗口 +0.35 秒", "base": 110, "max": 6},
	{"id": "time", "name": "燃料箱", "desc": "每级：每局时间 +5 秒", "base": 160, "max": 6},
	{"id": "cannon", "name": "主炮", "desc": "每级：装填快 13%，炮弹初速 +9%", "base": 150, "max": 6},
	{"id": "shell", "name": "弹药架", "desc": "每级：弹仓 +1 发，爆炸范围 +10%", "base": 130, "max": 6},
	{"id": "turret", "name": "炮塔马达", "desc": "每级：炮塔转速 +16%", "base": 90, "max": 6},
]

const FRUITS: Dictionary = {
	"cherry": {"name": "樱桃", "r": 0.5, "pts": 50, "speed": 10.0, "weight": 26.0, "life": 30.0, "juice": "#d4163c"},
	"apple": {"name": "苹果", "r": 0.65, "pts": 100, "speed": 7.0, "weight": 34.0, "life": 32.0, "juice": "#e03a3a"},
	"orange": {"name": "橙子", "r": 0.75, "pts": 150, "speed": 9.0, "weight": 22.0, "life": 30.0, "juice": "#ff9a1f"},
	"banana": {"name": "香蕉", "r": 0.85, "pts": 250, "speed": 12.0, "weight": 12.0, "life": 26.0, "juice": "#ffe14d"},
	"melon": {"name": "西瓜", "r": 1.25, "pts": 500, "speed": 5.0, "weight": 9.0, "life": 40.0, "juice": "#ff4f6e", "heavy": true},
	"gold": {"name": "金苹果", "r": 0.8, "pts": 2000, "speed": 13.0, "weight": 3.0, "life": 13.0, "juice": "#ffd23a", "flee": true},
	"mine": {"name": "地雷", "r": 0.8, "pts": 0, "speed": 3.0, "weight": 0.0, "life": 40.0, "juice": "#ff7a1a", "bad": true},
	# 只在大蒜模式出现；weight 为 0，由 main.gd 的 _pick_kind 按模式临时加权
	"garlic": {"name": "大蒜", "r": 0.78, "pts": 0, "speed": 6.5, "weight": 0.0, "life": 38.0, "juice": "#efe9d6", "garlic": true},
}


static func skin_by_id(id: String) -> Dictionary:
	for s in SKINS:
		var d: Dictionary = s
		if d["id"] == id:
			return d
	return SKINS[0]


static func upgrade_cost(u: Dictionary, level: int) -> int:
	var c: float = float(u["base"]) * pow(1.5, level)
	return int(round(c / 5.0)) * 5


static func stats(up: Dictionary) -> Dictionary:
	var e: int = int(up.get("engine", 0))
	var t: int = int(up.get("tread", 0))
	var w: int = int(up.get("weight", 0))
	var b: int = int(up.get("boost", 0))
	var c: int = int(up.get("combo", 0))
	var tm: int = int(up.get("time", 0))
	var cn: int = int(up.get("cannon", 0))
	var sh: int = int(up.get("shell", 0))
	var tu: int = int(up.get("turret", 0))
	return {
		"max_speed": 13.0 * (1.0 + 0.07 * e),
		"accel": 22.0 * (1.0 + 0.10 * e),
		"turn": 2.4 * (1.0 + 0.07 * t),
		"grip": 5.0 * (1.0 + 0.12 * t),
		"radius": 1.55 * (1.0 + 0.05 * w),
		"crush_speed": maxf(5.0, 11.0 - 0.9 * w),
		"boost_max": 100.0 * (1.0 + 0.2 * b),
		"boost_regen": 18.0 * (1.0 + 0.15 * b),
		"boost_mul": 1.55 + 0.04 * b,
		"combo_window": 2.2 + 0.35 * c,
		"time": 60.0 + 5.0 * tm,
		# 主炮
		"reload": 1.6 / (1.0 + 0.13 * cn),
		"shell_speed": 44.0 * (1.0 + 0.09 * cn),
		"ammo_max": 3 + sh,
		"blast": 2.8 * (1.0 + 0.10 * sh),
		"traverse": 2.4 * (1.0 + 0.16 * tu),
	}
