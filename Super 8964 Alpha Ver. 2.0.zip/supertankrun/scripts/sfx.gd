class_name Sfx
extends Node
## 程序化合成的音效与背景音乐：没有任何音频文件，启动时用代码生成波形。

const RATE := 22050

var music_on := true
var _snd: Dictionary = {}
var _players: Array = []
var _pi := 0
var _engine: AudioStreamPlayer
var _music: AudioStreamPlayer
var _eng_db := -60.0


func _ready() -> void:
	for i in 10:
		var p := AudioStreamPlayer.new()
		add_child(p)
		_players.append(p)
	_snd["squish"] = _gen_squish()
	_snd["boom"] = _gen_boom()
	_snd["thud"] = _gen_thud()
	_snd["blip"] = _gen_tone(880.0, 0.06, 0.35, 1)
	_snd["beep"] = _gen_tone(660.0, 0.16, 0.4, 0)
	_snd["go"] = _gen_tone(990.0, 0.4, 0.4, 0)
	_snd["coin"] = _gen_arp([660.0, 880.0, 1100.0, 1320.0], 0.07)
	_snd["buy"] = _gen_arp([523.0, 659.0, 784.0, 1046.0], 0.06)
	_snd["no"] = _gen_tone(160.0, 0.15, 0.4, 1)
	_snd["bump"] = _gen_thud()
	_snd["fire"] = _gen_fire()
	_snd["stink"] = _gen_stink()
	_engine = AudioStreamPlayer.new()
	_engine.stream = _gen_engine()
	_engine.volume_db = -60.0
	add_child(_engine)
	_engine.play()
	_music = AudioStreamPlayer.new()
	_music.stream = _gen_music()
	_music.volume_db = -13.0
	add_child(_music)
	_music.play()


func toggle_music() -> void:
	music_on = not music_on
	_music.volume_db = -13.0 if music_on else -80.0


func play(name: String, pitch: float = 1.0, vol: float = 0.0) -> void:
	if not _snd.has(name) or _players.is_empty():
		return
	var p: AudioStreamPlayer = _players[_pi]
	_pi = (_pi + 1) % _players.size()
	p.stream = _snd[name]
	p.pitch_scale = pitch
	p.volume_db = vol
	p.play()


func set_engine(active: bool, frac: float, boosting: bool) -> void:
	var target := (-22.0 + frac * 9.0) if active else -60.0
	_eng_db = lerpf(_eng_db, target, 0.15)
	_engine.volume_db = _eng_db
	_engine.pitch_scale = 0.7 + frac * 1.1 + (0.35 if boosting else 0.0)


# ---------- 合成 ----------
func _wav(s: PackedFloat32Array, loop: bool = false) -> AudioStreamWAV:
	var w := AudioStreamWAV.new()
	w.format = AudioStreamWAV.FORMAT_16_BITS
	w.mix_rate = RATE
	w.stereo = false
	var bytes := PackedByteArray()
	bytes.resize(s.size() * 2)
	for i in s.size():
		bytes.encode_s16(i * 2, int(clampf(s[i], -1.0, 1.0) * 30000.0))
	w.data = bytes
	if loop:
		w.loop_mode = AudioStreamWAV.LOOP_FORWARD
		w.loop_begin = 0
		w.loop_end = s.size()
	return w


func _gen_squish() -> AudioStreamWAV:
	var n := int(RATE * 0.28)
	var s := PackedFloat32Array()
	s.resize(n)
	var rng := RandomNumberGenerator.new()
	rng.seed = 1
	var ph := 0.0
	var lp := 0.0
	for i in n:
		var t := float(i) / RATE
		ph += TAU * (190.0 * exp(-t * 9.0) + 70.0) / RATE
		var tone := sin(ph) * exp(-t * 14.0)
		lp += (rng.randf_range(-1.0, 1.0) - lp) * 0.25
		var noise := lp * exp(-t * 22.0) * 1.2
		var pop := sin(TAU * 900.0 * t) * exp(-t * 60.0) * 0.5
		s[i] = (tone * 0.8 + noise * 0.7 + pop) * 0.9
	return _wav(s)


func _gen_boom() -> AudioStreamWAV:
	var n := int(RATE * 0.7)
	var s := PackedFloat32Array()
	s.resize(n)
	var rng := RandomNumberGenerator.new()
	rng.seed = 2
	var lp := 0.0
	var ph := 0.0
	for i in n:
		var t := float(i) / RATE
		lp += (rng.randf_range(-1.0, 1.0) - lp) * (0.08 + 0.3 * exp(-t * 8.0))
		ph += TAU * (80.0 * exp(-t * 3.0) + 30.0) / RATE
		s[i] = (lp * 1.6 + sin(ph) * 0.8) * exp(-t * 5.0)
	return _wav(s)


## 踩到大蒜：两个失谐方波下滑，拍频听着就"冲鼻子"
func _gen_stink() -> AudioStreamWAV:
	var n := int(RATE * 0.5)
	var s := PackedFloat32Array()
	s.resize(n)
	var ph := 0.0
	var ph2 := 0.0
	for i in n:
		var t := float(i) / RATE
		var f := 300.0 * exp(-t * 1.5)
		ph += f / RATE
		ph2 += f * 1.055 / RATE # 失谐制造"酸臭"的拍音
		var a := 1.0 if fmod(ph, 1.0) < 0.5 else -1.0
		var b := 1.0 if fmod(ph2, 1.0) < 0.45 else -1.0
		s[i] = (a * 0.5 + b * 0.5) * 0.42 * exp(-t * 2.6)
	return _wav(s)


## 主炮开火：爆鸣 + 低频炮口冲击 + 短促的金属脆响
func _gen_fire() -> AudioStreamWAV:
	var n := int(RATE * 0.38)
	var s := PackedFloat32Array()
	s.resize(n)
	var rng := RandomNumberGenerator.new()
	rng.seed = 7
	var lp := 0.0
	var ph := 0.0
	for i in n:
		var t := float(i) / RATE
		lp += (rng.randf_range(-1.0, 1.0) - lp) * (0.13 + 0.5 * exp(-t * 32.0))
		ph += TAU * (165.0 * exp(-t * 20.0) + 58.0) / RATE
		var crack := sin(TAU * 1500.0 * t) * exp(-t * 95.0) * 0.35
		s[i] = (lp * 1.5 + sin(ph) * 0.95 + crack) * exp(-t * 9.5)
	return _wav(s)


func _gen_thud() -> AudioStreamWAV:
	var n := int(RATE * 0.18)
	var s := PackedFloat32Array()
	s.resize(n)
	var ph := 0.0
	for i in n:
		var t := float(i) / RATE
		ph += TAU * (110.0 * exp(-t * 14.0) + 45.0) / RATE
		s[i] = sin(ph) * exp(-t * 18.0)
	return _wav(s)


func _gen_tone(freq: float, dur: float, vol: float, wave: int) -> AudioStreamWAV:
	var n := int(RATE * dur)
	var s := PackedFloat32Array()
	s.resize(n)
	for i in n:
		var t := float(i) / RATE
		var ph := fmod(t * freq, 1.0)
		var v := (1.0 if ph < 0.5 else -1.0) if wave == 1 else sin(TAU * ph)
		s[i] = v * vol * exp(-t * (3.0 / maxf(dur, 0.05)))
	return _wav(s)


func _gen_arp(freqs: Array, step: float) -> AudioStreamWAV:
	var per := int(RATE * step)
	var n := per * freqs.size() + int(RATE * 0.15)
	var s := PackedFloat32Array()
	s.resize(n)
	for k in freqs.size():
		var f: float = freqs[k]
		for i in int(RATE * 0.2):
			var idx := k * per + i
			if idx >= n:
				break
			var t := float(i) / RATE
			s[idx] += (1.0 if fmod(t * f, 1.0) < 0.5 else -1.0) * 0.18 * exp(-t * 14.0)
	return _wav(s)


func _gen_engine() -> AudioStreamWAV:
	# 1 秒 55Hz，整数个周期，可无缝循环
	var n := RATE
	var s := PackedFloat32Array()
	s.resize(n)
	var lp := 0.0
	for i in n:
		var t := float(i) / RATE
		var saw := fmod(t * 55.0, 1.0) * 2.0 - 1.0
		var sq := 1.0 if fmod(t * 110.0, 1.0) < 0.5 else -1.0
		lp += ((saw * 0.7 + sq * 0.3) - lp) * 0.2
		s[i] = lp * 0.6
	return _wav(s, true)


func _add_note(buf: PackedFloat32Array, start: int, freq: float, dur: float, amp: float, duty: float, decay: float) -> void:
	var cnt := int(dur * RATE)
	for i in cnt:
		var idx := start + i
		if idx >= buf.size():
			return
		var t := float(i) / RATE
		var v := 1.0 if fmod(t * freq, 1.0) < duty else -1.0
		buf[idx] += v * amp * exp(-t * decay)


func _gen_music() -> AudioStreamWAV:
	var bpm := 132.0
	var step := 60.0 / bpm / 4.0
	var steps := 64
	var n := int(step * steps * RATE)
	var buf := PackedFloat32Array()
	buf.resize(n)
	var chords: Array = [[220.0, 261.63, 329.63], [174.61, 220.0, 261.63], [261.63, 329.63, 392.0], [196.0, 246.94, 293.66]]
	var roots: Array = [55.0, 43.65, 65.41, 49.0]
	var arp_idx: Array = [0, 1, 2, 1]
	var rng := RandomNumberGenerator.new()
	rng.seed = 5
	for s in steps:
		var bar := int(floor(s / 16.0))
		var sub := s % 16
		var t0 := int(s * step * RATE)
		if s % 4 == 0:
			var ph := 0.0
			for i in int(RATE * 0.16):
				var idx := t0 + i
				if idx >= n:
					break
				var t := float(i) / RATE
				ph += TAU * (130.0 * exp(-t * 28.0) + 42.0) / RATE
				buf[idx] += sin(ph) * 0.5 * exp(-t * 14.0)
		if s % 2 == 1:
			for i in int(RATE * 0.04):
				var idx2 := t0 + i
				if idx2 >= n:
					break
				buf[idx2] += rng.randf_range(-1.0, 1.0) * 0.07 * exp(-float(i) / RATE * 70.0)
		if s % 2 == 0:
			var root: float = roots[bar]
			_add_note(buf, t0, root * (2.0 if sub % 8 == 6 else 1.0), step * 1.7, 0.13, 0.5, 6.0)
		var ch: Array = chords[bar]
		var nf: float = ch[arp_idx[s % 4]] * (2.0 if sub >= 8 else 1.0)
		_add_note(buf, t0, nf, step * 1.8, 0.055, 0.25, 13.0)
	return _wav(buf, true)
