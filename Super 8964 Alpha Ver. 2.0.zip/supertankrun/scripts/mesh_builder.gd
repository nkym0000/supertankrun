class_name MB
extends RefCounted
## 低多边形网格生成器：三角形 + 法线 + 顶点色 + UV。
## 约定：所有 add 函数接收"从外侧看逆时针"的三角形，内部转成 Godot 要求的顺时针。
## 圆形物体可用 smooth=true 输出平滑法线（Gouraud 渐变），方块保持平面法线。

static var _ico_cache: Dictionary = {}

var verts := PackedVector3Array()
var norms := PackedVector3Array()
var cols := PackedColorArray()
var uvs := PackedVector2Array()


static func xf(x: float = 0.0, y: float = 0.0, z: float = 0.0) -> Transform3D:
	return Transform3D(Basis.IDENTITY, Vector3(x, y, z))


## 朝上的方形面片（阴影/污渍/履带印），UV 0..1，中心在原点。
static func ground_quad(half_x: float, half_z: float) -> ArrayMesh:
	var b := MB.new()
	b.quad_uv(Vector3(-half_x, 0, -half_z), Vector3(-half_x, 0, half_z), Vector3(half_x, 0, half_z), Vector3(half_x, 0, -half_z),
		Color.WHITE, Vector2(0, 0), Vector2(0, 1), Vector2(1, 1), Vector2(1, 0))
	return b.build()


# ---------- 基础 ----------
func _push(p: Vector3, n: Vector3, c: Color, uv: Vector2) -> void:
	verts.push_back(p)
	norms.push_back(n)
	cols.push_back(c)
	uvs.push_back(uv)


func tri(a: Vector3, b: Vector3, c: Vector3, col: Color, ua: Vector2 = Vector2.ZERO, ub: Vector2 = Vector2.ZERO, uc: Vector2 = Vector2.ZERO) -> void:
	var n := (b - a).cross(c - a)
	if n.length_squared() < 1e-10:
		return
	n = n.normalized()
	_push(a, n, col, ua)
	_push(c, n, col, uc)
	_push(b, n, col, ub)


func tri_n(a: Vector3, b: Vector3, c: Vector3, na: Vector3, nb: Vector3, nc: Vector3, col: Color) -> void:
	if (b - a).cross(c - a).length_squared() < 1e-10:
		return
	_push(a, na, col, Vector2.ZERO)
	_push(c, nc, col, Vector2.ZERO)
	_push(b, nb, col, Vector2.ZERO)


## 每顶点独立颜色（地形的平滑色彩渐变）
func tri_nc(a: Vector3, b: Vector3, c: Vector3, na: Vector3, nb: Vector3, nc: Vector3, ca: Color, cb: Color, cc: Color) -> void:
	if (b - a).cross(c - a).length_squared() < 1e-10:
		return
	_push(a, na, ca, Vector2.ZERO)
	_push(c, nc, cc, Vector2.ZERO)
	_push(b, nb, cb, Vector2.ZERO)


func tri_away(a: Vector3, b: Vector3, c: Vector3, col: Color, origin: Vector3) -> void:
	var n := (b - a).cross(c - a)
	if n.dot((a + b + c) / 3.0 - origin) < 0.0:
		tri(a, c, b, col)
	else:
		tri(a, b, c, col)


func tri_n_away(a: Vector3, b: Vector3, c: Vector3, na: Vector3, nb: Vector3, nc: Vector3, col: Color, origin: Vector3) -> void:
	var n := (b - a).cross(c - a)
	if n.dot((a + b + c) / 3.0 - origin) < 0.0:
		tri_n(a, c, b, na, nc, nb, col)
	else:
		tri_n(a, b, c, na, nb, nc, col)


func quad(a: Vector3, b: Vector3, c: Vector3, d: Vector3, col: Color) -> void:
	tri(a, b, c, col)
	tri(a, c, d, col)


func quad_uv(a: Vector3, b: Vector3, c: Vector3, d: Vector3, col: Color, ua: Vector2, ub: Vector2, uc: Vector2, ud: Vector2) -> void:
	tri(a, b, c, col, ua, ub, uc)
	tri(a, c, d, col, ua, uc, ud)


## p: 8 个角点，索引 = x | y<<1 | z<<2 （bit=1 为正方向）
func hexa(p: Array, col: Color) -> void:
	quad(p[5], p[1], p[3], p[7], col) # +X
	quad(p[0], p[4], p[6], p[2], col) # -X
	quad(p[2], p[6], p[7], p[3], col) # +Y
	quad(p[0], p[1], p[5], p[4], col) # -Y
	quad(p[4], p[5], p[7], p[6], col) # +Z
	quad(p[0], p[2], p[3], p[1], col) # -Z


func box(t: Transform3D, size: Vector3, col: Color) -> void:
	wedge(t, size, 0.0, col)


## 长方体，前上沿(+Z,+Y)向后削 slope（斜面装甲），顶面可按 top_scale 收窄。
func wedge(t: Transform3D, size: Vector3, slope: float, col: Color, top_scale: float = 1.0) -> void:
	var h := size * 0.5
	var p: Array = []
	for i in 8:
		var x: float = h.x if (i & 1) != 0 else -h.x
		var y: float = h.y if (i & 2) != 0 else -h.y
		var z: float = h.z if (i & 4) != 0 else -h.z
		if (i & 2) != 0:
			x *= top_scale
			if (i & 4) != 0:
				z -= slope
		p.push_back(t * Vector3(x, y, z))
	hexa(p, col)


## 圆柱/圆锥，轴向局部 Y，居中。smooth=true 时侧面用平滑法线。
func cyl(t: Transform3D, r_bot: float, r_top: float, h: float, seg: int, col: Color, smooth: bool = false) -> void:
	var y0 := -h * 0.5
	var y1 := h * 0.5
	var cb := t * Vector3(0, y0, 0)
	var ct := t * Vector3(0, y1, 0)
	var slope := (r_bot - r_top) / maxf(h, 0.0001)
	for i in seg:
		var a0 := TAU * i / seg
		var a1 := TAU * (i + 1) / seg
		var b0 := t * Vector3(cos(a0) * r_bot, y0, sin(a0) * r_bot)
		var b1 := t * Vector3(cos(a1) * r_bot, y0, sin(a1) * r_bot)
		var t0 := t * Vector3(cos(a0) * r_top, y1, sin(a0) * r_top)
		var t1 := t * Vector3(cos(a1) * r_top, y1, sin(a1) * r_top)
		if smooth:
			var n0 := (t.basis * Vector3(cos(a0), slope, sin(a0))).normalized()
			var n1 := (t.basis * Vector3(cos(a1), slope, sin(a1))).normalized()
			tri_n(b0, t0, t1, n0, n0, n1, col)
			tri_n(b0, t1, b1, n0, n1, n1, col)
		else:
			quad(b0, t0, t1, b1, col)
		tri(ct, t1, t0, col)
		tri(cb, b0, b1, col)


static func ico_unit(detail: int) -> Array:
	if _ico_cache.has(detail):
		return _ico_cache[detail]
	var v: Array = ico_verts()
	var f: Array = [
		[0, 11, 5], [0, 5, 1], [0, 1, 7], [0, 7, 10], [0, 10, 11],
		[1, 5, 9], [5, 11, 4], [11, 10, 2], [10, 7, 6], [7, 1, 8],
		[3, 9, 4], [3, 4, 2], [3, 2, 6], [3, 6, 8], [3, 8, 9],
		[4, 9, 5], [2, 4, 11], [6, 2, 10], [8, 6, 7], [9, 8, 1]]
	var tris: Array = []
	for fi in f:
		tris.append([v[fi[0]], v[fi[1]], v[fi[2]]])
	for d in detail:
		var nt: Array = []
		for tr in tris:
			var a: Vector3 = tr[0]
			var b: Vector3 = tr[1]
			var c: Vector3 = tr[2]
			var ab := ((a + b) * 0.5).normalized()
			var bc := ((b + c) * 0.5).normalized()
			var ca := ((c + a) * 0.5).normalized()
			nt.append([a, ab, ca])
			nt.append([b, bc, ab])
			nt.append([c, ca, bc])
			nt.append([ab, bc, ca])
		tris = nt
	_ico_cache[detail] = tris
	return tris


static func ico_verts() -> Array:
	var t := (1.0 + sqrt(5.0)) / 2.0
	var raw: Array = [
		Vector3(-1, t, 0), Vector3(1, t, 0), Vector3(-1, -t, 0), Vector3(1, -t, 0),
		Vector3(0, -1, t), Vector3(0, 1, t), Vector3(0, -1, -t), Vector3(0, 1, -t),
		Vector3(t, 0, -1), Vector3(t, 0, 1), Vector3(-t, 0, -1), Vector3(-t, 0, 1)]
	var out: Array = []
	for r in raw:
		var rv: Vector3 = r
		out.append(rv.normalized())
	return out


## 二十面体球。jitter: 每个面随机明暗；col_fn(dir)->Color 可覆盖颜色；smooth: 平滑法线。
func ico(t: Transform3D, radius: float, detail: int, col: Color, jitter: float = 0.0, col_fn: Callable = Callable(), smooth: bool = false) -> void:
	for tr in MB.ico_unit(detail):
		var a: Vector3 = tr[0]
		var b: Vector3 = tr[1]
		var c: Vector3 = tr[2]
		var fc := col
		if col_fn.is_valid():
			fc = col_fn.call((a + b + c).normalized())
		if jitter > 0.0:
			var k := 1.0 + randf_range(-jitter, jitter)
			fc = Color(fc.r * k, fc.g * k, fc.b * k, fc.a)
		if smooth:
			tri_n_away(t * (a * radius), t * (b * radius), t * (c * radius),
				(t.basis * a).normalized(), (t.basis * b).normalized(), (t.basis * c).normalized(), fc, t.origin)
		else:
			tri_away(t * (a * radius), t * (b * radius), t * (c * radius), fc, t.origin)


## 弧形管（香蕉），平滑法线。路径在 XZ 平面，弧长 arc。
func arc_tube(t: Transform3D, big_r: float, r: float, arc: float, ring_seg: int, path_seg: int, col: Color, tip_col: Color) -> void:
	var rings: Array = []
	var nrms: Array = []
	var centers: Array = []
	for i in path_seg + 1:
		var u := float(i) / path_seg
		var th := lerpf(-arc * 0.5, arc * 0.5, u)
		var d := Vector3(sin(th), 0.0, cos(th))
		var c := d * big_r
		var rr := r * (0.5 + 0.5 * sin(PI * u)) + r * 0.12
		var ring: Array = []
		var nr: Array = []
		for j in ring_seg:
			var ph := TAU * j / ring_seg
			var off := d * (cos(ph) * rr) + Vector3.UP * (sin(ph) * rr)
			ring.append(t * (c + off))
			nr.append((t.basis * off).normalized())
		rings.append(ring)
		nrms.append(nr)
		centers.append(t * c)
	for i in path_seg:
		var u2 := (float(i) + 0.5) / path_seg
		var cc := tip_col if (u2 < 0.12 or u2 > 0.88) else col
		for j in ring_seg:
			var j2 := (j + 1) % ring_seg
			var o: Vector3 = ((centers[i] as Vector3) + (centers[i + 1] as Vector3)) * 0.5
			tri_n_away(rings[i][j], rings[i + 1][j], rings[i + 1][j2], nrms[i][j], nrms[i + 1][j], nrms[i + 1][j2], cc, o)
			tri_n_away(rings[i][j], rings[i + 1][j2], rings[i][j2], nrms[i][j], nrms[i + 1][j2], nrms[i][j2], cc, o)
	for end_i in [0, path_seg]:
		var ring_e: Array = rings[end_i]
		var ctr: Vector3 = centers[end_i]
		var out_dir: Vector3 = (ctr - (centers[path_seg - end_i] as Vector3)).normalized()
		for j in ring_seg:
			tri_away(ctr, ring_e[j], ring_e[(j + 1) % ring_seg], tip_col, ctr - out_dir * 0.5)


func build() -> ArrayMesh:
	var m := ArrayMesh.new()
	if verts.size() == 0:
		return m
	var arrays := []
	arrays.resize(Mesh.ARRAY_MAX)
	arrays[Mesh.ARRAY_VERTEX] = verts
	arrays[Mesh.ARRAY_NORMAL] = norms
	arrays[Mesh.ARRAY_COLOR] = cols
	arrays[Mesh.ARRAY_TEX_UV] = uvs
	m.add_surface_from_arrays(Mesh.PRIMITIVE_TRIANGLES, arrays)
	return m
