class_name Shell
extends Node3D
## 主炮炮弹：直线飞行并缓慢下坠，碰到水果/障碍/地面/场地边界就引爆。
## 命中判定在 main.gd 里做（只比较 XZ 平面距离，街机手感）。

const DROP := 1.5     # 每秒下坠，使弹道从炮口高度自然落到水果高度
const MAX_AGE := 3.0

var vel := Vector3.ZERO
var blast := 2.8
var age := 0.0
var done := false
## 对战模式：谁打出来的（自己的炮弹不伤自己）
var shooter: Node3D = null
var damage := GameData.SHELL_DAMAGE

static var _mesh: ArrayMesh = null


func setup(dir: Vector3, speed: float, blast_r: float) -> void:
	blast = blast_r
	vel = dir * speed + Vector3(0.0, -DROP, 0.0)
	rotation.y = atan2(dir.x, dir.z)
	var mi := MeshInstance3D.new()
	mi.mesh = Shell.mesh()
	mi.material_override = Mats.lp("shell", "metal", 1, 0.9)
	add_child(mi)


func step(dt: float) -> void:
	age += dt
	position += vel * dt
	if position.y <= 0.35 or age > MAX_AGE:
		done = true
		return
	if Vector2(position.x, position.z).length() > GameData.arena_radius - 0.6:
		done = true


static func mesh() -> ArrayMesh:
	if _mesh != null:
		return _mesh
	var b := MB.new()
	var body := Color("#5d5c40")
	var tip := Color("#8d7430")
	b.cyl(Transform3D(Basis(Vector3.RIGHT, PI / 2.0), Vector3(0, 0, -0.12)), 0.13, 0.13, 0.44, 8, body, true)
	b.cyl(Transform3D(Basis(Vector3.RIGHT, PI / 2.0), Vector3(0, 0, 0.25)), 0.13, 0.0, 0.3, 8, tip, true)
	_mesh = b.build()
	return _mesh
