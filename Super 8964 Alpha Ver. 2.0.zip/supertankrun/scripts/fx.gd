class_name FX
extends Node3D
## 特效池（全部循环复用）：公告牌粒子（果汁块/烟/星光）、贴图果汁污渍、履带印。

const MAX_P := 170
const MAX_SPLAT := 70
const MAX_MARK := 120

var _pn: Array = []
var _pv: Array = []
var _pl: Array = []
var _pm: Array = []
var _pg: Array = []
var _ps: Array = []
var _pmat: Array = []
var _pi := 0

var _sn: Array = []
var _sl: Array = []
var _smat: Array = []
var _si := 0

var _mn: Array = []
var _ml: Array = []
var _mmat: Array = []
var _mi := 0


func _ready() -> void:
	var quad := QuadMesh.new()
	quad.size = Vector2.ONE
	for i in MAX_P:
		var n := MeshInstance3D.new()
		n.mesh = quad
		var m := Mats.fx("chip", true)
		m.billboard_keep_scale = true
		n.material_override = m
		n.visible = false
		add_child(n)
		_pn.append(n)
		_pmat.append(m)
		_pv.append(Vector3.ZERO)
		_pl.append(0.0)
		_pm.append(1.0)
		_pg.append(0.0)
		_ps.append(0.2)
	var splat_mesh := MB.ground_quad(1.0, 1.0)
	for i in MAX_SPLAT:
		var n2 := MeshInstance3D.new()
		n2.mesh = splat_mesh
		var m2 := Mats.fx("splat%d" % (i % 4))
		n2.material_override = m2
		n2.visible = false
		add_child(n2)
		_sn.append(n2)
		_smat.append(m2)
		_sl.append(0.0)
	var mark_mesh := MB.ground_quad(0.24, 0.6)
	for i in MAX_MARK:
		var n3 := MeshInstance3D.new()
		n3.mesh = mark_mesh
		var m3 := Mats.fx("mark")
		n3.material_override = m3
		n3.visible = false
		add_child(n3)
		_mn.append(n3)
		_mmat.append(m3)
		_ml.append(0.0)


func clear() -> void:
	for i in MAX_P:
		_pl[i] = 0.0
		(_pn[i] as Node3D).visible = false
	for i in MAX_SPLAT:
		_sl[i] = 0.0
		(_sn[i] as Node3D).visible = false
	for i in MAX_MARK:
		_ml[i] = 0.0
		(_mn[i] as Node3D).visible = false


func emit(pos: Vector3, v: Vector3, col: Color, size: float, life: float, grav: float, tex: String = "chip") -> void:
	var i := _pi
	_pi = (_pi + 1) % MAX_P
	var n: Node3D = _pn[i]
	n.position = pos
	n.visible = true
	n.scale = Vector3.ONE * size
	var m: StandardMaterial3D = _pmat[i]
	m.albedo_texture = Tex.get_tex(tex)
	m.albedo_color = col
	_pv[i] = v
	_pl[i] = life
	_pm[i] = life
	_pg[i] = grav
	_ps[i] = size


func burst(pos: Vector3, col: Color, count: int, speed: float, size: float = 0.4, grav: float = 20.0) -> void:
	for k in count:
		var dir := Vector3(randf_range(-1, 1), randf_range(0.2, 1.4), randf_range(-1, 1)).normalized()
		var c := col.lightened(randf_range(-0.12, 0.2))
		emit(pos + Vector3(0, 0.3, 0), dir * speed * randf_range(0.4, 1.0), c, size * randf_range(0.6, 1.3), randf_range(0.45, 0.9), grav, "chip")
	# 几颗星光
	for k in maxi(2, count / 4):
		var dir2 := Vector3(randf_range(-1, 1), randf_range(0.5, 1.5), randf_range(-1, 1)).normalized()
		emit(pos + Vector3(0, 0.6, 0), dir2 * speed * 0.6, Color(1, 1, 0.8), size * 2.4, randf_range(0.3, 0.55), 6.0, "spark")


func puff(pos: Vector3, col: Color, size: float, up: float, life: float = 0.6) -> void:
	emit(pos, Vector3(randf_range(-0.6, 0.6), up, randf_range(-0.6, 0.6)), col, size * 2.0, life, -1.0, "puff")


func splat(pos: Vector3, col: Color, size: float) -> void:
	var i := _si
	_si = (_si + 1) % MAX_SPLAT
	var n: Node3D = _sn[i]
	n.position = Vector3(pos.x, 0.035 + (i % 12) * 0.002, pos.z)
	n.rotation.y = randf() * TAU
	n.scale = Vector3(size * 1.6, 1.0, size * 1.6)
	n.visible = true
	var c := col
	c.a = 1.0
	(_smat[i] as StandardMaterial3D).albedo_color = c
	_sl[i] = 28.0


func tread_mark(pos: Vector3, heading: float) -> void:
	var i := _mi
	_mi = (_mi + 1) % MAX_MARK
	var n: Node3D = _mn[i]
	n.position = Vector3(pos.x, 0.025, pos.z)
	n.rotation.y = heading
	n.visible = true
	_ml[i] = 6.0
	(_mmat[i] as StandardMaterial3D).albedo_color.a = 1.0


func step(dt: float) -> void:
	for i in MAX_P:
		var life: float = _pl[i]
		if life <= 0.0:
			continue
		life -= dt
		_pl[i] = life
		var n: Node3D = _pn[i]
		if life <= 0.0:
			n.visible = false
			continue
		var v: Vector3 = _pv[i]
		var g: float = _pg[i]
		v.y -= g * dt
		n.position += v * dt
		if g > 0.0 and n.position.y < 0.08:
			n.position.y = 0.08
			v.y = absf(v.y) * 0.3
			v.x *= 0.6
			v.z *= 0.6
		_pv[i] = v
		var k := clampf(life / float(_pm[i]) * 1.6, 0.0, 1.0)
		var s: float = _ps[i]
		var m: StandardMaterial3D = _pmat[i]
		if g < 0.0:
			# 烟雾：越飘越大、越淡
			n.scale = Vector3.ONE * s * (1.8 - k * 0.8)
			m.albedo_color.a = k * 0.7
		else:
			n.scale = Vector3.ONE * s * (0.4 + k * 0.6)
			m.albedo_color.a = clampf(k * 1.4, 0.0, 1.0)
	for i in MAX_SPLAT:
		var sl: float = _sl[i]
		if sl <= 0.0:
			continue
		sl -= dt
		_sl[i] = sl
		if sl <= 0.0:
			(_sn[i] as Node3D).visible = false
		elif sl < 6.0:
			(_smat[i] as StandardMaterial3D).albedo_color.a = sl / 6.0
	for i in MAX_MARK:
		var ml: float = _ml[i]
		if ml <= 0.0:
			continue
		ml -= dt
		_ml[i] = ml
		if ml <= 0.0:
			(_mn[i] as Node3D).visible = false
		elif ml < 2.0:
			(_mmat[i] as StandardMaterial3D).albedo_color.a = ml / 2.0
