extends Node
## 游戏主控：状态机、驾驶/碰撞/压扁/连击、主炮、摄像机、车库与存档的接线。
##
## 画面：3D 世界渲染在缩小 PIXEL_SHRINK 倍的 SubViewport 里，再用双线性放大 -> 复古低分辨率。

enum S { TITLE, GARAGE, COUNTDOWN, PLAYING, ENDING, RESULTS, PAUSED }
## CLASSIC = 原来的玩法；GARLIC = 大蒜模式（场上混入大蒜，碰到/炸到都算失误，三次结束）
## BATTLE = 战场对战（更大的场地、满地掩体、6 辆坦克混战，最后站着的赢）
enum MODE { CLASSIC, GARLIC, BATTLE }

const PIXEL_SHRINK := 3 # 1280x720 窗口 -> 427x240 内部分辨率（N64 级）；数字越大越"糊"
const PENTA := [0, 2, 4, 7, 9]

var state: int = S.TITLE
var resume_state: int = S.PLAYING
var mode: int = MODE.CLASSIC

var svc: SubViewportContainer
var vp: SubViewport
var cam: Camera3D
var arena: Arena
var tank: Tank
var fx: FX
var fruit_root: Node3D
var shell_root: Node3D
var ui: GameUI
var sfx: Sfx

var fruits: Array = []
var shells: Array = []
var stats: Dictionary = {}
var orbit := 0.0
var cam_heading := 0.0
var shake := 0.0
var cam_hoff := 0.0

# 一局的状态
var score := 0
var time_left := 60.0
var run_time := 0.0
var combo := 0
var combo_t := 0.0
var mult := 1
var max_combo := 0
var squashed := 0
var strikes := 0
var by_kind: Dictionary = {}
var cd := 0.0
var cd_shown := -1
var spawn_t := 0.0
var ending_t := 0.0
var tread_acc := 0.0
var smoke_t := 0.0
var hinted_melon := false

# 主炮
var ammo := 3
var reload_t := 0.0
var aim_world := 0.0
var want_fire := false

# 对战模式
var enemies: Array = []   # Tank
var ais: Array = []       # TankAI（与 enemies 一一对应）
var kills := 0
var battle_over := false
var survive_acc := 0.0    # 生存分的小数余量（每帧 int() 会被截成 0）
var player_ai: TankAI = null   # 仅自动测试时用来替玩家开车
var _bot_act: Dictionary = {}

# 自动测试（命令行：-- --autoplay --shots=/some/dir）
var autoplay := false
var shot_dir := ""
var showcase := false
var _auto_t := 0.0
var _auto_stage := 0


func _ready() -> void:
	SaveGame.load_game()
	_setup_input()
	_build_viewport()
	ui = GameUI.new()
	add_child(ui)
	sfx = Sfx.new()
	add_child(sfx)
	ui.clicked.connect(func(): sfx.play("blip"))
	# play/retry 沿用当前模式（车库的"出击"、结算的"再来一局"）；标题上的两个按钮显式选模式
	ui.play_pressed.connect(func(): ui.fade_to(_start_run))
	ui.retry_pressed.connect(func(): ui.fade_to(_start_run))
	ui.classic_pressed.connect(func():
		mode = MODE.CLASSIC
		ui.fade_to(_start_run))
	ui.garlic_pressed.connect(func():
		mode = MODE.GARLIC
		ui.fade_to(_start_run))
	ui.battle_pressed.connect(func():
		mode = MODE.BATTLE
		ui.fade_to(_start_run))
	ui.garage_pressed.connect(func(): ui.fade_to(_enter_garage))
	ui.title_pressed.connect(func(): ui.fade_to(_enter_title))
	ui.resume_pressed.connect(_toggle_pause)
	ui.skin_preview.connect(func(id: String): tank.apply_skin(id))
	ui.skin_buy.connect(_buy_skin)
	ui.skin_equip.connect(_equip_skin)
	ui.upgrade_buy.connect(_buy_upgrade)
	for a in OS.get_cmdline_user_args():
		if a == "--autoplay":
			autoplay = true
		elif a == "--showcase":
			showcase = true
		elif a == "--garlic":
			mode = MODE.GARLIC
		elif a == "--battle":
			mode = MODE.BATTLE
		elif a.begins_with("--shots="):
			shot_dir = a.substr(8)
	tank.apply_skin(SaveGame.skin)
	_enter_title()
	if showcase:
		_make_showcase()


# ============================================================ 搭建
func _build_viewport() -> void:
	svc = SubViewportContainer.new()
	svc.stretch = true
	svc.stretch_shrink = PIXEL_SHRINK
	svc.texture_filter = CanvasItem.TEXTURE_FILTER_LINEAR # 双线性放大 = N64 的柔和画面
	var post := ShaderMaterial.new()
	post.shader = load("res://shaders/n64_post.gdshader")
	svc.material = post
	svc.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	add_child(svc)
	vp = SubViewport.new()
	vp.msaa_3d = Viewport.MSAA_DISABLED
	svc.add_child(vp)
	_ensure_arena(Arena.KIND.PLAZA)
	fruit_root = Node3D.new()
	vp.add_child(fruit_root)
	shell_root = Node3D.new()
	vp.add_child(shell_root)
	tank = Tank.new()
	vp.add_child(tank)
	fx = FX.new()
	vp.add_child(fx)
	cam = Camera3D.new()
	cam.fov = 60.0
	cam.near = 0.3
	cam.far = 520.0
	vp.add_child(cam)
	cam.current = true
	cam.position = Vector3(0, 5, 12)


## 按模式换场景。半径必须在 Arena._ready() 之前设好，因为场景建造要用到它。
func _ensure_arena(k: int) -> void:
	if arena != null and arena.kind == k:
		return
	if arena != null:
		arena.queue_free()
		arena = null
	GameData.arena_radius = GameData.WAR_RADIUS if k == Arena.KIND.WAR else GameData.ARENA_RADIUS
	arena = Arena.new()
	arena.kind = k
	vp.add_child(arena)
	vp.move_child(arena, 0)


func _setup_input() -> void:
	_act("accel", [KEY_W, KEY_UP])
	_act("brake", [KEY_S, KEY_DOWN])
	_act("left", [KEY_A, KEY_LEFT])
	_act("right", [KEY_D, KEY_RIGHT])
	_act("boost", [KEY_SHIFT, KEY_SPACE])
	_act("pause", [KEY_ESCAPE, KEY_P])
	_act("music", [KEY_M])
	_act("confirm", [KEY_ENTER, KEY_KP_ENTER])
	_act("fire", [KEY_E])
	_mouse_btn("fire", MOUSE_BUTTON_LEFT)
	_joy_btn("fire", JOY_BUTTON_X)
	_joy_axis("fire", JOY_AXIS_TRIGGER_RIGHT, 1.0)
	_joy_axis("accel", JOY_AXIS_LEFT_Y, -1.0)
	_joy_axis("brake", JOY_AXIS_LEFT_Y, 1.0)
	_joy_axis("left", JOY_AXIS_LEFT_X, -1.0)
	_joy_axis("right", JOY_AXIS_LEFT_X, 1.0)
	_joy_btn("boost", JOY_BUTTON_A)
	_joy_btn("boost", JOY_BUTTON_RIGHT_SHOULDER)
	_joy_btn("pause", JOY_BUTTON_START)
	_joy_btn("confirm", JOY_BUTTON_A)


func _act(action: String, keys: Array) -> void:
	if not InputMap.has_action(action):
		InputMap.add_action(action)
	for k in keys:
		var e := InputEventKey.new()
		e.physical_keycode = k
		InputMap.action_add_event(action, e)


func _joy_axis(action: String, axis: int, value: float) -> void:
	var e := InputEventJoypadMotion.new()
	e.axis = axis
	e.axis_value = value
	InputMap.action_add_event(action, e)


func _joy_btn(action: String, btn: int) -> void:
	var e := InputEventJoypadButton.new()
	e.button_index = btn
	InputMap.action_add_event(action, e)


func _mouse_btn(action: String, btn: int) -> void:
	var e := InputEventMouseButton.new()
	e.button_index = btn
	InputMap.action_add_event(action, e)


# ============================================================ 状态切换
func _clear_fruits() -> void:
	for f in fruits:
		(f as Node).queue_free()
	fruits.clear()


func _clear_shells() -> void:
	for s in shells:
		(s as Node).queue_free()
	shells.clear()


func _clear_enemies() -> void:
	for e in enemies:
		(e as Node).queue_free()
	enemies.clear()
	ais.clear()


## 生成 5 辆敌方坦克，各用一种与玩家不同的涂装，放在场地外圈的出生点上
func _spawn_enemies() -> void:
	_clear_enemies()
	var spawns: Array = arena.spawns
	if spawns.is_empty():
		return
	# 玩家占第一个出生点
	tank.position = spawns[0]
	tank.heading = atan2(-tank.position.x, -tank.position.z) # 朝场地中心
	tank.turret_world = tank.heading
	tank.aim_world = tank.heading
	aim_world = tank.heading
	var skins: Array = []
	for s in GameData.SKINS:
		var sd: Dictionary = s
		if str(sd["id"]) != SaveGame.skin:
			skins.append(str(sd["id"]))
	var n: int = mini(GameData.BATTLE_ENEMIES, mini(skins.size(), spawns.size() - 1))
	for i in n:
		var e := Tank.new()
		e.is_enemy = true
		e.stats = stats
		vp.add_child(e)
		e.apply_skin(skins[i])
		e.reset_health()
		e.position = spawns[i + 1]
		e.heading = atan2(-e.position.x, -e.position.z)
		e.turret_world = e.heading
		e.aim_world = e.heading
		e.boost = float(stats["boost_max"])
		e.traverse = float(stats["traverse"])
		enemies.append(e)
		# 难度递增：后面出场的更准更猛
		ais.append(TankAI.new(e, 0.45 + 0.1 * float(i)))


func _enter_title() -> void:
	state = S.TITLE
	_ensure_arena(Arena.KIND.PLAZA) # 菜单背景永远是广场
	_clear_fruits()
	_clear_shells()
	_clear_enemies()
	fx.clear()
	tank.reset_health()
	tank.visible = true
	tank.apply_skin(SaveGame.skin)
	tank.position = Vector3.ZERO
	tank.heading = 0.0
	tank.vel = Vector3.ZERO
	tank.fwd_speed = 0.0
	tank.turret_world = 0.0
	tank.aim_world = 0.0
	ui.show_screen("title")


func _enter_garage() -> void:
	state = S.GARAGE
	_ensure_arena(Arena.KIND.PLAZA)
	_clear_fruits()
	_clear_shells()
	_clear_enemies()
	fx.clear()
	tank.reset_health()
	tank.visible = true
	tank.position = Vector3.ZERO
	tank.heading = 0.0
	tank.vel = Vector3.ZERO
	tank.fwd_speed = 0.0
	tank.turret_world = 0.0
	tank.aim_world = 0.0
	ui.preview_id = SaveGame.skin
	ui.tab = 0
	ui.show_screen("garage")
	ui.refresh_garage()


func _start_run() -> void:
	_ensure_arena(Arena.KIND.WAR if mode == MODE.BATTLE else Arena.KIND.PLAZA)
	stats = GameData.stats(SaveGame.up)
	tank.stats = stats
	tank.apply_skin(SaveGame.skin)
	tank.reset_health()
	tank.visible = true
	tank.position = Vector3.ZERO
	tank.heading = 0.0
	tank.vel = Vector3.ZERO
	tank.fwd_speed = 0.0
	tank.boost = float(stats["boost_max"])
	tank.stun = 0.0
	tank.turret_world = 0.0
	tank.aim_world = 0.0
	tank.recoil = 0.0
	cam_heading = 0.0
	score = 0
	time_left = float(stats["time"])
	run_time = 0.0
	combo = 0
	combo_t = 0.0
	mult = 1
	max_combo = 0
	squashed = 0
	strikes = 0
	by_kind = {}
	spawn_t = 0.0
	ending_t = 0.0
	hinted_melon = false
	cd = 3.0
	cd_shown = -1
	ammo = int(stats["ammo_max"])
	reload_t = float(stats["reload"])
	aim_world = 0.0
	kills = 0
	battle_over = false
	survive_acc = 0.0
	_clear_fruits()
	_clear_shells()
	_clear_enemies()
	fx.clear()
	player_ai = null
	if mode == MODE.BATTLE:
		time_left = GameData.BATTLE_TIME
		_spawn_enemies()
		if autoplay:
			player_ai = TankAI.new(tank, 0.8)
	else:
		for i in 12:
			_spawn_fruit(_pick_kind(false), false, true)
	ui.reset_hud()
	ui.show_screen("hud")
	state = S.COUNTDOWN
	_update_camera(0.0, true)


func _toggle_pause() -> void:
	if state == S.PAUSED:
		state = resume_state
		ui.show_screen("hud")
	elif state == S.PLAYING or state == S.COUNTDOWN:
		resume_state = state
		state = S.PAUSED
		ui.show_screen("pause")
		sfx.set_engine(false, 0.0, false)


func _notification(what: int) -> void:
	# 自动测试时不要因为窗口失焦而暂停（否则机器人会卡在暂停界面）
	if what == NOTIFICATION_APPLICATION_FOCUS_OUT and state == S.PLAYING and not autoplay:
		_toggle_pause()


func _end_run() -> void:
	state = S.RESULTS
	var perfect := mode == MODE.GARLIC and strikes == 0
	if perfect:
		score += GameData.GARLIC_PERFECT_BONUS
	var record := score > SaveGame.best
	var coins := int(score / 40.0) + (50 if (record and SaveGame.best > 0) else 0)
	var prev_best := SaveGame.best
	SaveGame.best = maxi(SaveGame.best, score)
	SaveGame.coins += coins
	SaveGame.runs += 1
	SaveGame.total_squashed += squashed
	SaveGame.save_game()
	sfx.set_engine(false, 0.0, false)
	sfx.play("coin")
	ui.show_results({
		"score": score, "best": SaveGame.best, "squashed": squashed, "max_combo": max_combo,
		"by_kind": by_kind, "coins": coins, "record": record and prev_best > 0,
		"garlic": mode == MODE.GARLIC, "strikes": strikes, "perfect": perfect,
		"battle": mode == MODE.BATTLE, "kills": kills, "won": tank.alive and _enemies_alive() == 0,
		"survived": tank.alive,
	})
	if autoplay:
		print("[autoplay] run done: score=%d squashed=%d max_combo=%d coins=%d" % [score, squashed, max_combo, coins])


# ============================================================ 车库
func _buy_skin(id: String) -> void:
	var s: Dictionary = GameData.skin_by_id(id)
	var price: int = int(s["price"])
	if SaveGame.coins >= price and not SaveGame.skins_owned.has(id):
		SaveGame.coins -= price
		SaveGame.skins_owned.append(id)
		SaveGame.skin = id
		SaveGame.save_game()
		sfx.play("buy")
		tank.apply_skin(id)
		ui.preview_id = id
		ui.refresh_garage()
	else:
		sfx.play("no")


func _equip_skin(id: String) -> void:
	if SaveGame.skins_owned.has(id):
		SaveGame.skin = id
		SaveGame.save_game()
		tank.apply_skin(id)
		ui.preview_id = id
		ui.refresh_garage()


func _buy_upgrade(id: String) -> void:
	for u in GameData.UPGRADES:
		var ud: Dictionary = u
		if ud["id"] != id:
			continue
		var lv: int = int(SaveGame.up.get(id, 0))
		var cost := GameData.upgrade_cost(ud, lv)
		if lv < int(ud["max"]) and SaveGame.coins >= cost:
			SaveGame.coins -= cost
			SaveGame.up[id] = lv + 1
			SaveGame.save_game()
			sfx.play("buy")
			ui.refresh_garage()
		else:
			sfx.play("no")
		return


# ============================================================ 主循环
func _process(delta: float) -> void:
	var dt := minf(delta, 0.05)
	if Input.is_action_just_pressed("music"):
		sfx.toggle_music()
	if autoplay:
		_autoplay_script(dt)
	match state:
		S.TITLE:
			_update_idle(dt, true)
			if Input.is_action_just_pressed("confirm"):
				sfx.play("blip")
				_start_run()
		S.GARAGE:
			_update_idle(dt, false)
			if Input.is_action_just_pressed("pause"):
				_enter_title()
		S.COUNTDOWN:
			if Input.is_action_just_pressed("pause"):
				_toggle_pause()
			else:
				_update_countdown(dt)
		S.PLAYING:
			if Input.is_action_just_pressed("pause"):
				_toggle_pause()
			else:
				_update_playing(dt)
		S.ENDING:
			_update_ending(dt)
		S.RESULTS:
			_update_idle(dt, false)
			if Input.is_action_just_pressed("confirm"):
				_start_run()
		S.PAUSED:
			if Input.is_action_just_pressed("pause"):
				_toggle_pause()
	fx.step(dt if state != S.PAUSED else 0.0)


func _update_idle(dt: float, ambient_fruits: bool) -> void:
	orbit += dt * 0.4
	tank.update_visuals(dt)
	if showcase:
		_step_fruits(dt, true)
	elif ambient_fruits:
		if fruits.size() < 7:
			spawn_t -= dt
			if spawn_t <= 0.0:
				spawn_t = 0.8
				_spawn_fruit(_pick_kind(true), true, false)
		_step_fruits(dt, true)
	sfx.set_engine(false, 0.0, false)
	_update_camera(dt, false)


func _update_countdown(dt: float) -> void:
	cd -= dt
	# 3 / 2 / 1 各整整显示一秒；cd_shown 保证第一帧就打出 "3"
	var n := int(ceil(cd))
	if n != cd_shown:
		cd_shown = n
		if n >= 1:
			ui.set_message(str(n), 140, Color("#ffd51f"))
			sfx.play("beep")
	if cd <= 0.0:
		ui.set_message("GO!", 150, Color("#5fe06a"))
		sfx.play("go")
		state = S.PLAYING
		get_tree().create_timer(0.8).timeout.connect(func():
			if state == S.PLAYING:
				ui.set_message(""))
	tank.drive(dt, 0.0, 0.0, false, arena.obstacles)
	_update_aim(dt, false) # 倒计时期间可以先转炮塔，但不能开火
	tank.update_visuals(dt)
	_step_fruits(dt, false)
	_update_camera(dt, false)
	_push_hud()


func _read_input() -> Vector3:
	# x: 油门, y: 转向, z: 加速(0/1)
	var throttle := Input.get_axis("brake", "accel")
	var steer := Input.get_axis("right", "left")
	var b := 1.0 if Input.is_action_pressed("boost") else 0.0
	if autoplay:
		if mode == MODE.BATTLE:
			return Vector3(float(_bot_act.get("throttle", 0.0)), float(_bot_act.get("steer", 0.0)),
				1.0 if bool(_bot_act.get("boost", false)) else 0.0)
		return _bot_input()
	return Vector3(throttle, steer, b)


func _update_playing(dt: float) -> void:
	if mode == MODE.BATTLE:
		_update_battle(dt)
		return
	run_time += dt
	time_left -= dt
	combo_t -= dt
	if combo_t <= 0.0 and combo > 0:
		combo = 0
		mult = 1
	var inp := _read_input()
	_update_aim(dt, true)
	var impact := tank.drive(dt, inp.x, inp.y, inp.z > 0.5, arena.obstacles)
	if impact > 4.0:
		sfx.play("bump", randf_range(0.9, 1.1), -4.0)
		shake = maxf(shake, clampf(impact * 0.04, 0.0, 0.5))
	tank.update_visuals(dt)
	_tank_fx(dt)
	# 补充水果
	var target := 16 + int(run_time / 15.0)
	spawn_t -= dt
	if spawn_t <= 0.0 and fruits.size() < target:
		spawn_t = 0.3
		_spawn_fruit(_pick_kind(false), false, false)
	_step_fruits(dt, false)
	_update_shells(dt)
	_collide_fruits()
	_update_camera(dt, false)
	_push_hud()
	sfx.set_engine(true, clampf(absf(tank.fwd_speed) / float(stats["max_speed"]), 0.0, 1.5), tank.boosting)
	if time_left <= 0.0:
		time_left = 0.0
		state = S.ENDING
		ending_t = 1.8
		ui.set_message("TIME UP!", 130, Color("#ff4040"))
		sfx.play("go", 0.6)


func _update_ending(dt: float) -> void:
	ending_t -= dt
	tank.drive(dt, 0.0, 0.0, false, arena.obstacles)
	tank.update_visuals(dt)
	if mode == MODE.BATTLE:
		for e in enemies:
			var et: Tank = e
			if et.alive:
				et.drive(dt, 0.0, 0.0, false, arena.obstacles)
			et.update_visuals(dt)
	else:
		_step_fruits(dt, false)
	_update_shells(dt)
	_update_camera(dt, false)
	sfx.set_engine(false, 0.0, false)
	if ending_t <= 0.0:
		ui.set_message("")
		_end_run()


func _push_hud() -> void:
	var boost_frac := clampf(tank.boost / float(stats["boost_max"]), 0.0, 1.0)
	if mode == MODE.BATTLE:
		ui.set_hud(score, time_left, 0, 1, 0.0, boost_frac)
		ui.set_strikes(0, 0, false)
		var alive_n := 0
		var bars: Array = []
		for e in enemies:
			var et: Tank = e
			if not et.alive:
				continue
			alive_n += 1
			var hp_pos := et.position + Vector3(0, 3.5, 0)
			if cam.is_position_behind(hp_pos):
				continue
			var sd: Dictionary = GameData.skin_by_id(et.skin_id)
			bars.append([cam.unproject_position(hp_pos) * float(PIXEL_SHRINK),
				et.hp / et.hp_max, Color.html(str(sd["body"]))])
		ui.set_battle(true, tank.hp / tank.hp_max, kills, alive_n, bars)
	else:
		var win: float = float(stats["combo_window"])
		ui.set_hud(score, time_left, combo, mult, clampf(combo_t / win, 0.0, 1.0), boost_frac)
		ui.set_strikes(strikes, GameData.GARLIC_STRIKES, mode == MODE.GARLIC)
		ui.set_battle(false, 1.0, 0, 0, [])
	ui.set_ammo(ammo, int(stats["ammo_max"]), 1.0 - clampf(reload_t / maxf(float(stats["reload"]), 0.01), 0.0, 1.0))
	# 准星画在炮口指向的位置（而不是鼠标），这样能看出炮塔还在转
	var ap := tank.position + tank.turret_fwd() * 16.0 + Vector3(0, 0.6, 0)
	if cam.is_position_behind(ap) or not tank.alive:
		ui.set_reticle(Vector2.ZERO, false)
	else:
		ui.set_reticle(cam.unproject_position(ap) * float(PIXEL_SHRINK), ammo > 0)


func _tank_fx(dt: float) -> void:
	var spd := tank.vel.length()
	var fwd := Vector3(sin(tank.heading), 0.0, cos(tank.heading))
	tread_acc += spd * dt
	if tread_acc > 1.1:
		tread_acc = 0.0
		fx.tread_mark(tank.rear_pos(1.0) + fwd * 1.2, tank.heading)
		fx.tread_mark(tank.rear_pos(-1.0) + fwd * 1.2, tank.heading)
	smoke_t -= dt
	if smoke_t <= 0.0:
		smoke_t = 0.05 if tank.boosting else 0.09
		if tank.boosting:
			fx.puff(tank.exhaust_pos(), Color("#ffb23a"), 0.55, 1.5, 0.35)
			fx.puff(tank.exhaust_pos(), Color("#ff6a1a"), 0.4, 1.0, 0.3)
		elif spd > 2.5:
			fx.puff(tank.exhaust_pos(), Color("#6a6a6a"), 0.3, 1.8, 0.7)
			fx.puff(tank.rear_pos(1.0 if randf() < 0.5 else -1.0), Color("#cdbb90"), 0.35, 1.0, 0.5)


# ============================================================ 对战模式
func _update_battle(dt: float) -> void:
	run_time += dt
	time_left -= dt
	# 攒够 1 分再加，直接 int(20 * 1/60) 每帧都是 0
	survive_acc += GameData.BATTLE_SURVIVE_SCORE * dt
	var gain := int(survive_acc)
	if gain > 0:
		survive_acc -= float(gain)
		score += gain
	# 自动测试时让同一套 AI 来开玩家的车。
	# 弹药要同步给 AI，否则它内部还有一套弹仓，玩家会被"双重限流"打不出枪。
	if autoplay and player_ai != null:
		player_ai.ammo = ammo
		player_ai.reload_t = reload_t
		_bot_act = player_ai.think(dt, _all_tanks(), arena.obstacles, stats)
	var inp := _read_input()
	_update_aim(dt, true)
	var impact := tank.drive(dt, inp.x, inp.y, inp.z > 0.5, arena.obstacles)
	if impact > 4.0:
		sfx.play("bump", randf_range(0.9, 1.1), -4.0)
		shake = maxf(shake, clampf(impact * 0.04, 0.0, 0.5))
	tank.update_visuals(dt)
	_tank_fx(dt)
	# 电脑坦克
	var all := _all_tanks()
	for i in enemies.size():
		var e: Tank = enemies[i]
		if not e.alive:
			continue
		var ai: TankAI = ais[i]
		var act: Dictionary = ai.think(dt, all, arena.obstacles, stats)
		e.aim_world = float(act["aim"])
		e.traverse = float(stats["traverse"])
		e.drive(dt, float(act["throttle"]), float(act["steer"]), bool(act["boost"]), arena.obstacles)
		e.update_visuals(dt)
		if bool(act["fire"]):
			_fire_from(e)
		if e.hp < e.hp_max * 0.45 and randf() < dt * 7.0:
			fx.puff(e.exhaust_pos() + Vector3(0, 0.4, 0), Color("#4a4640"), 0.5, 1.4, 0.7)
	_resolve_tank_collisions()
	_update_shells(dt)
	_update_camera(dt, false)
	_push_hud()
	sfx.set_engine(true, clampf(absf(tank.fwd_speed) / float(stats["max_speed"]), 0.0, 1.5), tank.boosting)
	_check_battle_end()


func _all_tanks() -> Array:
	var a: Array = [tank]
	a.append_array(enemies)
	return a


## 坦克之间的推挤与撞击伤害（相对速度越大伤害越高）
func _resolve_tank_collisions() -> void:
	var all := _all_tanks()
	var rr: float = float(stats["radius"]) * 1.25
	for i in all.size():
		for j in range(i + 1, all.size()):
			var a: Tank = all[i]
			var b: Tank = all[j]
			if not a.alive or not b.alive:
				continue
			var d := Vector2(b.position.x - a.position.x, b.position.z - a.position.z)
			var dist := d.length()
			var min_d := rr * 2.0
			if dist >= min_d or dist < 0.001:
				continue
			var n := d / dist
			var push := (min_d - dist) * 0.5
			a.position.x -= n.x * push
			a.position.z -= n.y * push
			b.position.x += n.x * push
			b.position.z += n.y * push
			# 接近速度决定伤害
			var rel := Vector2(b.vel.x - a.vel.x, b.vel.z - a.vel.z).dot(n)
			var closing := -rel
			var n3 := Vector3(n.x, 0.0, n.y)
			a.vel -= n3 * closing * 0.5
			b.vel += n3 * closing * 0.5
			if closing > GameData.RAM_MIN_SPEED:
				var dmg := minf((closing - GameData.RAM_MIN_SPEED) * GameData.RAM_DAMAGE, GameData.RAM_DAMAGE_MAX)
				# 撞击双方都掉血，但冲得快的那方少掉一些
				var a_fast := a.vel.length() > b.vel.length()
				_damage_tank(a, dmg * (0.55 if a_fast else 1.0), b)
				_damage_tank(b, dmg * (1.0 if a_fast else 0.55), a)
				var mid := (a.position + b.position) * 0.5 + Vector3(0, 1.0, 0)
				fx.burst(mid, Color("#ffd27a"), 8, 7.0, 0.26)
				sfx.play("bump", randf_range(0.8, 1.0))
				if a == tank or b == tank:
					shake = maxf(shake, 0.4)


func _damage_tank(t: Tank, amount: float, source: Tank) -> void:
	if not t.alive or amount <= 0.0:
		return
	var died := t.take_damage(amount)
	if t == tank:
		ui.flash(Color(1.0, 0.25, 0.2, 0.34))
	if not died:
		return
	_destroy_tank(t)
	if source == tank and t != tank:
		kills += 1
		score += GameData.BATTLE_KILL_SCORE
		_float_at(t.position + Vector3(0, 3.6, 0), "击毁！ +%d" % GameData.BATTLE_KILL_SCORE, Color("#ffd24a"), 46)
		sfx.play("coin", 1.1)


func _destroy_tank(t: Tank) -> void:
	t.alive = false
	t.visible = false
	t.vel = Vector3.ZERO
	fx.burst(t.position + Vector3(0, 1.0, 0), Color("#ff9a2a"), 30, 13.0, 0.45)
	fx.burst(t.position + Vector3(0, 1.0, 0), Color("#3a3630"), 18, 10.0, 0.4)
	fx.puff(t.position + Vector3(0, 1.6, 0), Color("#6a6458"), 1.6, 2.2, 1.1)
	fx.splat(t.position, Color("#2a2622"), 4.2)
	sfx.play("boom", randf_range(0.75, 0.9))
	shake = maxf(shake, 0.9 if t == tank else 0.5)


func _enemies_alive() -> int:
	var n := 0
	for e in enemies:
		if (e as Tank).alive:
			n += 1
	return n


func _check_battle_end() -> void:
	if battle_over:
		return
	var alive_enemies := _enemies_alive()
	if not tank.alive:
		battle_over = true
		ui.set_message("被击毁！", 110, Color("#ff5040"))
		state = S.ENDING
		ending_t = 2.4
		return
	if alive_enemies == 0:
		battle_over = true
		score += GameData.BATTLE_WIN_BONUS
		ui.set_message("最后的幸存者！", 92, Color("#5fe06a"))
		sfx.play("go")
		state = S.ENDING
		ending_t = 2.6
		return
	if time_left <= 0.0:
		battle_over = true
		time_left = 0.0
		ui.set_message("TIME UP!", 130, Color("#ff4040"))
		state = S.ENDING
		ending_t = 1.8


# ============================================================ 主炮
## 鼠标射线与坦克所在水平面的交点。SubViewport 缩小了 PIXEL_SHRINK 倍，先把屏幕坐标换算回去。
func _aim_point() -> Vector3:
	var fallback := tank.position + Vector3(sin(tank.heading), 0.0, cos(tank.heading)) * 20.0
	var mp := get_viewport().get_mouse_position() / float(PIXEL_SHRINK)
	var from := cam.project_ray_origin(mp)
	var dir := cam.project_ray_normal(mp)
	if absf(dir.y) < 0.0005:
		return fallback
	var t := (tank.position.y + 0.9 - from.y) / dir.y
	if t <= 0.0:
		return fallback
	return from + dir * t


func _update_aim(dt: float, allow_fire: bool) -> void:
	want_fire = false
	# 右摇杆（相对摄像机）优先，否则跟随鼠标
	var rs := Vector2(Input.get_joy_axis(0, JOY_AXIS_RIGHT_X), Input.get_joy_axis(0, JOY_AXIS_RIGHT_Y))
	if rs.length() > 0.35:
		aim_world = cam_heading + atan2(rs.x, -rs.y)
	else:
		var p := _aim_point()
		var d := Vector3(p.x - tank.position.x, 0.0, p.z - tank.position.z)
		if d.length() > 0.6:
			aim_world = atan2(d.x, d.z)
	if autoplay:
		if mode == MODE.BATTLE:
			aim_world = float(_bot_act.get("aim", aim_world))
			want_fire = bool(_bot_act.get("fire", false))
		else:
			aim_world = _bot_aim()
	tank.aim_world = aim_world
	tank.traverse = float(stats["traverse"])
	# 装填：弹仓没满就一发一发地补
	var cap := int(stats["ammo_max"])
	if ammo < cap:
		reload_t -= dt
		if reload_t <= 0.0:
			ammo += 1
			reload_t = float(stats["reload"])
			sfx.play("blip", 0.65, -16.0)
	else:
		reload_t = float(stats["reload"])
	if not allow_fire:
		return
	var pressed := want_fire if autoplay else Input.is_action_just_pressed("fire")
	if pressed and ammo > 0 and tank.stun <= 0.0:
		_fire()


func _fire() -> void:
	ammo -= 1
	_fire_from(tank)


func _fire_from(t: Tank) -> void:
	var dir := t.turret_fwd()
	var mp := t.muzzle_pos()
	var sh := Shell.new()
	sh.setup(dir, float(stats["shell_speed"]), float(stats["blast"]))
	sh.shooter = t
	shell_root.add_child(sh)
	sh.position = mp
	shells.append(sh)
	t.recoil = 1.0
	t.vel -= dir * 2.4
	fx.burst(mp + dir * 0.5, Color("#ffc44a"), 7, 9.0, 0.3, 2.0)
	fx.puff(mp + dir * 0.9, Color("#9a9684"), 0.6, 1.1, 0.5)
	if t == tank:
		sfx.play("fire", randf_range(0.95, 1.06))
		shake = maxf(shake, 0.32)
	else:
		# 远处的炮声小一点
		var d := tank.position.distance_to(t.position)
		sfx.play("fire", randf_range(0.9, 1.0), clampf(-4.0 - d * 0.22, -26.0, -4.0))


func _update_shells(dt: float) -> void:
	for i in range(shells.size() - 1, -1, -1):
		var sh: Shell = shells[i]
		sh.step(dt)
		if randf() < 0.5:
			fx.puff(sh.position, Color("#b4b1a2"), 0.2, 0.25, 0.28)
		if not sh.done:
			for f in fruits:
				var fr: Fruit = f
				if fr.state != 0 or fr.age < 0.2:
					continue
				if Vector2(fr.position.x - sh.position.x, fr.position.z - sh.position.z).length() < fr.r + 0.6:
					sh.done = true
					break
		# 打到坦克（不伤开炮者本人）；伤害统一由 _detonate 的范围判定处理
		if not sh.done and mode == MODE.BATTLE:
			for t in _all_tanks():
				var tt: Tank = t
				if not tt.alive or tt == sh.shooter:
					continue
				if Vector2(tt.position.x - sh.position.x, tt.position.z - sh.position.z).length() < 2.4:
					sh.done = true
					break
		if not sh.done:
			for o in arena.obstacles:
				var ov: Vector3 = o
				if Vector2(ov.x - sh.position.x, ov.z - sh.position.z).length() < ov.y + 0.3:
					sh.done = true
					break
		if sh.done:
			_detonate(sh.position, sh.blast, sh.shooter as Tank, sh.damage)
			sh.queue_free()
			shells.remove_at(i)


## 爆炸：范围内的水果走和碾压完全相同的计分/连击逻辑；地雷被安全引爆（不扣时间）。
func _detonate(pos: Vector3, r: float, shooter: Tank = null, dmg: float = 0.0) -> void:
	var gp := Vector3(pos.x, maxf(pos.y, 0.3), pos.z)
	fx.burst(gp, Color("#ffb23a"), 16, 9.5, 0.3)
	fx.burst(gp, Color("#6e6a5c"), 8, 7.0, 0.36)
	fx.puff(gp + Vector3(0, 0.6, 0), Color("#9a968a"), 0.85, 1.3, 0.7)
	sfx.play("boom", randf_range(1.25, 1.4), -7.0)
	shake = maxf(shake, 0.26 if tank.position.distance_to(gp) < 26.0 else 0.0)
	if mode == MODE.BATTLE:
		# 开炮者本人免疫自己的溅射，否则贴脸打墙会很憋屈
		for t in _all_tanks():
			var tt: Tank = t
			if not tt.alive or tt == shooter:
				continue
			var d := Vector2(tt.position.x - gp.x, tt.position.z - gp.z).length()
			if d > r + 2.3:
				continue
			# 直击才疼，擦边只蹭一点皮
			var falloff := clampf(1.0 - maxf(d - 2.0, 0.0) / maxf(r, 0.1), 0.18, 1.0)
			_damage_tank(tt, dmg * falloff, shooter)
		return
	for f in fruits:
		var fr: Fruit = f
		if fr.state != 0 or fr.age < 0.2:
			continue
		if Vector2(fr.position.x - gp.x, fr.position.z - gp.z).length() > r + fr.r:
			continue
		# 炸到大蒜一样算失误——所以大蒜模式里不能见人就轰
		if fr.is_garlic():
			_hit_garlic(fr)
			if state != S.PLAYING:
				return
			continue
		if fr.is_bad():
			fx.burst(fr.position, Color("#ff7a1a"), 10, 8.0, 0.3)
			fx.splat(fr.position, Color("#2a2a2a"), 2.2)
			fr.squash()
			continue
		_squash(fr)


# ============================================================ 水果
func _count_kind(k: String) -> int:
	var n := 0
	for f in fruits:
		if (f as Fruit).kind == k and (f as Fruit).state == 0:
			n += 1
	return n


func _pick_kind(ambient: bool) -> String:
	var w: Dictionary = {}
	var total := 0.0
	var garlic_mode := mode == MODE.GARLIC
	for k in GameData.FRUITS.keys():
		var info: Dictionary = GameData.FRUITS[k]
		var wt: float = float(info["weight"])
		if k == "mine":
			# 大蒜模式里不放地雷，让大蒜成为唯一的威胁
			if garlic_mode:
				wt = 0.0
			else:
				wt = clampf((run_time - 6.0) * 0.4, 0.0, 12.0)
				if _count_kind("mine") >= 4:
					wt = 0.0
		elif k == "gold":
			wt = 3.0 if (run_time > 8.0 and _count_kind("gold") == 0) else 0.0
		elif k == "garlic":
			# 开局就有，随时间越铺越密；但设上限，否则大蒜寿命长会堆到满场、没东西可压
			wt = 0.0
			if garlic_mode and _count_kind("garlic") < 7:
				wt = clampf(22.0 + run_time * 0.5, 0.0, 48.0)
		if ambient and (k == "mine" or k == "gold" or k == "garlic"):
			wt = 0.0
		w[k] = wt
		total += wt
	var roll := randf() * total
	for k in w.keys():
		roll -= float(w[k])
		if roll <= 0.0:
			return k
	return "apple"


func _spawn_fruit(kind: String, ambient: bool, scatter: bool) -> void:
	var f := Fruit.new()
	f.setup(kind)
	fruit_root.add_child(f)
	var a := randf() * TAU
	var rr := GameData.arena_radius - 4.0
	if scatter:
		rr = randf_range(12.0, 42.0)
	f.position = Vector3(cos(a) * rr, 0.0, sin(a) * rr)
	var tgt := Vector3(randf_range(-22, 22), 0.0, randf_range(-22, 22))
	f.vel = (tgt - f.position).normalized() * float(f.info["speed"])
	fruits.append(f)


func _step_fruits(dt: float, ambient: bool) -> void:
	var diff := clampf(run_time / 90.0, 0.0, 1.0)
	for i in range(fruits.size() - 1, -1, -1):
		var f: Fruit = fruits[i]
		f.step(dt, tank.position, arena.obstacles, diff, ambient)
		if f.done:
			f.queue_free()
			fruits.remove_at(i)


func _collide_fruits() -> void:
	var fwd := Vector3(sin(tank.heading), 0.0, cos(tank.heading))
	var cp := tank.position + fwd * 0.3
	var tr: float = float(stats["radius"])
	for f in fruits:
		var fr: Fruit = f
		if fr.state != 0 or fr.cooldown > 0.0 or fr.age < 0.3:
			continue
		var d := Vector2(fr.position.x - cp.x, fr.position.z - cp.z)
		var reach := tr + fr.r * (0.35 if (fr.is_bad() or fr.is_garlic()) else 0.55)
		if d.length() >= reach:
			continue
		if fr.is_garlic():
			_hit_garlic(fr)
		elif fr.is_bad():
			_hit_mine(fr)
		elif fr.is_heavy() and absf(tank.fwd_speed) < float(stats["crush_speed"]):
			_bump_melon(fr, cp)
		else:
			_squash(fr)


func _bump_melon(f: Fruit, cp: Vector3) -> void:
	var away := Vector3(f.position.x - cp.x, 0.0, f.position.z - cp.z).normalized()
	f.vel = away * (8.0 + absf(tank.fwd_speed))
	f.cooldown = 0.35
	tank.vel *= 0.55
	sfx.play("thud")
	shake = maxf(shake, 0.2)
	if not hinted_melon:
		hinted_melon = true
		_float_at(f.position + Vector3(0, 2.5, 0), "速度太慢，压不碎！", Color("#ffe14d"), 34)


func _squash(f: Fruit) -> void:
	if combo_t > 0.0:
		combo += 1
	else:
		combo = 1
	combo_t = float(stats["combo_window"])
	max_combo = maxi(max_combo, combo)
	mult = mini(10, 1 + int(floor(combo / 3.0)))
	var pts := int(f.info["pts"]) * mult
	score += pts
	squashed += 1
	by_kind[f.kind] = int(by_kind.get(f.kind, 0)) + 1
	var juice := Color.html(str(f.info["juice"]))
	fx.splat(f.position, juice, f.r * 1.9)
	fx.burst(f.position, juice, 12 if f.kind != "melon" else 22, 8.0, 0.24)
	if f.kind == "melon":
		fx.burst(f.position, Color("#2c8a3a"), 8, 9.0, 0.3)
	var big := f.kind == "melon" or f.kind == "gold"
	shake = maxf(shake, 0.35 if big else 0.1)
	var idx := combo - 1
	var semi: int = int(PENTA[idx % 5]) + 12 * mini(int(floor(idx / 5.0)), 2)
	sfx.play("squish", pow(2.0, semi / 12.0) * (0.8 if f.kind == "melon" else 1.0))
	var col := Color.WHITE
	if mult >= 6:
		col = Color("#ff4fd8")
	elif mult >= 4:
		col = Color("#ff9a1f")
	elif mult >= 2:
		col = Color("#ffe14d")
	_float_at(f.position + Vector3(0, 1.8, 0), "+%d" % pts, col, 36 + mult * 3)
	if f.kind == "gold":
		time_left += 3.0
		sfx.play("coin")
		_float_at(f.position + Vector3(0, 3.2, 0), "+3 秒", Color("#5fe06a"), 40)
	if combo > 0 and combo % 10 == 0:
		time_left += 2.0
		sfx.play("coin", 1.2)
		_float_at(tank.position + Vector3(0, 4.0, 0), "连击奖励 +2 秒", Color("#5fe06a"), 38)
	f.squash()


func _hit_mine(f: Fruit) -> void:
	fx.burst(f.position, Color("#ff7a1a"), 24, 11.0, 0.35)
	fx.burst(f.position, Color("#333333"), 14, 9.0, 0.3)
	fx.splat(f.position, Color("#2a2a2a"), 3.2)
	sfx.play("boom")
	shake = 1.0
	var away := Vector3(tank.position.x - f.position.x, 0.0, tank.position.z - f.position.z).normalized()
	tank.vel = away * 15.0
	tank.stun = 0.9
	time_left = maxf(0.5, time_left - 3.0)
	combo = 0
	combo_t = 0.0
	mult = 1
	_float_at(tank.position + Vector3(0, 3.0, 0), "BOOM!  -3 秒", Color("#ff4040"), 50)
	f.squash()


## 大蒜模式的失误：扣时间、断连击，累计 GARLIC_STRIKES 次直接收尾
func _hit_garlic(f: Fruit) -> void:
	strikes += 1
	combo = 0
	combo_t = 0.0
	mult = 1
	fx.burst(f.position, Color("#f4f0e2"), 20, 9.0, 0.3)
	fx.burst(f.position, Color("#aebd72"), 10, 7.5, 0.32)
	fx.splat(f.position, Color("#e6dfc6"), 2.6)
	sfx.play("stink")
	shake = maxf(shake, 0.5)
	ui.flash(Color(0.78, 0.92, 0.42, 0.45))
	f.squash()
	var left := GameData.GARLIC_STRIKES - strikes
	if left <= 0:
		time_left = 0.0
		state = S.ENDING
		ending_t = 2.0
		ui.set_message("蒜味超标！", 110, Color("#cfe85a"))
		sfx.play("no", 0.8)
		return
	time_left = maxf(0.5, time_left - GameData.GARLIC_TIME_PENALTY)
	_float_at(tank.position + Vector3(0, 3.0, 0),
		"大蒜！ -%d 秒   还能错 %d 次" % [int(GameData.GARLIC_TIME_PENALTY), left], Color("#cfe85a"), 44)


func _float_at(pos: Vector3, text: String, col: Color, size: int) -> void:
	if cam.is_position_behind(pos):
		return
	var p := cam.unproject_position(pos) * float(PIXEL_SHRINK)
	ui.add_float(text, p, col, size)


# ============================================================ 摄像机
func _update_camera(dt: float, snap: bool) -> void:
	var idle := state == S.TITLE or state == S.GARAGE or state == S.RESULTS
	var hoff_target := 0.0
	if idle:
		var dist := 11.5 if state == S.TITLE else 10.5
		var height := 4.2 if state == S.TITLE else 3.8
		if showcase:
			dist = 8.5
			height = 5.0
		var pos := Vector3(sin(orbit) * dist, height, cos(orbit) * dist)
		cam.position = pos if snap else cam.position.lerp(pos, 1.0 - exp(-4.0 * dt))
		cam.look_at(Vector3(0, 1.1, 0))
		if state == S.GARAGE:
			hoff_target = -2.8
		elif state == S.TITLE and not showcase:
			hoff_target = -3.4
		cam.fov = lerpf(cam.fov, 60.0, 1.0 - exp(-5.0 * dt))
	else:
		cam_heading += angle_difference(cam_heading, tank.heading) * minf(1.0, dt * 2.6)
		if snap:
			cam_heading = tank.heading
		var f := Vector3(sin(cam_heading), 0.0, cos(cam_heading))
		var sf := clampf(tank.vel.length() / (float(stats["max_speed"]) * 1.5), 0.0, 1.0)
		var want := tank.position - f * (12.5 + sf * 3.0) + Vector3(0, 9.0, 0)
		want.y = maxf(want.y, Arena.height_at(want.x, want.z) + 3.0)
		cam.position = want if snap else cam.position.lerp(want, 1.0 - exp(-9.0 * dt))
		cam.look_at(tank.position + f * 4.0 + Vector3(0, 0.5, 0))
		var fov_t := 60.0 + (12.0 if tank.boosting else 0.0)
		cam.fov = lerpf(cam.fov, fov_t, 1.0 - exp(-6.0 * dt))
	arena.follow_sky(cam.position)
	cam_hoff = lerpf(cam_hoff, hoff_target, 1.0 - exp(-6.0 * dt))
	shake = maxf(0.0, shake - dt * 2.2)
	cam.h_offset = cam_hoff + randf_range(-1.0, 1.0) * shake * 0.6
	cam.v_offset = randf_range(-1.0, 1.0) * shake * 0.6


# ============================================================ 自动测试机器人
func _bot_input() -> Vector3:
	var best: Fruit = null
	var best_d := 1e9
	var avoid := Vector3.ZERO
	for f in fruits:
		var fr: Fruit = f
		if fr.state != 0:
			continue
		var d := Vector3(fr.position.x - tank.position.x, 0.0, fr.position.z - tank.position.z)
		var dl := d.length()
		if fr.is_bad() or fr.is_garlic():
			if dl < 9.0:
				avoid -= d.normalized() * (9.0 - dl)
			continue
		if dl < best_d:
			best_d = dl
			best = fr
	var want_dir := Vector3.ZERO
	if best != null:
		want_dir = Vector3(best.position.x - tank.position.x, 0.0, best.position.z - tank.position.z).normalized()
	want_dir = (want_dir + avoid * 0.25).normalized() if (want_dir + avoid * 0.25).length() > 0.01 else want_dir
	if want_dir == Vector3.ZERO:
		return Vector3(0.0, 0.0, 0.0)
	var target_h := atan2(want_dir.x, want_dir.z)
	var diff := angle_difference(tank.heading, target_h)
	var steer := clampf(diff * 2.5, -1.0, 1.0)
	var throttle := 1.0 if absf(diff) < 1.3 else 0.3
	var boost_on := 1.0 if (best != null and best.is_heavy() and absf(diff) < 0.3) else 0.0
	return Vector3(throttle, steer, boost_on)


## 机器人：炮塔瞄准较远的水果（近的直接碾），对准了就开火
func _bot_aim() -> float:
	var best: Fruit = null
	var bd := 1e9
	for f in fruits:
		var fr: Fruit = f
		if fr.state != 0 or fr.is_bad() or fr.is_garlic():
			continue
		var d := Vector2(fr.position.x - tank.position.x, fr.position.z - tank.position.z).length()
		if d > 7.0 and d < bd:
			bd = d
			best = fr
	if best == null:
		return tank.turret_world
	var a := atan2(best.position.x - tank.position.x, best.position.z - tank.position.z)
	if ammo <= 0 or absf(angle_difference(tank.turret_world, a)) >= 0.05:
		return a
	# 大蒜模式：爆炸半径里有蒜就别开炮
	var blast: float = float(stats["blast"]) + 1.2
	for f2 in fruits:
		var g: Fruit = f2
		if g.state != 0 or not g.is_garlic():
			continue
		if Vector2(g.position.x - best.position.x, g.position.z - best.position.z).length() < blast + g.r:
			return a
	want_fire = true
	return a


func _make_showcase() -> void:
	var kinds := GameData.FRUITS.keys()
	for i in kinds.size():
		var f := Fruit.new()
		f.setup(kinds[i])
		f.frozen = true
		fruit_root.add_child(f)
		var a := TAU * i / kinds.size() + 0.4
		f.position = Vector3(cos(a), 0.0, sin(a)) * 4.6
		fruits.append(f)


func _shot(name: String) -> void:
	if shot_dir == "":
		return
	var img := get_viewport().get_texture().get_image()
	if img != null:
		DirAccess.make_dir_recursive_absolute(shot_dir)
		img.save_png("%s/%s.png" % [shot_dir, name])
		print("[autoplay] shot ", name)


func _autoplay_script(dt: float) -> void:
	_auto_t += dt
	match _auto_stage:
		0:
			if showcase and _auto_t > 1.0:
				_shot("00_showcase")
				get_tree().quit()
			if not showcase and _auto_t > 1.2:
				_shot("01_title")
				_auto_stage = 1
				_start_run()
				_auto_t = 0.0
		1:
			if _auto_t > 2.0 and state == S.COUNTDOWN:
				_shot("02_countdown")
			if state == S.PLAYING and _auto_t > 12.0:
				_shot("03_play")
				_auto_stage = 2
		2:
			if state == S.PLAYING and _auto_t > 30.0:
				_shot("04_play_late")
				_auto_stage = 3
		3:
			if state == S.RESULTS:
				_shot("05_results")
				_auto_stage = 4
				_auto_t = 0.0
		4:
			if _auto_t > 0.3:
				SaveGame.coins += 5000
				_enter_garage()
				_auto_stage = 5
				_auto_t = 0.0
		5:
			if _auto_t > 0.8:
				_shot("06_garage_upgrades")
				_buy_upgrade("engine")
				_buy_upgrade("weight")
				_buy_upgrade("cannon")
				_buy_upgrade("shell")
				ui.tab = 1
				ui.refresh_garage()
				_buy_skin("pink")
				_auto_stage = 6
				_auto_t = 0.0
		6:
			if _auto_t > 0.8:
				_shot("07_garage_skins")
				print("[autoplay] coins=%d skin=%s up=%s" % [SaveGame.coins, SaveGame.skin, str(SaveGame.up)])
				get_tree().quit()
