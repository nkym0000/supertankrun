class_name Arena
extends Node3D
## 天安门广场（N64 低多边形风格）。全部几何体由代码生成，贴图来自 textures.gd。
##
## 布局（+Z 为北）：
##   北 — 长安街、金水河与金水桥、天安门城楼（红墙 + 金色重檐庑殿顶）
##   中 — 人民英雄纪念碑（z=+20）、国旗杆（z=+42）、两列华灯、四座花坛
##   东西 — 国家博物馆 / 人民大会堂（柱廊式米黄石建筑，贴着广场边缘）
##   南 — 毛主席纪念堂、正阳门城楼与箭楼
##   远处 — 雾中的城市天际线
##
## 可驾驶范围仍是半径 GameData.ARENA_RADIUS 的圆（未改动），
## 大型建筑都在圆外，圆内只有纪念碑/旗杆/华灯/花坛作为障碍物。

## 两种场景：天安门广场（经典/大蒜）与战场（对战模式）
enum KIND { PLAZA, WAR }

const FOG_COL := Color("#ccd5dd")
const WAR_FOG_COL := Color("#b9ad92")

## 建场景之前由 main.gd 设置
var kind: int = KIND.PLAZA
var plaza_r := GameData.ARENA_RADIUS

# ---- 配色 ----
const C_WALL := Color("#b02a1e")      # 宫墙红
const C_WALL_DK := Color("#8b1f16")
const C_ROOF := Color("#e4b02a")      # 金色琉璃瓦
const C_ROOF_DK := Color("#b1800f")
const C_EAVE := Color("#2e7f6b")      # 檐下彩画（青绿）
const C_EAVE2 := Color("#2a5ba4")     # 檐下彩画（靛蓝，用于斗拱间隔）
const C_MARBLE := Color("#ece9dc")    # 汉白玉
const C_MARBLE_DK := Color("#cdc9b6")
const C_GRANITE := Color("#c6c4ba")   # 广场铺地
const C_BUFF := Color("#d6c9a2")      # 大会堂 / 博物馆米黄石
const C_BUFF_DK := Color("#bcac86")
const C_GREY := Color("#8e9299")      # 城砖灰
const C_GREY_DK := Color("#6e737a")
const C_GOLD := Color("#f2cf4a")
const C_RED := Color("#c9281c")

# ---- 关键尺寸 ----
const GATE_Z := 85.0        # 城台中心
const GATE_FRONT := 78.0    # 城台南立面
const WALL_H := 14.5        # 城台高

## 障碍物：Vector3(x, 半径, z)
var obstacles: Array = []
## 战场模式的出生点（6 个，均匀分布在外圈）
var spawns: Array = []
var sky: Node3D
var _clouds: Array = []
var _flags: Array = []
var _mb: Dictionary = {}
var _t := 0.0


## 广场是平的；保留接口供 main.gd 的摄像机使用。
static func height_at(_x: float, _z: float) -> float:
	return 0.0


static func normal_at(_x: float, _z: float) -> Vector3:
	return Vector3.UP


func _ready() -> void:
	plaza_r = GameData.arena_radius
	if kind == KIND.WAR:
		_build_war()
	else:
		_build_square()


func _build_square() -> void:
	_build_env()
	_build_sky()
	_build_ground()
	_build_roads()
	_build_plaza()
	_build_gate()
	_build_wings()
	_build_south()
	_build_trees()
	_build_skyline()
	_flush()
	_build_sprites()
	_build_clouds()


func _process(delta: float) -> void:
	_t += delta
	for c in _clouds:
		var m: Node3D = c
		m.position.x += delta * (1.2 + m.position.y * 0.02)
		if m.position.x > 240.0:
			m.position.x = -240.0
	for f in _flags:
		var fn: Node3D = f
		fn.rotation.y = sin(_t * 1.6) * 0.17
		fn.rotation.z = sin(_t * 2.3 + 1.0) * 0.05


func follow_sky(pos: Vector3) -> void:
	if sky != null:
		sky.position = pos


# ============================================================ 批次 / 材质
func _b(key: String) -> MB:
	if not _mb.has(key):
		_mb[key] = MB.new()
	return _mb[key]


func _flush() -> void:
	var globe := Mats.lp("a_globe", "marble", 1, 0.2)
	globe.set_shader_parameter("glow", 0.22)
	var mats: Dictionary = {
		"stone": Mats.lp("a_stone", "marble", 1, 0.2),
		"red": Mats.lp("a_red", "concrete", 1, 0.1),
		"roof": Mats.lp("a_roof", "rooftile", 1, 0.3),
		"brick": Mats.lp("a_brick", "brick", 1, 0.2),
		"buff": Mats.lp("a_buff", "concrete", 1, 0.07),
		"steel": Mats.lp("a_steel", "metal", 1, 0.25),
		"city": Mats.lp("a_city", "concrete", 1, 0.04),
		"road": Mats.lp("a_road", "asphalt", 1, 0.28),
		"bark": Mats.lp("a_bark", "bark", 1, 0.5),
		"leaf": Mats.lp("a_leaf", "leaves", 1, 0.3),
		"globe": globe,
		"paint": Mats.lp("a_paint", "", 0),
		# 战场
		"sandbag": Mats.lp("w_bag", "dirt", 1, 0.45),
		"concrete": Mats.lp("w_conc", "concrete", 1, 0.14),
		"rust": Mats.lp("w_rust", "metal", 1, 0.45),
	}
	for k in _mb.keys():
		var mi := MeshInstance3D.new()
		mi.mesh = (_mb[k] as MB).build()
		mi.material_override = mats.get(k, mats["paint"])
		add_child(mi)
	_mb.clear()


# ============================================================ 通用构件
## 朝上的矩形面片（道路、标线、水面）
func _flat_rect(b: MB, cx: float, cz: float, hx: float, hz: float, y: float, col: Color) -> void:
	b.quad(Vector3(cx - hx, y, cz - hz), Vector3(cx - hx, y, cz + hz),
		Vector3(cx + hx, y, cz + hz), Vector3(cx + hx, y, cz - hz), col)


## 朝 -Z（面向广场）的贴图面片，UV 已做左右翻转
func _panel_quad(b: MB, cx: float, cy: float, z: float, hw: float, hh: float) -> void:
	b.quad_uv(Vector3(cx - hw, cy - hh, z), Vector3(cx - hw, cy + hh, z),
		Vector3(cx + hw, cy + hh, z), Vector3(cx + hw, cy - hh, z), Color.WHITE,
		Vector2(1, 1), Vector2(1, 0), Vector2(0, 0), Vector2(0, 1))


## 檐角起翘曲线：t∈[-1,1]，端部抬高
func _eave_lift(t: float, lift: float) -> float:
	return lift * pow(absf(t), 3.0)


## 中式庑殿顶（低多边形，四角起翘）。ctr = 檐口中心，h = 举高。
func _hip_roof(b: MB, ctr: Vector3, hw: float, hd: float, h: float, ridge_hw: float,
		lift: float, seg: int, col: Color, ridge_col: Color) -> void:
	for sv in [1.0, -1.0]:
		var s := float(sv)
		for i in seg:
			var t0 := -1.0 + 2.0 * float(i) / float(seg)
			var t1 := -1.0 + 2.0 * float(i + 1) / float(seg)
			var e0 := ctr + Vector3(t0 * hw, _eave_lift(t0, lift), s * hd)
			var e1 := ctr + Vector3(t1 * hw, _eave_lift(t1, lift), s * hd)
			var r0 := ctr + Vector3(t0 * ridge_hw, h, 0.0)
			var r1 := ctr + Vector3(t1 * ridge_hw, h, 0.0)
			b.tri_away(e0, e1, r1, col, ctr)
			b.tri_away(e0, r1, r0, col, ctr)
	for sv2 in [-1.0, 1.0]:
		var s2 := float(sv2)
		var apex := ctr + Vector3(s2 * ridge_hw, h, 0.0)
		for i in seg:
			var t0 := -1.0 + 2.0 * float(i) / float(seg)
			var t1 := -1.0 + 2.0 * float(i + 1) / float(seg)
			var e0 := ctr + Vector3(s2 * hw, _eave_lift(t0, lift), t0 * hd)
			var e1 := ctr + Vector3(s2 * hw, _eave_lift(t1, lift), t1 * hd)
			b.tri_away(e0, e1, apex, col, ctr)
	# 檐底封板（避免从下方看穿）
	b.quad(ctr + Vector3(-hw, 0, -hd), ctr + Vector3(hw, 0, -hd),
		ctr + Vector3(hw, 0, hd), ctr + Vector3(-hw, 0, hd), ridge_col)
	# 正脊 + 垂脊端饰
	b.box(MB.xf(ctr.x, ctr.y + h + 0.22, ctr.z), Vector3(ridge_hw * 2.0 + 0.8, 0.5, 0.75), ridge_col)
	for ex in [-1.0, 1.0]:
		b.box(MB.xf(ctr.x + float(ex) * (ridge_hw + 0.45), ctr.y + h + 0.6, ctr.z),
			Vector3(0.5, 0.75, 0.5), ridge_col)


## 重檐下层的腰檐（四坡外张的裙边，顶部是平台而非屋脊）
func _eave_skirt(b: MB, ctr: Vector3, hw: float, hd: float, thw: float, thd: float,
		h: float, lift: float, seg: int, col: Color, cap_col: Color) -> void:
	for sv in [1.0, -1.0]:
		var s := float(sv)
		for i in seg:
			var t0 := -1.0 + 2.0 * float(i) / float(seg)
			var t1 := -1.0 + 2.0 * float(i + 1) / float(seg)
			var e0 := ctr + Vector3(t0 * hw, _eave_lift(t0, lift), s * hd)
			var e1 := ctr + Vector3(t1 * hw, _eave_lift(t1, lift), s * hd)
			var p0 := ctr + Vector3(t0 * thw, h, s * thd)
			var p1 := ctr + Vector3(t1 * thw, h, s * thd)
			b.tri_away(e0, e1, p1, col, ctr)
			b.tri_away(e0, p1, p0, col, ctr)
	for sv2 in [1.0, -1.0]:
		var s2 := float(sv2)
		for i in seg:
			var t0 := -1.0 + 2.0 * float(i) / float(seg)
			var t1 := -1.0 + 2.0 * float(i + 1) / float(seg)
			var e0 := ctr + Vector3(s2 * hw, _eave_lift(t0, lift), t0 * hd)
			var e1 := ctr + Vector3(s2 * hw, _eave_lift(t1, lift), t1 * hd)
			var p0 := ctr + Vector3(s2 * thw, h, t0 * thd)
			var p1 := ctr + Vector3(s2 * thw, h, t1 * thd)
			b.tri_away(e0, e1, p1, col, ctr)
			b.tri_away(e0, p1, p0, col, ctr)
	b.quad(ctr + Vector3(-hw, 0, -hd), ctr + Vector3(hw, 0, -hd),
		ctr + Vector3(hw, 0, hd), ctr + Vector3(-hw, 0, hd), cap_col)


## 券门（方洞 + 半圆拱），画在墙面前方一点避免 z-fighting
func _door(b: MB, x: float, y0: float, z: float, w: float, h: float, col: Color) -> void:
	var hw := w * 0.5
	var straight := maxf(h - hw, 0.3)
	b.box(MB.xf(x, y0 + straight * 0.5, z), Vector3(w, straight, 0.3), col)
	b.cyl(Transform3D(Basis(Vector3.RIGHT, PI / 2.0), Vector3(x, y0 + straight, z)),
		hw, hw, 0.3, 12, col, true)


## 沿 X 轴排一列小方块（斗拱 / 椽头 / 齿饰）。N64 的做法：靠剪影和配色读出细节，不堆面数。
func _block_row(b: MB, y: float, z: float, x0: float, x1: float, n: int,
		sz: Vector3, c1: Color, c2: Color) -> void:
	for i in n:
		var x := lerpf(x0, x1, float(i) / float(maxi(1, n - 1)))
		b.box(MB.xf(x, y, z), sz, c1 if i % 2 == 0 else c2)


## 沿 Z 轴排一列小方块
func _block_row_z(b: MB, x: float, y: float, z0: float, z1: float, n: int,
		sz: Vector3, c1: Color, c2: Color) -> void:
	for i in n:
		var z := lerpf(z0, z1, float(i) / float(maxi(1, n - 1)))
		b.box(MB.xf(x, y, z), sz, c1 if i % 2 == 0 else c2)


## 一扇窗：大一圈的窗框先凸出墙面，更小的玻璃再凸出一点，于是四周留出一道框。
## z 传墙面坐标，out 是朝向观众的方向（-1 = 朝 -Z）。
func _window_z(b: MB, x: float, y: float, z: float, w: float, h: float,
		frame: Color, glass: Color, out: float = -1.0) -> void:
	b.box(MB.xf(x, y, z + out * 0.10), Vector3(w + 0.6, h + 0.6, 0.3), frame)
	b.box(MB.xf(x, y, z + out * 0.22), Vector3(w, h, 0.3), glass)


## 同上，但法线朝 ±X（东西两侧建筑的正立面）。x 传墙面坐标。
func _window_x(b: MB, x: float, y: float, z: float, w: float, h: float,
		frame: Color, glass: Color) -> void:
	var out := 1.0 if x < 0.0 else -1.0 # 朝广场（原点）的方向
	b.box(MB.xf(x + out * 0.10, y, z), Vector3(0.3, h + 0.6, w + 0.6), frame)
	b.box(MB.xf(x + out * 0.22, y, z), Vector3(0.3, h, w), glass)


## 汉白玉栏杆（直线段）
func _rail_line(b: MB, p0: Vector3, p1: Vector3, n: int, h: float) -> void:
	var d := p1 - p0
	var seglen := d.length() / float(n)
	var ang := atan2(d.x, d.z)
	var bas := Basis(Vector3.UP, ang)
	for i in n + 1:
		var p := p0 + d * (float(i) / float(n))
		b.box(Transform3D(bas, p + Vector3(0, h * 0.5, 0)), Vector3(0.32, h, 0.32), C_MARBLE)
		b.box(Transform3D(bas, p + Vector3(0, h + 0.07, 0)), Vector3(0.44, 0.14, 0.44), C_MARBLE_DK)
	for i in n:
		var p := p0 + d * ((float(i) + 0.5) / float(n))
		b.box(Transform3D(bas, p + Vector3(0, h * 0.4, 0)), Vector3(0.18, h * 0.5, seglen), C_MARBLE)
		b.box(Transform3D(bas, p + Vector3(0, h * 0.8, 0)), Vector3(0.24, 0.18, seglen), C_MARBLE_DK)


# ============================================================ 环境 / 天空
func _build_env() -> void:
	var env := Environment.new()
	env.background_mode = Environment.BG_COLOR
	env.background_color = FOG_COL
	env.fog_enabled = true
	env.fog_mode = Environment.FOG_MODE_DEPTH
	env.fog_light_color = FOG_COL
	env.fog_depth_begin = 46.0
	env.fog_depth_end = 188.0
	env.fog_depth_curve = 1.0
	var we := WorldEnvironment.new()
	we.environment = env
	add_child(we)


func _build_sky() -> void:
	sky = Node3D.new()
	add_child(sky)
	var b := MB.new()
	var rings := 9
	var seg := 16
	var rad := 330.0
	# 北京式的灰蓝天：地平线一层白霾，往上逐渐转蓝
	var stops: Array = [
		[-0.5, FOG_COL], [0.0, FOG_COL], [0.10, Color("#dde3e7")],
		[0.30, Color("#9cc0dc")], [0.62, Color("#6093cb")], [1.0, Color("#3a6fb8")]]
	if kind == KIND.WAR:
		# 战场：地平线一层沙尘，天顶是被硝烟压暗的灰蓝
		stops = [
			[-0.5, WAR_FOG_COL], [0.0, WAR_FOG_COL], [0.12, Color("#c9b894")],
			[0.34, Color("#a9a289")], [0.66, Color("#788391")], [1.0, Color("#55637a")]]
	var pts: Array = []
	for i in rings + 1:
		var el := lerpf(-0.5, PI / 2.0, float(i) / rings)
		var y := sin(el)
		var rr := cos(el)
		var yn := clampf(y, -0.5, 1.0)
		var c := FOG_COL
		for k in range(stops.size() - 1):
			var s0: Array = stops[k]
			var s1: Array = stops[k + 1]
			if yn >= float(s0[0]) and yn <= float(s1[0]):
				c = (s0[1] as Color).lerp(s1[1], (yn - float(s0[0])) / (float(s1[0]) - float(s0[0])))
		var row: Array = []
		for j in seg:
			var a := TAU * j / seg
			row.append([Vector3(cos(a) * rr, y, sin(a) * rr) * rad, c])
		pts.append(row)
	for i in rings:
		for j in seg:
			var j2 := (j + 1) % seg
			var p00: Array = pts[i][j]
			var p01: Array = pts[i][j2]
			var p10: Array = pts[i + 1][j]
			var p11: Array = pts[i + 1][j2]
			var n0 := -(p00[0] as Vector3).normalized()
			b.tri_nc(p00[0], p10[0], p11[0], n0, n0, n0, p00[1], p10[1], p11[1])
			b.tri_nc(p00[0], p11[0], p01[0], n0, n0, n0, p00[1], p11[1], p01[1])
	var mi := MeshInstance3D.new()
	mi.mesh = b.build()
	var m := StandardMaterial3D.new()
	m.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	m.vertex_color_use_as_albedo = true
	m.vertex_color_is_srgb = true
	m.cull_mode = BaseMaterial3D.CULL_DISABLED
	m.disable_fog = true
	mi.material_override = m
	sky.add_child(mi)
	# 雾中的白日头
	for d in [[110.0, Color(1.0, 0.98, 0.9), 300.0], [34.0, Color(1, 1, 0.96), 295.0]]:
		var dd: Array = d
		var s := MeshInstance3D.new()
		var q := QuadMesh.new()
		q.size = Vector2(float(dd[0]), float(dd[0]))
		s.mesh = q
		s.material_override = Mats.fx("puff", true, dd[1])
		(s.material_override as StandardMaterial3D).disable_fog = true
		s.position = Vector3(0.35, 0.55, 0.4).normalized() * float(dd[2])
		sky.add_child(s)


# ============================================================ 地面 / 道路
func _ground_color(x: float, z: float, noise: FastNoiseLite) -> Color:
	var r := sqrt(x * x + z * z)
	var nv := noise.get_noise_2d(x, z) * 0.5 + 0.5
	# 广场：浅色花岗岩方砖
	var c := C_GRANITE.lerp(Color("#d9d5c7"), nv)
	var a := 1.0
	# 中轴线上略浅的石带
	c = c.lerp(Color("#e3dfd1"), clampf(1.0 - absf(x) / 10.0, 0.0, 1.0) * 0.55)
	# 广场外是城市地面（沥青灰）
	if r > plaza_r:
		var k := smoothstep(plaza_r, plaza_r + 24.0, r)
		c = c.lerp(Color("#8d9197").lerp(Color("#7c8086"), nv), k)
		a = 1.0 - k * 0.95
	# 天安门前的石铺广场（金水桥一带）
	var cx := clampf(1.0 - maxf(absf(x) - 44.0, 0.0) / 18.0, 0.0, 1.0)
	var cz := clampf(1.0 - maxf(absf(z - 74.0) - 9.0, 0.0) / 8.0, 0.0, 1.0)
	var court := cx * cz
	c = c.lerp(Color("#d3cfc1"), court)
	a = maxf(a, court)
	if r > 120.0:
		c = c.lerp(Color("#6f747a"), smoothstep(120.0, 190.0, r))
	c.a = a
	return c


func _build_ground() -> void:
	var cell := 5.0
	var n := 40
	var cnt := n * 2 + 1
	var noise := FastNoiseLite.new()
	noise.seed = 5
	noise.frequency = 0.03
	var pos: Array = []
	var col: Array = []
	for iz in cnt:
		for ix in cnt:
			var x := (ix - n) * cell
			var z := (iz - n) * cell
			pos.append(Vector3(x, 0.0, z))
			col.append(_ground_color(x, z, noise))
	var b := MB.new()
	var up := Vector3.UP
	for iz in cnt - 1:
		for ix in cnt - 1:
			var i00 := iz * cnt + ix
			var i10 := i00 + 1
			var i01 := i00 + cnt
			var i11 := i01 + 1
			var p: Vector3 = pos[i00]
			if sqrt(p.x * p.x + p.z * p.z) > 192.0:
				continue
			b.tri_nc(pos[i00], pos[i01], pos[i11], up, up, up, col[i00], col[i01], col[i11])
			b.tri_nc(pos[i00], pos[i11], pos[i10], up, up, up, col[i00], col[i11], col[i10])
	var mi := MeshInstance3D.new()
	mi.mesh = b.build()
	mi.material_override = Mats.lp("ground", "paving", 1, 0.26, "asphalt")
	add_child(mi)


func _build_roads() -> void:
	var rb := _b("road")
	var lb := _b("paint")
	var road := Color("#5c6064")
	# 长安街（东西向，广场与天安门之间）
	_flat_rect(rb, 0.0, 62.0, 200.0, 5.0, 0.04, road)
	# 南侧横街
	_flat_rect(rb, 0.0, -94.0, 200.0, 6.0, 0.04, road)
	# 东西两条纵街
	for sx in [-1.0, 1.0]:
		_flat_rect(rb, float(sx) * 118.0, 0.0, 6.0, 200.0, 0.04, road)
	# 中央双黄线
	for k in 2:
		_flat_rect(lb, 0.0, 61.6 + float(k) * 0.8, 200.0, 0.14, 0.06, Color("#e8c43a"))
	# 车道虚线
	for i in range(-30, 31):
		var x := float(i) * 6.2
		for zz in [59.4, 64.6]:
			_flat_rect(lb, x, float(zz), 1.7, 0.14, 0.06, Color("#e9e9e4"))


# ============================================================ 广场本体
func _build_plaza() -> void:
	_ring_balustrade()
	_monument(Vector3(0, 0, 20))
	_flagpole(Vector3(0, 0, 42))
	for sx in [-1.0, 1.0]:
		var s := float(sx)
		for i in 5:
			_lamp(Vector3(s * 30.0, 0.0, -36.0 + float(i) * 18.0))
		for sz in [-1.0, 1.0]:
			_planter(Vector3(s * 19.0, 0.0, float(sz) * 36.0), 2.6)


## 广场边缘的汉白玉栏杆（代替原来的红白路缘，半径不变）
func _ring_balustrade() -> void:
	var s := _b("stone")
	var seg := 72
	var rad := plaza_r + 0.7
	var seglen := TAU * rad / float(seg)
	for i in seg:
		var ang := TAU * (float(i) + 0.5) / float(seg)
		var bas := Basis(Vector3.UP, -(ang + PI / 2.0))
		var c := Vector3(cos(ang) * rad, 0.0, sin(ang) * rad)
		s.box(Transform3D(bas, c + Vector3(0, 0.3, 0)), Vector3(seglen + 0.15, 0.6, 0.5), C_MARBLE_DK)
		s.box(Transform3D(bas, c + Vector3(0, 1.0, 0)), Vector3(seglen + 0.15, 0.26, 0.3), C_MARBLE)
		s.box(Transform3D(bas, c + Vector3(0, 1.32, 0)), Vector3(seglen + 0.15, 0.22, 0.46), C_MARBLE)
		var ang2 := TAU * float(i) / float(seg)
		var bas2 := Basis(Vector3.UP, -(ang2 + PI / 2.0))
		var c2 := Vector3(cos(ang2) * rad, 0.0, sin(ang2) * rad)
		s.box(Transform3D(bas2, c2 + Vector3(0, 0.75, 0)), Vector3(0.4, 1.5, 0.5), C_MARBLE)
		s.box(Transform3D(bas2, c2 + Vector3(0, 1.56, 0)), Vector3(0.54, 0.18, 0.62), C_MARBLE_DK)


## 人民英雄纪念碑
func _monument(p: Vector3) -> void:
	var s := _b("stone")
	var pa := _b("paint")
	# 两层月台
	s.box(MB.xf(p.x, 0.3, p.z), Vector3(13.6, 0.6, 13.6), C_MARBLE_DK)
	s.box(MB.xf(p.x, 0.95, p.z), Vector3(11.0, 0.7, 11.0), C_MARBLE)
	# 须弥座（中间一圈浮雕带）
	s.box(MB.xf(p.x, 1.9, p.z), Vector3(7.6, 1.2, 7.6), C_MARBLE)
	s.box(MB.xf(p.x, 2.9, p.z), Vector3(6.9, 0.8, 6.9), C_MARBLE_DK)
	s.box(MB.xf(p.x, 3.8, p.z), Vector3(7.4, 1.0, 7.4), C_MARBLE)
	# 碑身（向上微收）
	s.wedge(MB.xf(p.x, 11.0, p.z), Vector3(4.6, 13.4, 3.4), 0.0, C_MARBLE, 0.9)
	s.box(MB.xf(p.x, 17.95, p.z), Vector3(5.2, 0.5, 4.0), C_MARBLE_DK)
	_hip_roof(s, Vector3(p.x, 18.2, p.z), 3.0, 2.3, 1.6, 1.2, 0.35, 4, C_MARBLE, C_MARBLE_DK)
	# 月台栏杆
	var y := 1.3
	for sx in [-1.0, 1.0]:
		var sg := float(sx)
		_rail_line(s, Vector3(p.x + sg * 5.2, y, p.z - 5.2), Vector3(p.x + sg * 5.2, y, p.z + 5.2), 5, 1.0)
		_rail_line(s, Vector3(p.x - 5.2, y, p.z + sg * 5.2), Vector3(p.x + 5.2, y, p.z + sg * 5.2), 5, 1.0)
	# 朝北（面向天安门）的鎏金题字
	for i in 8:
		pa.box(MB.xf(p.x, 15.4 - float(i) * 1.15, p.z + 1.76), Vector3(0.95, 0.8, 0.12), C_GOLD)
	obstacles.append(Vector3(p.x, 6.8, p.z))


## 国旗杆（底座是贴地铺装，坦克可以开上去；只有红色栏座挡路）
func _flagpole(p: Vector3) -> void:
	var s := _b("stone")
	var m := _b("steel")
	var pa := _b("paint")
	s.box(MB.xf(p.x, 0.07, p.z), Vector3(12.0, 0.14, 12.0), C_MARBLE_DK)
	s.box(MB.xf(p.x, 0.17, p.z), Vector3(8.6, 0.14, 8.6), C_MARBLE)
	pa.cyl(MB.xf(p.x, 0.62, p.z), 1.65, 1.5, 0.9, 12, Color("#b8302a"), true)
	pa.cyl(MB.xf(p.x, 1.12, p.z), 1.7, 1.7, 0.14, 12, C_GOLD, true)
	m.cyl(MB.xf(p.x, 11.4, p.z), 0.24, 0.13, 20.0, 8, Color("#dcdcd8"), true)
	m.ico(MB.xf(p.x, 21.7, p.z), 0.3, 0, C_GOLD, 0.0, Callable(), true)
	obstacles.append(Vector3(p.x, 2.0, p.z))
	# 旗面（单独节点，便于飘动）
	var fn := Node3D.new()
	fn.position = Vector3(p.x, 17.6, p.z)
	add_child(fn)
	var fb := MB.new()
	fb.quad_uv(Vector3(0.2, -2.1, 0), Vector3(0.2, 2.1, 0), Vector3(6.5, 2.1, 0), Vector3(6.5, -2.1, 0),
		Color.WHITE, Vector2(0, 1), Vector2(0, 0), Vector2(1, 0), Vector2(1, 1))
	var mi := MeshInstance3D.new()
	mi.mesh = fb.build()
	mi.material_override = Mats.fx("flag")
	fn.add_child(mi)
	_flags.append(fn)


## 广场华灯（九球莲花灯）
func _lamp(p: Vector3) -> void:
	var s := _b("stone")
	var m := _b("steel")
	var g := _b("globe")
	s.cyl(MB.xf(p.x, 0.25, p.z), 1.15, 0.98, 0.5, 8, C_MARBLE_DK, true)
	s.cyl(MB.xf(p.x, 0.65, p.z), 0.88, 0.72, 0.4, 8, C_MARBLE, true)
	m.cyl(MB.xf(p.x, 4.05, p.z), 0.26, 0.19, 6.4, 8, Color("#e4e0d2"), true)
	m.box(MB.xf(p.x, 7.1, p.z), Vector3(2.9, 0.16, 0.34), Color("#d6d2c2"))
	m.box(MB.xf(p.x, 7.1, p.z), Vector3(0.34, 0.16, 2.9), Color("#d6d2c2"))
	g.ico(MB.xf(p.x, 8.1, p.z), 0.62, 0, Color("#fff8dc"), 0.0, Callable(), true)
	for k in 8:
		var a := TAU * float(k) / 8.0
		g.ico(MB.xf(p.x + cos(a) * 1.3, 7.35, p.z + sin(a) * 1.3), 0.4, 0, Color("#fff8dc"), 0.0, Callable(), true)
	obstacles.append(Vector3(p.x, 1.1, p.z))


## 花坛
func _planter(p: Vector3, r: float) -> void:
	var s := _b("stone")
	var pa := _b("paint")
	s.cyl(MB.xf(p.x, 0.2, p.z), r, r * 0.98, 0.4, 14, C_MARBLE, true)
	s.cyl(MB.xf(p.x, 0.52, p.z), r * 0.95, r * 0.88, 0.3, 14, C_MARBLE_DK, true)
	pa.cyl(MB.xf(p.x, 0.86, p.z), r * 0.86, r * 0.6, 0.45, 14, Color("#1d8a3c"), true)
	pa.cyl(MB.xf(p.x, 1.22, p.z), r * 0.62, r * 0.2, 0.5, 12, Color("#d8321f"), true)
	pa.ico(MB.xf(p.x, 1.56, p.z), r * 0.3, 0, Color("#f2c21a"), 0.08, Callable(), true)
	obstacles.append(Vector3(p.x, r + 0.15, p.z))


# ============================================================ 天安门城楼
func _build_gate() -> void:
	var red := _b("red")
	var st := _b("stone")
	var rf := _b("roof")
	var pa := _b("paint")
	var zf := GATE_FRONT - 0.18
	# 城台（略带收分）+ 压顶 + 石基座
	st.box(MB.xf(0, 0.35, GATE_Z), Vector3(73.0, 0.7, 15.6), C_MARBLE_DK)
	st.box(MB.xf(0, 0.85, GATE_Z), Vector3(72.4, 0.4, 14.9), C_MARBLE) # 须弥座上枋
	red.wedge(MB.xf(0, 0.7 + WALL_H * 0.5, GATE_Z), Vector3(72.0, WALL_H, 14.0), 0.0, C_WALL, 0.965)
	red.box(MB.xf(0, 0.7 + WALL_H + 0.35, GATE_Z), Vector3(73.6, 0.7, 15.2), C_WALL_DK)
	# 墙面壁柱（给大红墙打断，远看有竖向节奏）
	for i in 8:
		var px := lerpf(-32.0, 32.0, float(i) / 7.0)
		if absf(px) < 6.0:
			continue
		red.box(MB.xf(px, 0.7 + WALL_H * 0.5, GATE_FRONT - 0.12), Vector3(1.5, WALL_H - 1.0, 0.3), C_WALL_DK)
	# 墙顶压檐下的一排椽头
	_block_row(red, 0.7 + WALL_H - 0.5, GATE_FRONT - 0.3, -34.0, 34.0, 36,
		Vector3(0.6, 0.5, 0.5), C_ROOF_DK, C_WALL_DK)
	# 五个券门（石框 + 暗色门洞）
	st.box(MB.xf(0, 4.4, zf + 0.16), Vector3(8.6, 7.6, 0.26), C_MARBLE_DK)
	_door(st, 0.0, 0.5, zf + 0.16, 8.4, 8.0, C_MARBLE_DK)
	_door(red, 0.0, 0.7, zf, 7.2, 7.2, Color("#2b1b17"))
	for sx in [-1.0, 1.0]:
		var s := float(sx)
		for dx in [13.0, 25.0]:
			_door(st, s * float(dx), 0.5, zf + 0.16, 5.8, 6.8, C_MARBLE_DK)
			_door(red, s * float(dx), 0.7, zf, 4.8, 5.8, Color("#2b1b17"))
	# 城台顶的汉白玉栏杆
	var ty := 0.7 + WALL_H + 0.7
	_rail_line(st, Vector3(-35.0, ty, GATE_Z - 7.2), Vector3(35.0, ty, GATE_Z - 7.2), 26, 1.3)
	for sx2 in [-1.0, 1.0]:
		var s2 := float(sx2)
		_rail_line(st, Vector3(s2 * 35.0, ty, GATE_Z - 7.2), Vector3(s2 * 35.0, ty, GATE_Z + 7.2), 5, 1.3)
	# ---- 城楼 ----
	var by := ty + 0.3
	st.box(MB.xf(0, by, GATE_Z), Vector3(52.0, 0.6, 13.6), C_MARBLE_DK)
	var py := by + 0.3
	red.box(MB.xf(0, py + 3.6, GATE_Z), Vector3(46.0, 7.2, 10.4), C_WALL)
	# 檐柱
	for i in 11:
		var x := lerpf(-24.0, 24.0, float(i) / 10.0)
		for zz in [-5.6, 5.6]:
			red.cyl(MB.xf(x, py + 3.7, GATE_Z + float(zz)), 0.58, 0.54, 7.4, 8, C_WALL_DK, true)
	# 四角擎檐柱（粗一点，撑出屋檐的体量）
	for cx in [-24.6, 24.6]:
		for cz in [-5.6, 5.6]:
			red.cyl(MB.xf(float(cx), py + 3.7, GATE_Z + float(cz)), 0.72, 0.68, 7.4, 8, C_WALL_DK, true)
	# 门窗：金色棱花 + 十字窗棂
	for i in 10:
		var x2 := lerpf(-21.6, 21.6, float(i) / 9.0)
		pa.box(MB.xf(x2, py + 3.5, GATE_Z - 5.25), Vector3(3.1, 5.4, 0.3), Color("#c98f2a"))
		pa.box(MB.xf(x2, py + 3.5, GATE_Z - 5.15), Vector3(2.5, 4.8, 0.2), Color("#8e5f18"))
		for k in 3:
			pa.box(MB.xf(x2, py + 1.6 + float(k) * 1.9, GATE_Z - 5.08), Vector3(2.5, 0.16, 0.16), C_GOLD)
		for k2 in 2:
			pa.box(MB.xf(x2 - 0.62 + float(k2) * 1.24, py + 3.5, GATE_Z - 5.08), Vector3(0.16, 4.8, 0.16), C_GOLD)
	# 额枋彩画（青绿 + 金线 + 一排斗拱）
	pa.box(MB.xf(0, py + 7.5, GATE_Z), Vector3(50.0, 0.8, 12.0), C_EAVE)
	pa.box(MB.xf(0, py + 8.05, GATE_Z), Vector3(50.4, 0.35, 12.4), C_GOLD)
	_block_row(pa, py + 8.6, GATE_Z - 5.9, -24.0, 24.0, 25, Vector3(0.78, 0.9, 1.5), C_EAVE2, C_ROOF_DK)
	pa.box(MB.xf(0, py + 9.25, GATE_Z), Vector3(50.6, 0.3, 12.6), C_GOLD)
	# 重檐：下层腰檐 + 上层庑殿顶
	_eave_skirt(rf, Vector3(0, py + 9.4, GATE_Z), 29.0, 10.0, 21.0, 6.0, 2.8, 1.2, 6, C_ROOF, C_ROOF_DK)
	# 下层檐口的瓦当（一排小圆头）
	_block_row(rf, py + 9.3, GATE_Z - 9.9, -28.0, 28.0, 30, Vector3(0.62, 0.42, 0.4), C_ROOF, C_ROOF_DK)
	# 平座栏杆
	_rail_line(st, Vector3(-20.0, py + 12.2, GATE_Z - 5.9), Vector3(20.0, py + 12.2, GATE_Z - 5.9), 14, 0.9)
	red.box(MB.xf(0, py + 13.5, GATE_Z), Vector3(39.0, 2.8, 8.0), C_WALL)
	# 上层小窗
	for i in 7:
		var x3 := lerpf(-15.0, 15.0, float(i) / 6.0)
		_window_z(pa, x3, py + 13.6, GATE_Z - 4.0, 2.2, 1.7, Color("#c98f2a"), Color("#6e4a14"))
	pa.box(MB.xf(0, py + 15.1, GATE_Z), Vector3(40.0, 0.7, 9.0), C_EAVE)
	_block_row(pa, py + 15.7, GATE_Z - 4.3, -18.0, 18.0, 19, Vector3(0.7, 0.8, 1.2), C_EAVE2, C_ROOF_DK)
	_hip_roof(rf, Vector3(0, py + 16.3, GATE_Z), 24.0, 8.4, 4.6, 9.5, 1.3, 6, C_ROOF, C_ROOF_DK)
	_block_row(rf, py + 16.2, GATE_Z - 8.3, -23.0, 23.0, 26, Vector3(0.6, 0.4, 0.38), C_ROOF, C_ROOF_DK)
	# 垂脊上的脊兽（四条垂脊各一串小兽，改变屋顶剪影）
	for sx4 in [-1.0, 1.0]:
		var s4 := float(sx4)
		for k3 in 4:
			var t4 := float(k3) / 3.0
			var bx := lerpf(s4 * 9.5, s4 * 23.0, t4)
			var bz := lerpf(0.0, 7.9, t4)
			var by2 := lerpf(py + 20.5, py + 16.6, t4)
			for sz4 in [-1.0, 1.0]:
				rf.box(MB.xf(bx, by2, GATE_Z + float(sz4) * bz), Vector3(0.6, 0.78, 0.6), C_ROOF_DK)
	# 檐下红灯笼
	for i in 8:
		var lx := lerpf(-19.0, 19.0, float(i) / 7.0)
		pa.ico(Transform3D(Basis.from_scale(Vector3(1.0, 0.78, 1.0)), Vector3(lx, py + 6.6, GATE_Z - 8.2)),
			0.62, 0, C_RED, 0.0, Callable(), true)
		pa.box(MB.xf(lx, py + 7.2, GATE_Z - 8.2), Vector3(0.3, 0.5, 0.3), C_GOLD)
	_build_gate_panels()
	_build_golden_water()


## 城楼正中的画像与两侧标语牌（独立贴图面片）
func _build_gate_panels() -> void:
	var zp := GATE_FRONT - 0.35
	var pb := MB.new()
	_panel_quad(pb, 0.0, 11.4, zp, 2.1, 2.5)
	var pmi := MeshInstance3D.new()
	pmi.mesh = pb.build()
	pmi.material_override = Mats.fx("portrait")
	add_child(pmi)
	var bb := MB.new()
	for sx in [-1.0, 1.0]:
		_panel_quad(bb, float(sx) * 14.5, 11.4, zp, 8.0, 1.3)
	var bmi := MeshInstance3D.new()
	bmi.mesh = bb.build()
	bmi.material_override = Mats.fx("banner")
	add_child(bmi)
	# 画像与标语牌的外框
	var st := _b("stone")
	st.box(MB.xf(0, 11.4, zp + 0.14), Vector3(4.8, 5.6, 0.2), C_MARBLE_DK)
	for sx2 in [-1.0, 1.0]:
		st.box(MB.xf(float(sx2) * 14.5, 11.4, zp + 0.14), Vector3(16.6, 3.0, 0.2), C_MARBLE_DK)


## 金水河与五座金水桥、华表、石狮
func _build_golden_water() -> void:
	var st := _b("stone")
	var pa := _b("paint")
	# 河面
	_flat_rect(pa, 0.0, 74.5, 34.0, 2.3, 0.07, Color("#3f6f74"))
	_flat_rect(pa, 0.0, 74.5, 34.4, 2.6, 0.05, C_MARBLE_DK)
	# 五桥
	var bridges: Array = [[0.0, 3.6], [-12.0, 2.5], [12.0, 2.5], [-23.0, 2.3], [23.0, 2.3]]
	for br in bridges:
		var bd: Array = br
		var bx := float(bd[0])
		var bw := float(bd[1])
		st.box(MB.xf(bx, 0.52, 74.5), Vector3(bw * 2.0, 1.0, 8.2), C_MARBLE)
		for sz in [-1.0, 1.0]:
			var s := float(sz)
			_rail_line(st, Vector3(bx - bw, 1.0, 74.5 + s * 3.8), Vector3(bx + bw, 1.0, 74.5 + s * 3.8),
				maxi(2, int(bw)), 0.9)
	# 华表
	for sx in [-1.0, 1.0]:
		var s2 := float(sx)
		var hx := s2 * 30.0
		st.box(MB.xf(hx, 0.4, 70.5), Vector3(3.0, 0.8, 3.0), C_MARBLE_DK)
		st.cyl(MB.xf(hx, 6.0, 70.5), 0.62, 0.5, 10.4, 8, C_MARBLE, true)
		st.box(MB.xf(hx, 9.4, 70.5), Vector3(5.2, 0.4, 1.1), C_MARBLE)
		st.cyl(MB.xf(hx, 11.5, 70.5), 1.1, 1.0, 0.5, 8, C_MARBLE_DK, true)
		st.ico(MB.xf(hx, 12.2, 70.5), 0.55, 0, C_MARBLE, 0.0, Callable(), true)
		# 石狮
		var lx := s2 * 6.5
		st.box(MB.xf(lx, 0.55, 69.2), Vector3(2.2, 1.1, 2.8), C_MARBLE_DK)
		st.ico(Transform3D(Basis.from_scale(Vector3(1.0, 0.9, 1.5)), Vector3(lx, 1.9, 69.2)),
			1.0, 0, C_MARBLE, 0.04, Callable(), true)
		st.ico(MB.xf(lx, 2.8, 68.3), 0.6, 0, C_MARBLE, 0.04, Callable(), true)
	# 城台两侧延伸的红墙
	var red := _b("red")
	for sx3 in [-1.0, 1.0]:
		var s3 := float(sx3)
		red.box(MB.xf(s3 * 92.0, 4.0, GATE_Z + 1.0), Vector3(56.0, 8.0, 7.0), C_WALL)
		red.box(MB.xf(s3 * 92.0, 8.4, GATE_Z + 1.0), Vector3(57.0, 0.9, 8.2), C_WALL_DK)


# ============================================================ 东西两侧建筑
func _build_wings() -> void:
	_hall(-1.0, 11, C_BUFF)                       # 西：人民大会堂
	_hall(1.0, 9, C_BUFF.lerp(Color("#cfc5a8"), 0.5))  # 东：国家博物馆


## 柱廊式大型石建筑，立面朝向广场
func _hall(sx: float, ncol: int, tint: Color) -> void:
	var bf := _b("buff")
	var st := _b("stone")
	var pa := _b("paint")
	var depth := 46.0
	var width := 96.0
	var fx := sx * 60.0
	var bodyc := sx * (60.0 + depth * 0.5)
	var h := 22.0
	# 踏步
	for i in 4:
		var t := float(i)
		st.box(MB.xf(fx - sx * (6.0 - t * 1.5), 0.3 + t * 0.6, 0.0),
			Vector3(1.6, 0.6 + t * 1.2, width * 0.5 - t * 3.0), C_MARBLE_DK)
	# 台基 + 主体
	st.box(MB.xf(bodyc, 1.5, 0.0), Vector3(depth + 4.0, 3.0, width + 3.0), C_MARBLE_DK)
	bf.box(MB.xf(bodyc, 3.0 + h * 0.5, 0.0), Vector3(depth, h, width), tint)
	# 柱廊：柱础 + 柱身 + 柱头
	for i in ncol:
		var z := lerpf(-34.0, 34.0, float(i) / float(ncol - 1))
		st.box(MB.xf(fx + sx * 1.6, 3.6, z), Vector3(4.0, 1.2, 3.8), C_MARBLE_DK)     # 柱础
		bf.box(MB.xf(fx + sx * 1.6, 12.0, z), Vector3(3.2, 16.0, 3.0), tint.lightened(0.12))
		bf.box(MB.xf(fx + sx * 1.6, 19.6, z), Vector3(3.6, 0.9, 3.4), tint.lightened(0.2)) # 柱颈
		st.box(MB.xf(fx + sx * 1.6, 20.5, z), Vector3(4.2, 0.8, 4.0), C_MARBLE_DK)    # 柱头
	# 柱廊后的大门（深色门洞 + 稍亮的门扇）
	var ndoor := maxi(2, ncol - 4)
	for i in ndoor:
		var dz := lerpf(-24.0, 24.0, float(i) / float(maxi(1, ndoor - 1)))
		bf.box(MB.xf(fx + sx * 0.05, 7.2, dz), Vector3(0.4, 8.4, 3.8), Color("#443e32"))
		bf.box(MB.xf(fx - sx * 0.12, 7.0, dz), Vector3(0.4, 7.6, 3.0), Color("#6e6452"))
	# 正立面：柱廊两侧露出来的窗带（两层）
	for row in 2:
		for i in 4:
			var wz := lerpf(37.0, 45.0, float(i) / 3.0)
			for szs in [-1.0, 1.0]:
				_window_x(bf, fx, 9.0 + float(row) * 6.8, float(szs) * wz, 3.0, 3.6,
					C_BUFF_DK, Color("#55606b"))
	# 南北侧立面的窗带（从广场上斜着看得到）
	for szf in [-1.0, 1.0]:
		var sf := float(szf)
		for i in 7:
			var wx := bodyc + lerpf(-17.0, 17.0, float(i) / 6.0)
			for row2 in 2:
				_window_z(bf, wx, 9.0 + float(row2) * 6.8, sf * (width * 0.5), 3.0, 3.6,
					C_BUFF_DK, Color("#55606b"), sf)
	# 檐部与绿琉璃檐口
	bf.box(MB.xf(fx + sx * 1.6, 22.4, 0.0), Vector3(5.0, 3.6, 72.0), C_BUFF_DK)
	# 檐下齿饰
	_block_row_z(bf, fx - sx * 0.6, 21.2, -34.0, 34.0, 40, Vector3(0.9, 0.9, 1.3), tint.lightened(0.18), C_BUFF_DK)
	pa.box(MB.xf(fx + sx * 1.6, 24.6, 0.0), Vector3(6.4, 1.3, 74.0), Color("#2f7a52"))
	pa.box(MB.xf(bodyc, 3.0 + h + 0.7, 0.0), Vector3(depth + 3.2, 1.4, width + 3.2), Color("#2f7a52"))
	bf.box(MB.xf(bodyc, 3.0 + h + 2.2, 0.0), Vector3(depth, 1.6, width), tint)
	# 屋顶旗杆
	for fz in [-30.0, 30.0]:
		bf.cyl(MB.xf(fx + sx * 3.0, 30.0, float(fz)), 0.18, 0.12, 10.0, 6, C_MARBLE, true)
	# 立面国徽
	pa.cyl(Transform3D(Basis(Vector3.BACK, PI / 2.0), Vector3(fx - sx * 1.2, 23.4, 0.0)),
		2.4, 2.4, 0.5, 12, C_RED, true)
	pa.cyl(Transform3D(Basis(Vector3.BACK, PI / 2.0), Vector3(fx - sx * 1.5, 23.4, 0.0)),
		1.5, 1.5, 0.4, 10, C_GOLD, true)
	# 南北两翼
	for sz in [-1.0, 1.0]:
		var s := float(sz)
		bf.box(MB.xf(bodyc, 11.0, s * (width * 0.5 + 12.0)), Vector3(depth - 6.0, 16.0, 24.0), tint)
		pa.box(MB.xf(bodyc, 19.7, s * (width * 0.5 + 12.0)), Vector3(depth - 3.0, 1.2, 27.0), Color("#2f7a52"))


# ============================================================ 南端：纪念堂 / 正阳门
func _build_south() -> void:
	var bf := _b("buff")
	var st := _b("stone")
	var rf := _b("roof")
	var pa := _b("paint")
	var br := _b("brick")
	var red := _b("red")
	# ---- 纪念堂 ----
	var mz := -74.0
	st.box(MB.xf(0, 1.0, mz), Vector3(56.0, 2.0, 40.0), C_MARBLE_DK)
	st.box(MB.xf(0, 2.4, mz), Vector3(48.0, 1.2, 33.0), C_MARBLE)
	bf.box(MB.xf(0, 10.5, mz), Vector3(40.0, 15.0, 26.0), C_BUFF)
	for i in 8:
		var x := lerpf(-16.0, 16.0, float(i) / 7.0)
		bf.box(MB.xf(x, 9.5, mz + 13.6), Vector3(2.4, 13.0, 2.4), C_BUFF.lightened(0.12))
	pa.box(MB.xf(0, 17.0, mz + 13.6), Vector3(38.0, 2.0, 3.4), C_EAVE)
	_eave_skirt(rf, Vector3(0, 18.2, mz), 23.0, 16.5, 21.0, 14.5, 1.8, 0.9, 5, C_ROOF, C_ROOF_DK)
	bf.box(MB.xf(0, 21.0, mz), Vector3(38.0, 3.0, 24.0), C_BUFF)
	_eave_skirt(rf, Vector3(0, 22.4, mz), 22.0, 15.5, 19.5, 13.0, 1.7, 0.8, 5, C_ROOF, C_ROOF_DK)
	pa.box(MB.xf(0, 24.3, mz), Vector3(36.0, 0.9, 23.0), C_ROOF_DK)
	# ---- 正阳门城楼 ----
	var qz := -108.0
	br.box(MB.xf(0, 8.0, qz), Vector3(52.0, 16.0, 22.0), C_GREY)
	br.box(MB.xf(0, 16.5, qz), Vector3(53.5, 1.0, 23.0), C_GREY_DK)
	_door(br, 0.0, 0.6, qz + 11.2, 7.0, 9.0, Color("#241f1c"))
	red.box(MB.xf(0, 21.0, qz), Vector3(34.0, 8.0, 14.0), Color("#8e3a2a"))
	for i in 9:
		var wx := lerpf(-14.0, 14.0, float(i) / 8.0)
		pa.box(MB.xf(wx, 21.6, qz + 7.2), Vector3(2.0, 2.8, 0.4), Color("#efe9dc"))
	_eave_skirt(br, Vector3(0, 25.2, qz), 20.5, 10.5, 18.0, 8.6, 1.6, 0.8, 5, C_GREY, C_GREY_DK)
	red.box(MB.xf(0, 27.8, qz), Vector3(28.0, 3.6, 11.0), Color("#8e3a2a"))
	_hip_roof(br, Vector3(0, 29.6, qz), 18.0, 9.5, 4.0, 7.0, 1.1, 5, C_GREY, C_GREY_DK)
	# ---- 箭楼 ----
	var az := -136.0
	br.box(MB.xf(0, 9.0, az), Vector3(44.0, 18.0, 20.0), C_GREY)
	br.box(MB.xf(0, 24.5, az), Vector3(34.0, 13.0, 15.0), Color("#7e8389"))
	for row in 4:
		for i in 8:
			var ex := lerpf(-13.0, 13.0, float(i) / 7.0)
			pa.box(MB.xf(ex, 19.5 + float(row) * 3.0, az + 7.6), Vector3(1.4, 1.9, 0.4), Color("#2a2a2e"))
	_hip_roof(br, Vector3(0, 31.0, az), 19.0, 9.0, 4.2, 7.5, 1.1, 5, C_GREY, C_GREY_DK)


# ============================================================ 行道树
func _poplar(p: Vector3, s: float, rng: RandomNumberGenerator) -> void:
	var tr := _b("bark")
	var lv := _b("leaf")
	tr.cyl(MB.xf(p.x, 2.3 * s, p.z), 0.26 * s, 0.36 * s, 4.6 * s, 6, Color("#8d6a45"), true)
	var g := rng.randf_range(-0.05, 0.05)
	for i in 3:
		var yy := (5.4 + float(i) * 2.5) * s
		var rr := (2.2 - float(i) * 0.5) * s
		lv.ico(Transform3D(Basis.from_scale(Vector3(1.0, 1.3, 1.0)), Vector3(p.x, yy, p.z)),
			rr, 0, Color(0.30 + g, 0.60 + g, 0.27 + g), 0.06, Callable(), true)


func _build_trees() -> void:
	var rng := RandomNumberGenerator.new()
	rng.seed = 12345
	# 长安街北侧（避开天安门前广场）
	for i in 30:
		var x := -170.0 + float(i) * 11.6
		if absf(x) < 50.0:
			continue
		_poplar(Vector3(x, 0, 69.0), rng.randf_range(1.1, 1.5), rng)
	# 南侧横街两旁
	for i in 30:
		var x2 := -170.0 + float(i) * 11.6
		if absf(x2) < 30.0:
			continue
		_poplar(Vector3(x2, 0, -88.0), rng.randf_range(1.0, 1.4), rng)
	# 东西纵街
	for sx in [-1.0, 1.0]:
		var s := float(sx)
		for i in 22:
			var z := -150.0 + float(i) * 13.0
			if absf(z) < 56.0:
				continue
			_poplar(Vector3(s * 126.0, 0, z), rng.randf_range(1.0, 1.4), rng)
	# 远处零散绿化
	for i in 60:
		var a := rng.randf() * TAU
		var r := rng.randf_range(95.0, 178.0)
		_poplar(Vector3(cos(a) * r, 0, sin(a) * r), rng.randf_range(1.0, 1.7), rng)


# ============================================================ 远景城市
func _build_skyline() -> void:
	var rng := RandomNumberGenerator.new()
	rng.seed = 77
	var ci := _b("city")
	# 近处的灰色低矮院落
	for i in 70:
		var a := rng.randf() * TAU
		var r := rng.randf_range(96.0, 126.0)
		var x := cos(a) * r
		var z := sin(a) * r
		var w := rng.randf_range(10.0, 20.0)
		var d := rng.randf_range(8.0, 15.0)
		var hh := rng.randf_range(5.0, 9.0)
		var bas := Basis(Vector3.UP, a)
		ci.box(Transform3D(bas, Vector3(x, hh * 0.5, z)), Vector3(w, hh, d), Color("#8c8f92").lerp(Color("#9b968a"), rng.randf()))
		ci.box(Transform3D(bas, Vector3(x, hh + 0.4, z)), Vector3(w + 1.2, 0.8, d + 1.2), C_GREY_DK)
	# 远处高楼天际线
	for i in 95:
		var a2 := TAU * float(i) / 95.0 + rng.randf_range(-0.025, 0.025)
		var r2 := rng.randf_range(132.0, 184.0)
		var x2 := cos(a2) * r2
		var z2 := sin(a2) * r2
		var hh2 := rng.randf_range(16.0, 60.0)
		var w2 := rng.randf_range(13.0, 30.0)
		var d2 := rng.randf_range(13.0, 26.0)
		var c := Color("#949da7").lerp(Color("#a9a79b"), rng.randf())
		var bas2 := Basis(Vector3.UP, a2)
		ci.box(Transform3D(bas2, Vector3(x2, hh2 * 0.5, z2)), Vector3(w2, hh2, d2), c)
		if rng.randf() < 0.32:
			ci.box(Transform3D(bas2, Vector3(x2, hh2 + 2.5, z2)), Vector3(w2 * 0.42, 5.0, d2 * 0.42), c.darkened(0.12))


# ============================================================ 战场场景（对战模式）
func _build_war() -> void:
	_build_war_env()
	_build_sky()
	_build_war_ground()
	_build_war_props()
	_build_war_perimeter()
	_build_war_horizon()
	_flush()
	_build_clouds()


func _build_war_env() -> void:
	var env := Environment.new()
	env.background_mode = Environment.BG_COLOR
	env.background_color = WAR_FOG_COL
	env.fog_enabled = true
	env.fog_mode = Environment.FOG_MODE_DEPTH
	env.fog_light_color = WAR_FOG_COL
	env.fog_depth_begin = 62.0
	env.fog_depth_end = 250.0
	env.fog_depth_curve = 1.0
	var we := WorldEnvironment.new()
	we.environment = env
	add_child(we)


func _war_ground_color(x: float, z: float, noise: FastNoiseLite) -> Color:
	var r := sqrt(x * x + z * z)
	var nv := noise.get_noise_2d(x, z) * 0.5 + 0.5
	var c := Color("#9e8c66").lerp(Color("#7b6a49"), nv)
	# 车辙 / 焦土
	var burn := noise.get_noise_2d(x * 2.3 + 90.0, z * 2.3) * 0.5 + 0.5
	c = c.lerp(Color("#5d5240"), smoothstep(0.58, 0.85, burn) * 0.7)
	var a := 1.0
	if r > plaza_r:
		var k := smoothstep(plaza_r, plaza_r + 30.0, r)
		c = c.lerp(Color("#71674f"), k)
		a = 1.0 - k * 0.9
	if r > 150.0:
		c = c.lerp(Color("#6b6454"), smoothstep(150.0, 235.0, r))
	c.a = a
	return c


func _build_war_ground() -> void:
	var cell := 7.0
	var n := 36
	var cnt := n * 2 + 1
	var noise := FastNoiseLite.new()
	noise.seed = 17
	noise.frequency = 0.022
	var pos: Array = []
	var col: Array = []
	for iz in cnt:
		for ix in cnt:
			var x := (ix - n) * cell
			var z := (iz - n) * cell
			pos.append(Vector3(x, 0.0, z))
			col.append(_war_ground_color(x, z, noise))
	var b := MB.new()
	var up := Vector3.UP
	for iz in cnt - 1:
		for ix in cnt - 1:
			var i00 := iz * cnt + ix
			var i10 := i00 + 1
			var i01 := i00 + cnt
			var i11 := i01 + 1
			var p: Vector3 = pos[i00]
			if sqrt(p.x * p.x + p.z * p.z) > 244.0:
				continue
			b.tri_nc(pos[i00], pos[i01], pos[i11], up, up, up, col[i00], col[i01], col[i11])
			b.tri_nc(pos[i00], pos[i11], pos[i10], up, up, up, col[i00], col[i11], col[i10])
	var mi := MeshInstance3D.new()
	mi.mesh = b.build()
	mi.material_override = Mats.lp("war_ground", "dirt", 1, 0.3, "rock")
	add_child(mi)


# ---------------- 掩体构件 ----------------
## 沙袋墙：错缝叠放的小圆柱
func _sandbags(p: Vector3, ang: float, n: int, rows: int) -> void:
	var b := _b("sandbag")
	var bas := Basis(Vector3.UP, ang)
	for row in rows:
		var y := 0.34 + float(row) * 0.56
		var off := 0.0 if row % 2 == 0 else 0.52
		var cnt := n if row % 2 == 0 else n - 1
		for i in cnt:
			var lx := (float(i) - float(cnt - 1) * 0.5) * 1.04 + off * 0.0
			var local := Vector3(lx, y, 0.0)
			var c := Color("#9c8f6a").lerp(Color("#7d7250"), float((i * 7 + row * 3) % 5) / 4.0)
			var t := Transform3D(bas * Basis(Vector3.UP, 0.12 * sin(float(i) * 2.3)), p + bas * local)
			b.cyl(Transform3D(t.basis * Basis(Vector3.BACK, PI / 2.0), t.origin), 0.3, 0.3, 1.0, 6, c, true)


## 混凝土隔离墩
func _barrier(p: Vector3, ang: float) -> void:
	var b := _b("concrete")
	var bas := Basis(Vector3.UP, ang)
	b.wedge(Transform3D(bas, p + Vector3(0, 0.75, 0)), Vector3(4.6, 1.5, 1.5), 0.0, Color("#b4b0a4"), 0.55)
	b.box(Transform3D(bas, p + Vector3(0, 1.56, 0)), Vector3(2.7, 0.14, 0.95), Color("#8e8a7e"))
	for sx in [-1.0, 1.0]:
		b.box(Transform3D(bas, p + Vector3(float(sx) * 1.9, 0.5, 0)), Vector3(0.3, 1.0, 1.6), Color("#9a968a"))


## 反坦克拒马（三根交叉的工字钢）
func _hedgehog(p: Vector3, ang: float) -> void:
	var b := _b("rust")
	var c := Color("#7a6a52")
	for i in 3:
		var a := ang + TAU * float(i) / 3.0
		var axis := Vector3(cos(a), 0.0, sin(a)).cross(Vector3.UP).normalized()
		var bas := Basis(axis, 0.62)
		b.box(Transform3D(bas, p + Vector3(0, 1.1, 0)), Vector3(0.3, 0.3, 4.4), c)


## 油桶
func _barrel(p: Vector3, col: Color) -> void:
	var b := _b("rust")
	b.cyl(MB.xf(p.x, 0.62, p.z), 0.55, 0.55, 1.24, 8, col, true)
	for y in [0.3, 0.62, 0.94]:
		b.cyl(MB.xf(p.x, float(y), p.z), 0.58, 0.58, 0.1, 8, col.darkened(0.25), true)


## 碉堡：混凝土方盒 + 射击孔
func _bunker(p: Vector3, ang: float) -> void:
	var b := _b("concrete")
	var d := _b("paint")
	var bas := Basis(Vector3.UP, ang)
	b.wedge(Transform3D(bas, p + Vector3(0, 1.5, 0)), Vector3(7.5, 3.0, 6.0), 0.0, Color("#a9a497"), 0.82)
	b.box(Transform3D(bas, p + Vector3(0, 3.2, 0)), Vector3(8.2, 0.5, 6.6), Color("#8d8a7d"))
	# 射击孔
	for sz in [-1.0, 1.0]:
		d.box(Transform3D(bas, p + bas * Vector3(0, 2.1, float(sz) * 3.05)), Vector3(4.2, 0.7, 0.3), Color("#1c1a16"))
	# 顶上的沙袋
	for i in 5:
		var lx := (float(i) - 2.0) * 1.5
		b.cyl(Transform3D(bas * Basis(Vector3.BACK, PI / 2.0), p + bas * Vector3(lx, 3.7, 2.4)),
			0.32, 0.32, 1.1, 6, Color("#938767"), true)


## 被击毁的坦克残骸
func _wreck(p: Vector3, ang: float) -> void:
	var b := _b("rust")
	var bas := Basis(Vector3.UP, ang)
	var burnt := Color("#4a443a")
	var burnt2 := Color("#39342c")
	b.box(Transform3D(bas, p + Vector3(0, 0.5, 0)), Vector3(3.4, 1.0, 6.0), burnt)
	b.wedge(Transform3D(bas, p + Vector3(0, 1.3, 0)), Vector3(3.0, 0.7, 5.0), 1.0, burnt2)
	for sx in [-1.0, 1.0]:
		b.box(Transform3D(bas, p + bas * Vector3(float(sx) * 1.8, 0.5, 0)), Vector3(0.8, 1.1, 5.6), burnt2)
	# 歪掉的炮塔
	var tb := Basis(Vector3.UP, ang + 0.9) * Basis(Vector3.BACK, 0.22)
	b.cyl(Transform3D(tb, p + Vector3(0, 1.9, 0)), 1.25, 1.0, 0.9, 8, burnt, true)
	b.cyl(Transform3D(tb * Basis(Vector3.RIGHT, PI / 2.0), p + tb * Vector3(0, 0.1, 2.3)),
		0.17, 0.15, 3.4, 6, burnt2, true)


## 弹坑（只是地面贴花，不挡路）
func _crater(p: Vector3, r: float) -> void:
	var b := _b("paint")
	_flat_rect(b, p.x, p.z, r, r, 0.05, Color("#4e4538"))
	b.cyl(MB.xf(p.x, 0.12, p.z), r * 0.78, r * 0.95, 0.24, 9, Color("#6a5d48"), true)


func _build_war_props() -> void:
	var rng := RandomNumberGenerator.new()
	rng.seed = 2024
	# 6 个出生点（玩家 + 5 个敌人），均匀分布在外圈
	for i in 6:
		var a := TAU * float(i) / 6.0
		spawns.append(Vector3(cos(a) * plaza_r * 0.70, 0.0, sin(a) * plaza_r * 0.70))
	var tries := 0
	while obstacles.size() < 56 and tries < 4000:
		tries += 1
		var a2 := rng.randf() * TAU
		var rad := sqrt(rng.randf()) * (plaza_r - 9.0)
		var p := Vector3(cos(a2) * rad, 0.0, sin(a2) * rad)
		var roll := rng.randf()
		var orad := 2.6
		if roll < 0.18:
			orad = 4.6      # 碉堡
		elif roll < 0.40:
			orad = 3.0      # 沙袋墙
		elif roll < 0.60:
			orad = 2.7      # 隔离墩
		elif roll < 0.76:
			orad = 1.9      # 拒马
		elif roll < 0.88:
			orad = 0.95     # 油桶
		else:
			orad = 3.2      # 残骸
		# 出生点要留空
		var ok := true
		for s in spawns:
			if Vector2(p.x - (s as Vector3).x, p.z - (s as Vector3).z).length() < orad + 13.0:
				ok = false
				break
		if ok:
			for o in obstacles:
				var ov: Vector3 = o
				if Vector2(ov.x - p.x, ov.z - p.z).length() < ov.y + orad + 5.5:
					ok = false
					break
		if not ok:
			continue
		obstacles.append(Vector3(p.x, orad, p.z))
		var ang := rng.randf() * TAU
		if roll < 0.18:
			_bunker(p, ang)
		elif roll < 0.40:
			_sandbags(p, ang, rng.randi_range(4, 6), rng.randi_range(2, 3))
		elif roll < 0.60:
			_barrier(p, ang)
		elif roll < 0.76:
			_hedgehog(p, ang)
		elif roll < 0.88:
			_barrel(p, Color("#6e7a52") if rng.randf() < 0.5 else Color("#8a5a3a"))
		else:
			_wreck(p, ang)
	# 弹坑与零散杂物（无碰撞）
	for i in 40:
		var a3 := rng.randf() * TAU
		var r3 := sqrt(rng.randf()) * (plaza_r - 4.0)
		_crater(Vector3(cos(a3) * r3, 0.0, sin(a3) * r3), rng.randf_range(1.6, 3.6))


## 外圈：土堤 + 铁丝网桩，明确标出可驾驶边界
func _build_war_perimeter() -> void:
	var b := _b("sandbag")
	var m := _b("rust")
	var seg := 84
	var rad := plaza_r + 1.0
	var seglen := TAU * rad / float(seg)
	for i in seg:
		var ang := TAU * (float(i) + 0.5) / float(seg)
		var bas := Basis(Vector3.UP, -(ang + PI / 2.0))
		var c := Vector3(cos(ang) * rad, 0.0, sin(ang) * rad)
		# 土堤
		b.wedge(Transform3D(bas, c + Vector3(0, 0.8, 0)), Vector3(seglen + 0.2, 1.6, 3.2), 0.0,
			Color("#8a7c58").lerp(Color("#6f6446"), float(i % 3) / 2.0), 0.5)
		# 沙袋压顶
		b.cyl(Transform3D(bas * Basis(Vector3.BACK, PI / 2.0), c + Vector3(0, 1.75, 0)),
			0.32, 0.32, seglen * 0.9, 6, Color("#9a8d69"), true)
	# 铁丝网桩
	for i in 42:
		var ang2 := TAU * float(i) / 42.0
		var c2 := Vector3(cos(ang2) * (rad - 2.6), 0.0, sin(ang2) * (rad - 2.6))
		m.cyl(MB.xf(c2.x, 1.1, c2.z), 0.12, 0.1, 2.2, 5, Color("#6b6355"), true)
		m.box(MB.xf(c2.x, 2.15, c2.z), Vector3(0.9, 0.1, 0.1), Color("#5e5749"))


## 远景：废墟、焦树、黑烟柱
func _build_war_horizon() -> void:
	var rng := RandomNumberGenerator.new()
	rng.seed = 404
	var ci := _b("city")
	var tr := _b("bark")
	for i in 60:
		var a := rng.randf() * TAU
		var r := rng.randf_range(plaza_r + 26.0, 215.0)
		var x := cos(a) * r
		var z := sin(a) * r
		var w := rng.randf_range(9.0, 26.0)
		var d := rng.randf_range(9.0, 20.0)
		var h := rng.randf_range(6.0, 34.0)
		var bas := Basis(Vector3.UP, a + rng.randf_range(-0.4, 0.4))
		var c := Color("#8b8274").lerp(Color("#6f6a60"), rng.randf())
		# 被打塌的楼：主体 + 残缺的上半截
		ci.box(Transform3D(bas, Vector3(x, h * 0.5, z)), Vector3(w, h, d), c)
		if rng.randf() < 0.65:
			ci.box(Transform3D(bas, Vector3(x + w * 0.2, h + h * 0.22, z)),
				Vector3(w * rng.randf_range(0.3, 0.7), h * 0.45, d * 0.8), c.darkened(0.08))
	# 焦树
	for i in 40:
		var a2 := rng.randf() * TAU
		var r2 := rng.randf_range(plaza_r + 10.0, 200.0)
		var p := Vector3(cos(a2) * r2, 0.0, sin(a2) * r2)
		var hh := rng.randf_range(4.0, 9.0)
		tr.cyl(MB.xf(p.x, hh * 0.5, p.z), 0.3, 0.14, hh, 5, Color("#4f4538"), true)
		for k in 3:
			var ba := TAU * float(k) / 3.0 + rng.randf()
			tr.box(Transform3D(Basis(Vector3(cos(ba), 0, sin(ba)), 0.9),
				p + Vector3(cos(ba) * 0.8, hh * 0.82, sin(ba) * 0.8)), Vector3(0.16, 0.16, 2.0), Color("#443b2f"))
	# 黑烟柱（公告牌）
	for i in 7:
		var a3 := rng.randf() * TAU
		var r3 := rng.randf_range(110.0, 200.0)
		for k2 in 5:
			var mi := MeshInstance3D.new()
			var q := QuadMesh.new()
			var sz := 16.0 + float(k2) * 7.0
			q.size = Vector2(sz, sz)
			mi.mesh = q
			var mm := Mats.fx("puff", true, Color(0.16, 0.15, 0.14, 1.0).lerp(Color(0.5, 0.48, 0.45), float(k2) / 4.0))
			mi.material_override = mm
			mi.position = Vector3(cos(a3) * r3, 7.0 + float(k2) * 9.0, sin(a3) * r3)
			add_child(mi)


# ============================================================ 花带 / 云
func _build_sprites() -> void:
	var rng := RandomNumberGenerator.new()
	rng.seed = 404
	var b := MB.new()
	var spots: Array = []
	# 纪念碑两侧花带
	for sx in [-1.0, 1.0]:
		for i in 46:
			spots.append(Vector3(float(sx) * rng.randf_range(8.6, 11.4), 0.0, rng.randf_range(8.0, 32.0)))
	# 花坛周围
	for p in [Vector3(-19, 0, 36), Vector3(19, 0, 36), Vector3(-19, 0, -36), Vector3(19, 0, -36)]:
		var pv: Vector3 = p
		for i in 22:
			var a := rng.randf() * TAU
			var rr := rng.randf_range(3.1, 4.3)
			spots.append(Vector3(pv.x + cos(a) * rr, 0.0, pv.z + sin(a) * rr))
	# 广场边缘的带状花坛
	for i in 150:
		var a2 := rng.randf() * TAU
		if absf(cos(a2)) < 0.25:
			continue
		spots.append(Vector3(cos(a2) * rng.randf_range(50.0, 54.0), 0.0, sin(a2) * rng.randf_range(50.0, 54.0)))
	for sp in spots:
		var p2: Vector3 = sp
		var cell := rng.randi_range(1, 3)
		var sz := rng.randf_range(0.75, 1.05)
		var u0 := float(cell) * 0.25
		var u1 := u0 + 0.25
		var yaw := rng.randf() * PI
		for k in 2:
			var ang := yaw + float(k) * PI * 0.5
			var d := Vector3(cos(ang), 0.0, sin(ang)) * sz * 0.5
			b.quad_uv(p2 - d, p2 - d + Vector3(0, sz, 0), p2 + d + Vector3(0, sz, 0), p2 + d, Color.WHITE,
				Vector2(u0, 1), Vector2(u0, 0), Vector2(u1, 0), Vector2(u1, 1))
	var mi := MeshInstance3D.new()
	mi.mesh = b.build()
	mi.material_override = Mats.sprite("flowers")
	add_child(mi)


func _build_clouds() -> void:
	var rng := RandomNumberGenerator.new()
	rng.seed = 99
	for i in 13:
		var mi := MeshInstance3D.new()
		var q := QuadMesh.new()
		var w := rng.randf_range(60.0, 100.0)
		q.size = Vector2(w, w * 0.46)
		mi.mesh = q
		var m := Mats.fx("cloud", true, Color(0.97, 0.97, 0.99))
		m.disable_fog = false
		mi.material_override = m
		mi.position = Vector3(rng.randf_range(-230, 230), rng.randf_range(66, 102), rng.randf_range(-230, 230))
		add_child(mi)
		_clouds.append(mi)
