class_name Tex
extends RefCounted
## 程序化生成的 N64 风格小贴图（32~128px）。
## 场景贴图是"明度图"（近白灰度），由顶点色上色；水果贴图是完整彩色（球面映射）。

static var _c: Dictionary = {}


static func get_tex(tex_name: String) -> ImageTexture:
	if _c.has(tex_name):
		return _c[tex_name]
	var t: ImageTexture
	match tex_name:
		"grass": t = _grass()
		"dirt": t = _dirt()
		"bark": t = _bark()
		"leaves": t = _leaves()
		"rock": t = _rock()
		"metal": t = _metal()
		"tread": t = _tread()
		"concrete": t = _concrete()
		"paving": t = _paving()
		"asphalt": t = _asphalt()
		"marble": t = _marble()
		"rooftile": t = _rooftile()
		"brick": t = _brick()
		"camo": t = _camo()
		"flag": t = _flag()
		"portrait": t = _portrait()
		"banner": t = _banner()
		"apple": t = _apple()
		"cherry": t = _cherry()
		"orange": t = _orange()
		"melon": t = _melon()
		"gold": t = _gold()
		"mine": t = _mine()
		"garlic": t = _garlic()
		"shadow": t = _radial(32, 0.62, 0.15, 0.0, Color(0, 0, 0))
		"puff": t = _radial(32, 0.95, 0.2, 0.2, Color(1, 1, 1))
		"chip": t = _chip()
		"star": t = _star(32, true)
		"star_outline": t = _star(32, false)
		"spark": t = _spark()
		"cloud": t = _cloud()
		"flowers": t = _flowers()
		"splat0": t = _splat(0)
		"splat1": t = _splat(1)
		"splat2": t = _splat(2)
		"splat3": t = _splat(3)
		"mark": t = _mark()
		_:
			t = ImageTexture.create_from_image(_img(4, 4, Color.WHITE))
	_c[tex_name] = t
	return t


# ---------------- 工具 ----------------
static func _img(w: int, h: int, fill: Color = Color(0, 0, 0, 0)) -> Image:
	var im := Image.create(w, h, false, Image.FORMAT_RGBA8)
	im.fill(fill)
	return im


static func _noise(seed_v: int, freq: float, w: int, h: int, octaves: int = 3) -> Image:
	var n := FastNoiseLite.new()
	n.noise_type = FastNoiseLite.TYPE_SIMPLEX_SMOOTH
	n.seed = seed_v
	n.frequency = freq
	n.fractal_octaves = octaves
	return n.get_seamless_image(w, h)


static func _g(v: float, tint: Color = Color(1, 1, 1)) -> Color:
	return Color(clampf(v * tint.r, 0.0, 1.0), clampf(v * tint.g, 0.0, 1.0), clampf(v * tint.b, 0.0, 1.0), 1.0)


static func _tex(im: Image) -> ImageTexture:
	return ImageTexture.create_from_image(im)


static func _rng(s: int) -> RandomNumberGenerator:
	var r := RandomNumberGenerator.new()
	r.seed = s
	return r


# ---------------- 场景贴图（明度图） ----------------
static func _grass() -> ImageTexture:
	var n := _noise(1, 0.05, 64, 64)
	var n2 := _noise(2, 0.2, 64, 64)
	var r := _rng(11)
	var im := _img(64, 64)
	for y in 64:
		for x in 64:
			var v := 0.82 + (n.get_pixel(x, y).r - 0.5) * 0.35 + (n2.get_pixel(x, y).r - 0.5) * 0.18
			if r.randf() < 0.07:
				v -= 0.16
			elif r.randf() < 0.05:
				v += 0.12
			im.set_pixel(x, y, _g(v, Color(0.98, 1.0, 0.96)))
	# 细小草叶笔触
	for i in 70:
		var x := r.randi() % 64
		var y := r.randi() % 64
		for k in 3:
			im.set_pixel(x, (y + k) % 64, _g(0.66 + k * 0.1, Color(0.95, 1.0, 0.9)))
	return _tex(im)


static func _dirt() -> ImageTexture:
	var n := _noise(3, 0.07, 64, 64)
	var r := _rng(12)
	var im := _img(64, 64)
	for y in 64:
		for x in 64:
			var v := 0.84 + (n.get_pixel(x, y).r - 0.5) * 0.32
			if r.randf() < 0.05:
				v -= 0.18
			im.set_pixel(x, y, _g(v, Color(1.0, 0.98, 0.94)))
	for i in 22:
		var cx := r.randi() % 64
		var cy := r.randi() % 64
		var rad := r.randi_range(1, 2)
		for dy in range(-rad, rad + 1):
			for dx in range(-rad, rad + 1):
				if dx * dx + dy * dy <= rad * rad:
					var shade := 0.62 if (dx + dy) > 0 else 0.98
					im.set_pixel((cx + dx + 64) % 64, (cy + dy + 64) % 64, _g(shade))
	return _tex(im)


static func _bark() -> ImageTexture:
	var n := _noise(4, 0.08, 32, 64)
	var im := _img(32, 64)
	for y in 64:
		for x in 32:
			var streak := sin(float(x) * 1.7 + n.get_pixel(x, y).r * 5.0) * 0.5 + 0.5
			im.set_pixel(x, y, _g(0.62 + streak * 0.36))
	return _tex(im)


static func _leaves() -> ImageTexture:
	var n := _noise(5, 0.1, 32, 32)
	var r := _rng(13)
	var im := _img(32, 32)
	for y in 32:
		for x in 32:
			var v := 0.84 + (n.get_pixel(x, y).r - 0.5) * 0.4
			if r.randf() < 0.1:
				v -= 0.22
			elif r.randf() < 0.08:
				v += 0.14
			im.set_pixel(x, y, _g(v))
	# 针叶斜线
	for i in 26:
		var x := r.randi() % 32
		var y := r.randi() % 32
		for k in 3:
			im.set_pixel((x + k) % 32, (y + k) % 32, _g(0.6))
	return _tex(im)


static func _rock() -> ImageTexture:
	var n := _noise(6, 0.06, 64, 64)
	var n2 := _noise(7, 0.12, 64, 64)
	var im := _img(64, 64)
	for y in 64:
		for x in 64:
			var v := 0.84 + (n.get_pixel(x, y).r - 0.5) * 0.4
			var ridge := absf(n2.get_pixel(x, y).r - 0.5)
			if ridge < 0.03:
				v -= 0.32
			im.set_pixel(x, y, _g(v, Color(0.98, 0.98, 1.0)))
	return _tex(im)


static func _metal() -> ImageTexture:
	var n := _noise(8, 0.035, 64, 64)
	var n2 := _noise(9, 0.09, 64, 64)
	var im := _img(64, 64)
	for y in 64:
		for x in 64:
			var camo := n.get_pixel(x, y).r
			var v := 1.0
			if camo < 0.38:
				v = 0.80
			elif camo < 0.52:
				v = 0.91
			v += (n2.get_pixel(x, y).r - 0.5) * 0.08
			if x % 32 == 0 or y % 32 == 0:
				v -= 0.28
			elif x % 32 == 1 or y % 32 == 1:
				v += 0.05
			im.set_pixel(x, y, _g(v))
	# 铆钉
	for px in [6, 26, 38, 58]:
		for py in [6, 26, 38, 58]:
			im.set_pixel(px, py, _g(1.0))
			im.set_pixel(px + 1, py + 1, _g(0.55))
	return _tex(im)


static func _tread() -> ImageTexture:
	var im := _img(32, 32)
	var r := _rng(14)
	for y in 32:
		for x in 32:
			var v := 0.7 if (y % 8) < 5 else 0.42
			v += r.randf_range(-0.05, 0.05)
			im.set_pixel(x, y, _g(v))
	return _tex(im)


static func _concrete() -> ImageTexture:
	var n := _noise(10, 0.1, 32, 32)
	var im := _img(32, 32)
	for y in 32:
		for x in 32:
			im.set_pixel(x, y, _g(0.9 + (n.get_pixel(x, y).r - 0.5) * 0.2))
	return _tex(im)


# ---------------- 广场 / 建筑贴图（明度图） ----------------
## 广场花岗岩方砖
static func _paving() -> ImageTexture:
	var n := _noise(51, 0.09, 64, 64)
	var r := _rng(51)
	var im := _img(64, 64)
	for y in 64:
		for x in 64:
			var sx := x / 16
			var sy := y / 16
			var v := 0.94 + (float((sx * 7 + sy * 13) % 5) - 2.0) * 0.02
			v += (n.get_pixel(x, y).r - 0.5) * 0.12
			if r.randf() < 0.03:
				v -= 0.06
			var gx := x % 16
			var gy := y % 16
			if gx == 0 or gy == 0:
				v -= 0.28
			elif gx == 1 or gy == 1:
				v += 0.06
			im.set_pixel(x, y, _g(v, Color(1.0, 0.995, 0.98)))
	return _tex(im)


## 沥青路面 / 广场外围地面
static func _asphalt() -> ImageTexture:
	var n := _noise(52, 0.28, 64, 64)
	var r := _rng(52)
	var im := _img(64, 64)
	for y in 64:
		for x in 64:
			var v := 0.88 + (n.get_pixel(x, y).r - 0.5) * 0.16
			if r.randf() < 0.05:
				v += 0.1
			elif r.randf() < 0.05:
				v -= 0.12
			im.set_pixel(x, y, _g(v, Color(0.99, 0.99, 1.0)))
	return _tex(im)


## 汉白玉（栏杆、纪念碑、金水桥）
static func _marble() -> ImageTexture:
	var n := _noise(53, 0.05, 64, 64)
	var n2 := _noise(54, 0.14, 64, 64)
	var im := _img(64, 64)
	for y in 64:
		for x in 64:
			var v := 0.97 + (n.get_pixel(x, y).r - 0.5) * 0.07
			var vein := absf(n2.get_pixel(x, y).r - 0.5)
			if vein < 0.04:
				v -= 0.14 * (1.0 - vein / 0.04)
			im.set_pixel(x, y, _g(v, Color(1.0, 0.995, 0.97)))
	return _tex(im)


## 琉璃筒瓦（竖向瓦垄 + 横向瓦当行）
static func _rooftile() -> ImageTexture:
	var im := _img(32, 32)
	var r := _rng(55)
	for y in 32:
		for x in 32:
			var rib := sin(float(x) / 32.0 * TAU * 5.0) * 0.5 + 0.5
			var v := 0.74 + 0.3 * rib
			if y % 8 == 0:
				v -= 0.22
			elif y % 8 == 1:
				v += 0.08
			v += r.randf_range(-0.03, 0.03)
			im.set_pixel(x, y, _g(v, Color(1.0, 0.98, 0.92)))
	return _tex(im)


## 城砖（错缝砌法）
static func _brick() -> ImageTexture:
	var im := _img(64, 64)
	var r := _rng(56)
	for y in 64:
		for x in 64:
			var row := y / 8
			var off := 0 if row % 2 == 0 else 8
			var ax := (x + off) % 64
			var bx := ax % 16
			var by := y % 8
			var v := 0.92 + (float((row * 31 + ax / 16 * 17) % 7) - 3.0) * 0.018
			if by == 0 or bx == 0:
				v -= 0.24
			elif by == 1 or bx == 1:
				v += 0.05
			v += r.randf_range(-0.025, 0.025)
			im.set_pixel(x, y, _g(v, Color(0.99, 1.0, 1.0)))
	return _tex(im)


## 数码迷彩（彩色贴图，2px 色块 + 低频噪声聚簇，可无缝平铺）
static func _camo() -> ImageTexture:
	var a := _noise(61, 0.045, 64, 64, 2)
	var b := _noise(62, 0.11, 64, 64, 2)
	var c := _noise(63, 0.26, 64, 64, 1)
	var cols := [Color("#2d3a1c"), Color("#4a5a2d"), Color("#7e7146"), Color("#55482c")]
	var im := _img(64, 64)
	for sy in 32:
		for sx in 32:
			var px := sx * 2
			var py := sy * 2
			var v := a.get_pixel(px, py).r * 0.62 + b.get_pixel(px, py).r * 0.28 + c.get_pixel(px, py).r * 0.10
			var idx := 0
			if v < 0.40:
				idx = 0
			elif v < 0.52:
				idx = 1
			elif v < 0.63:
				idx = 3
			else:
				idx = 2
			var col: Color = cols[idx]
			for dy in 2:
				for dx in 2:
					im.set_pixel(px + dx, py + dy, col)
	return _tex(im)


# ---------------- 旗帜 / 匾额（彩色） ----------------
static func _star_blit(im: Image, cx: float, cy: float, rad: float, col: Color) -> void:
	var s := int(ceil(rad)) + 1
	for dy in range(-s, s + 1):
		for dx in range(-s, s + 1):
			var d := sqrt(float(dx * dx + dy * dy))
			var th := atan2(float(dx), -float(dy))
			var k := fposmod(th, TAU / 5.0) / (TAU / 5.0)
			var tri := absf(k - 0.5) * 2.0
			if d > rad * (0.42 + 0.58 * tri):
				continue
			var px := int(cx) + dx
			var py := int(cy) + dy
			if px >= 0 and px < im.get_width() and py >= 0 and py < im.get_height():
				im.set_pixel(px, py, col)


static func _flag() -> ImageTexture:
	var im := _img(48, 32, Color("#de2910"))
	var gold := Color("#ffde00")
	_star_blit(im, 9.0, 9.0, 5.2, gold)
	for p in [[17.0, 3.5], [21.0, 7.5], [21.0, 13.0], [17.0, 17.0]]:
		var pp: Array = p
		_star_blit(im, float(pp[0]), float(pp[1]), 2.1, gold)
	return _tex(im)


## 城楼正中的金框画像（风格化剪影，不作写实刻画）
static func _portrait() -> ImageTexture:
	var im := _img(48, 64, Color("#c9a24a"))
	for y in range(3, 61):
		for x in range(3, 45):
			im.set_pixel(x, y, Color("#8a6a22"))
	for y in range(5, 59):
		for x in range(5, 43):
			var t := float(y - 5) / 54.0
			var c := Color("#cfd9e4").lerp(Color("#93a8bd"), t)
			var dx := float(x) - 24.0
			var dy := float(y) - 27.0
			if (dx * dx) / 70.0 + (dy * dy) / 130.0 < 1.0:
				c = Color("#d9c5ab")
			elif y > 37 and absf(dx) < 5.0 + float(y - 37) * 0.95:
				c = Color("#4e5a66")
			im.set_pixel(x, y, c)
	return _tex(im)


## 城楼两侧的红底金字标语牌（抽象字形）
static func _banner() -> ImageTexture:
	var im := _img(64, 16, Color("#c0281c"))
	var gold := Color("#ffd964")
	for x in 64:
		im.set_pixel(x, 0, Color("#e8bf52"))
		im.set_pixel(x, 1, Color("#e8bf52"))
		im.set_pixel(x, 14, Color("#8a1a11"))
		im.set_pixel(x, 15, Color("#8a1a11"))
	for i in 7:
		var ox := 2 + i * 9
		for yy in range(4, 12):
			for xx in range(ox, mini(ox + 6, 64)):
				var lx := xx - ox
				var ly := yy - 4
				if ly == 0 or ly == 3 or ly == 7 or lx == 2 or (ly == 5 and lx > 0 and lx < 5):
					im.set_pixel(xx, yy, gold)
	return _tex(im)


# ---------------- 水果贴图（彩色，64x32 经纬图） ----------------
static func _lon_dist(u: float, c: float) -> float:
	var d := absf(u - c)
	return minf(d, 1.0 - d)


static func _blob_hl(u: float, v: float, cu: float, cv: float, rad: float) -> float:
	var dx := _lon_dist(u, cu) * 64.0
	var dy := (v - cv) * 32.0
	return smoothstep(rad, rad * 0.25, sqrt(dx * dx + dy * dy))


static func _apple() -> ImageTexture:
	var n := _noise(21, 0.12, 64, 32)
	var im := _img(64, 32)
	for y in 32:
		for x in 64:
			var u := float(x) / 64.0
			var v := float(y) / 32.0
			var c := Color("#e8392b")
			c = c.lerp(Color("#a9161f"), clampf(absf(v - 0.5) * 2.0, 0.0, 1.0) * 0.55)
			c = c.lerp(Color("#f58a3c"), n.get_pixel(x, y).r * 0.35)
			c = c.lerp(Color("#fff0e0"), _blob_hl(u, v, 0.3, 0.33, 6.0) * 0.6)
			im.set_pixel(x, y, c)
	return _tex(im)


static func _cherry() -> ImageTexture:
	var im := _img(64, 32)
	for y in 32:
		for x in 64:
			var u := float(x) / 64.0
			var v := float(y) / 32.0
			var c := Color("#c4122e").lerp(Color("#6e0818"), clampf(absf(v - 0.45) * 1.6, 0.0, 1.0) * 0.6)
			c = c.lerp(Color("#ffd8dc"), _blob_hl(u, v, 0.3, 0.33, 5.0) * 0.8)
			im.set_pixel(x, y, c)
	return _tex(im)


static func _orange() -> ImageTexture:
	var n := _noise(22, 0.3, 64, 32)
	var im := _img(64, 32)
	for y in 32:
		for x in 64:
			var u := float(x) / 64.0
			var v := float(y) / 32.0
			var c := Color("#ff9a1c").lerp(Color("#e86a08"), clampf(absf(v - 0.5) * 2.0, 0.0, 1.0) * 0.45)
			if n.get_pixel(x, y).r > 0.66:
				c = c.darkened(0.12)
			c = c.lerp(Color("#fff2c4"), _blob_hl(u, v, 0.3, 0.33, 6.0) * 0.55)
			im.set_pixel(x, y, c)
	return _tex(im)


static func _melon() -> ImageTexture:
	var n := _noise(23, 0.15, 64, 32)
	var im := _img(64, 32)
	for y in 32:
		for x in 64:
			var u := float(x) / 64.0
			var v := float(y) / 32.0
			var wave := sin(v * 18.0 + n.get_pixel(x, y).r * 4.0) * 0.045
			var s := sin((u + wave) * TAU * 6.0)
			var c := Color("#3a9a3e") if s > 0.15 else Color("#a6e06a")
			if s > 0.15:
				c = c.lerp(Color("#1f6a2a"), (n.get_pixel(x, y).r) * 0.5)
			c = c.lerp(Color("#f4ffd8"), _blob_hl(u, v, 0.3, 0.33, 7.0) * 0.45)
			im.set_pixel(x, y, c)
	return _tex(im)


static func _gold() -> ImageTexture:
	var r := _rng(24)
	var im := _img(64, 32)
	for y in 32:
		for x in 64:
			var u := float(x) / 64.0
			var v := float(y) / 32.0
			var c := Color("#ffc800").lerp(Color("#ff9a00"), clampf(absf(v - 0.5) * 2.0, 0.0, 1.0) * 0.6)
			c = c.lerp(Color("#fffbd0"), _blob_hl(u, v, 0.3, 0.33, 8.0) * 0.85)
			if r.randf() < 0.025:
				c = Color("#ffffff")
			im.set_pixel(x, y, c)
	return _tex(im)


static func _mine() -> ImageTexture:
	var im := _img(64, 32)
	for y in 32:
		for x in 64:
			var u := float(x) / 64.0
			var v := float(y) / 32.0
			var c := Color("#33333f").lerp(Color("#1a1a22"), clampf(absf(v - 0.5) * 2.0, 0.0, 1.0) * 0.5)
			if absf(v - 0.5) < 0.1:
				c = Color("#d92d2d") if (x / 4) % 2 == 0 else Color("#ffd51f")
			elif x % 8 == 0 and y % 8 == 4:
				c = Color("#8a8a98")
			c = c.lerp(Color("#bcc0ff"), _blob_hl(u, v, 0.3, 0.3, 5.0) * 0.5)
			im.set_pixel(x, y, c)
	return _tex(im)


## 蒜头：米白纸皮 + 纵向蒜瓣分界 + 顶端偏紫、根部偏黄
## 注意经纬贴图里 v=0 是顶（+Y），v=1 是底
static func _garlic() -> ImageTexture:
	var n := _noise(71, 0.18, 64, 32)
	var n2 := _noise(72, 0.5, 64, 32)
	var im := _img(64, 32)
	for y in 32:
		for x in 64:
			var u := float(x) / 64.0
			var v := float(y) / 32.0
			# 紫皮蒜：广场是浅灰花岗岩，纯白蒜头看不清，用紫红纸皮拉开对比
			var s := absf(sin(u * TAU * 7.0))
			var cleft := clampf(1.0 - s, 0.0, 1.0)
			var c := Color("#f4eee4").lerp(Color("#7c4a78"), cleft * 0.85)
			# 纵向紫色条纹（真实紫皮蒜的纹路）
			var stripe := clampf(sin(u * TAU * 7.0 + 0.6) * 0.5 + 0.5, 0.0, 1.0)
			c = c.lerp(Color("#a85f93"), pow(stripe, 2.5) * 0.55)
			# 纸质纤维
			c = c.lerp(Color("#c9b4c2"), n.get_pixel(x, y).r * 0.3)
			if n2.get_pixel(x, y).r > 0.72:
				c = c.darkened(0.08)
			# 顶端更深的紫、根部的土黄
			c = c.lerp(Color("#6d3f6b"), smoothstep(0.42, 0.0, v) * 0.6)
			c = c.lerp(Color("#d2c296"), smoothstep(0.76, 1.0, v) * 0.5)
			c = c.lerp(Color("#fff8f2"), _blob_hl(u, v, 0.3, 0.36, 6.0) * 0.55)
			im.set_pixel(x, y, c)
	return _tex(im)


# ---------------- 精灵 / 特效贴图 ----------------
static func _radial(s: int, peak: float, inner: float, edge: float, col: Color) -> ImageTexture:
	var im := _img(s, s)
	var c := (s - 1) * 0.5
	for y in s:
		for x in s:
			var d := sqrt((x - c) * (x - c) + (y - c) * (y - c)) / c
			var a := peak * smoothstep(1.0, inner, d)
			a = maxf(a - edge * smoothstep(0.7, 1.0, d), 0.0)
			im.set_pixel(x, y, Color(col.r, col.g, col.b, a))
	return _tex(im)


static func _chip() -> ImageTexture:
	var im := _img(16, 16)
	for y in 16:
		for x in 16:
			var dx := (x - 7.5) / 7.5
			var dy := (y - 7.5) / 7.5
			var d := sqrt(dx * dx + dy * dy)
			if d <= 1.0:
				var shade := 1.0 - 0.35 * d + 0.35 * clampf(1.0 - sqrt((dx + 0.35) * (dx + 0.35) + (dy + 0.35) * (dy + 0.35)) * 1.6, 0.0, 1.0)
				im.set_pixel(x, y, Color(shade, shade, shade, 1.0))
	return _tex(im)


static func _star(s: int, filled: bool) -> ImageTexture:
	var im := _img(s, s)
	var c := (s - 1) * 0.5
	for y in s:
		for x in s:
			var dx := (x - c) / c
			var dy := (y - c) / c
			var r := sqrt(dx * dx + dy * dy)
			var th := atan2(dx, -dy)
			var k := fposmod(th, TAU / 5.0) / (TAU / 5.0)
			var tri := absf(k - 0.5) * 2.0
			var rr := 0.42 + (0.97 - 0.42) * tri
			if r < rr:
				var edge := rr - r < 0.09
				var col := Color(0.08, 0.08, 0.12, 1.0) if edge and not filled else Color(1, 1, 1, 1)
				if filled and edge:
					col = Color(0.85, 0.85, 0.85, 1.0)
				im.set_pixel(x, y, col)
	return _tex(im)


static func _spark() -> ImageTexture:
	var im := _img(32, 32)
	for y in 32:
		for x in 32:
			var dx := absf(x - 15.5) / 15.5
			var dy := absf(y - 15.5) / 15.5
			var a := maxf(1.0 - (dx * 6.0 + dy * 0.7), 0.0) + maxf(1.0 - (dy * 6.0 + dx * 0.7), 0.0)
			a = clampf(a, 0.0, 1.0)
			if a > 0.05:
				im.set_pixel(x, y, Color(1, 1, 1, a))
	return _tex(im)


static func _cloud() -> ImageTexture:
	var im := _img(128, 64)
	var blobs := [[34.0, 40.0, 16.0], [56.0, 30.0, 22.0], [82.0, 34.0, 19.0], [100.0, 42.0, 13.0], [66.0, 44.0, 16.0], [22.0, 46.0, 10.0]]
	for y in 64:
		for x in 128:
			var best := 0.0
			for b in blobs:
				var bb: Array = b
				var d := sqrt((x - float(bb[0])) * (x - float(bb[0])) + (y - float(bb[1])) * (y - float(bb[1]))) / float(bb[2])
				best = maxf(best, 1.0 - d)
			if best > 0.0:
				var a := clampf(best * 2.2, 0.0, 1.0)
				var shade := lerpf(1.0, 0.78, clampf((y - 24.0) / 30.0, 0.0, 1.0))
				im.set_pixel(x, y, Color(shade, shade, minf(1.0, shade + 0.06), a))
	return _tex(im)


static func _flowers() -> ImageTexture:
	var im := _img(128, 32)
	var r := _rng(31)
	# cell 0：草丛
	for i in 9:
		var bx := 4 + i * 3
		var h := r.randi_range(14, 28)
		var lean := r.randf_range(-0.25, 0.25)
		for k in h:
			var x := int(bx + lean * k)
			var y := 31 - k
			if x >= 0 and x < 32:
				var g := 0.55 + 0.45 * float(k) / h
				im.set_pixel(x, y, Color(0.35 * g, 0.85 * g, 0.25 * g, 1.0))
				if x + 1 < 32:
					im.set_pixel(x + 1, y, Color(0.3 * g, 0.75 * g, 0.2 * g, 1.0))
	var cols := [Color("#ff5fa2"), Color("#ffe14d"), Color("#ffffff")]
	for f in 3:
		var ox := 32 * (f + 1)
		for k in 14:
			im.set_pixel(ox + 16, 31 - k, Color(0.25, 0.7, 0.2, 1.0))
			im.set_pixel(ox + 17, 31 - k, Color(0.2, 0.6, 0.18, 1.0))
		for p in 5:
			var a := TAU * p / 5.0 + 0.3
			var px := ox + 16.5 + cos(a) * 5.0
			var py := 11.0 + sin(a) * 5.0
			for dy in range(-3, 4):
				for dx in range(-3, 4):
					if dx * dx + dy * dy <= 9:
						im.set_pixel(int(px) + dx, int(py) + dy, cols[f])
		for dy in range(-2, 3):
			for dx in range(-2, 3):
				if dx * dx + dy * dy <= 4:
					im.set_pixel(ox + 16 + dx, 11 + dy, Color("#ff9a1c") if f != 1 else Color("#d96a00"))
	return _tex(im)


static func _splat(variant: int) -> ImageTexture:
	var s := 64
	var im := _img(s, s)
	var r := _rng(40 + variant)
	var ph1 := r.randf() * TAU
	var ph2 := r.randf() * TAU
	var drops: Array = []
	for i in 5 + variant:
		drops.append([r.randf() * TAU, r.randf_range(0.62, 0.9), r.randf_range(0.05, 0.1)])
	for y in s:
		for x in s:
			var dx := (x - 31.5) / 31.5
			var dy := (y - 31.5) / 31.5
			var d := sqrt(dx * dx + dy * dy)
			var th := atan2(dy, dx)
			var edge := 0.5 + 0.1 * sin(3.0 * th + ph1) + 0.08 * sin(5.0 * th + ph2) + 0.05 * sin(8.0 * th)
			var inside := d < edge
			for dr in drops:
				var dd: Array = dr
				var cx := cos(float(dd[0])) * float(dd[1])
				var cy := sin(float(dd[0])) * float(dd[1])
				if sqrt((dx - cx) * (dx - cx) + (dy - cy) * (dy - cy)) < float(dd[2]):
					inside = true
			if inside:
				var shade := 0.92 - 0.18 * smoothstep(edge * 0.55, edge, d)
				if d > edge - 0.06:
					shade -= 0.1
				im.set_pixel(x, y, Color(shade, shade, shade, 0.95))
	return _tex(im)


static func _mark() -> ImageTexture:
	var im := _img(8, 16)
	for y in 16:
		for x in 8:
			var a := 0.7 if (y % 4) < 3 else 0.35
			if x == 0 or x == 7:
				a *= 0.5
			im.set_pixel(x, y, Color(0.1, 0.07, 0.04, a))
	return _tex(im)


# ---------------- UI 九宫格贴图 ----------------
static func ui_panel_image(fill_top: Color, fill_bottom: Color, rim: Color, radius: float = 14.0) -> ImageTexture:
	return _round_box(48, radius, fill_top, fill_bottom, rim, false)


static func ui_button_image(base: Color) -> ImageTexture:
	return _round_box(48, 16.0, base.lightened(0.28), base.darkened(0.22), base.lightened(0.7), true)


static func _round_box(s: int, rad: float, top: Color, bottom: Color, rim: Color, gloss: bool) -> ImageTexture:
	var im := _img(s, s)
	var half := s * 0.5
	for y in s:
		for x in s:
			var qx := absf(x + 0.5 - half) - (half - rad)
			var qy := absf(y + 0.5 - half) - (half - rad)
			var d := sqrt(maxf(qx, 0.0) * maxf(qx, 0.0) + maxf(qy, 0.0) * maxf(qy, 0.0)) + minf(maxf(qx, qy), 0.0) - rad
			var a := clampf(0.5 - d, 0.0, 1.0)
			if a <= 0.0:
				continue
			var col: Color
			if d > -3.0:
				col = Color(0.04, 0.04, 0.1, 1.0)
			elif d > -5.0:
				col = rim
			else:
				var t := float(y) / s
				col = top.lerp(bottom, t)
				if gloss and t < 0.45:
					col = col.lightened(0.16)
				if gloss and t > 0.45 and t < 0.5:
					col = col.darkened(0.08)
			col.a = a
			im.set_pixel(x, y, col)
	return _tex(im)
