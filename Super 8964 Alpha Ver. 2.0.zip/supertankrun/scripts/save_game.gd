class_name SaveGame
extends RefCounted
## 存档：金币、最高分、已购涂装、升级等级。保存在 user://。

const PATH := "user://supertankrun_save.json"

static var coins: int = 0
static var best: int = 0
static var runs: int = 0
static var total_squashed: int = 0
static var skins_owned: Array = ["olive"]
static var skin: String = "olive"
static var up: Dictionary = {
	"engine": 0, "tread": 0, "weight": 0, "boost": 0, "combo": 0, "time": 0,
	"cannon": 0, "shell": 0, "turret": 0,
}


static func load_game() -> void:
	if not FileAccess.file_exists(PATH):
		return
	var f := FileAccess.open(PATH, FileAccess.READ)
	if f == null:
		return
	var parsed: Variant = JSON.parse_string(f.get_as_text())
	if typeof(parsed) != TYPE_DICTIONARY:
		return
	var d: Dictionary = parsed
	coins = int(d.get("coins", 0))
	best = int(d.get("best", 0))
	runs = int(d.get("runs", 0))
	total_squashed = int(d.get("total_squashed", 0))
	skin = str(d.get("skin", "olive"))
	skins_owned = []
	for s in d.get("skins_owned", ["olive"]):
		skins_owned.append(str(s))
	if not skins_owned.has("olive"):
		skins_owned.append("olive")
	var u: Dictionary = d.get("up", {})
	for k in up.keys():
		up[k] = int(u.get(k, 0))


static func save_game() -> void:
	var f := FileAccess.open(PATH, FileAccess.WRITE)
	if f == null:
		return
	f.store_string(JSON.stringify({
		"coins": coins, "best": best, "runs": runs, "total_squashed": total_squashed,
		"skin": skin, "skins_owned": skins_owned, "up": up,
	}))
