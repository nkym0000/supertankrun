class_name Mats
extends RefCounted
## 材质工厂：lowpoly.gdshader 的各种预设（带缓存）+ 精灵/特效材质。

static var _c: Dictionary = {}
static var _lp_shader: Shader = null
static var _sprite_shader: Shader = null


static func lp(key: String, tex_a: String, mode: int, scale: float = 0.25, tex_b: String = "") -> ShaderMaterial:
	var ck := "lp:" + key
	if _c.has(ck):
		return _c[ck]
	if _lp_shader == null:
		_lp_shader = load("res://shaders/lowpoly.gdshader")
	var m := ShaderMaterial.new()
	m.shader = _lp_shader
	m.set_shader_parameter("tex_mode", mode)
	m.set_shader_parameter("tex_scale", scale)
	if tex_a != "":
		m.set_shader_parameter("tex_a", Tex.get_tex(tex_a))
	m.set_shader_parameter("tex_b", Tex.get_tex(tex_b if tex_b != "" else tex_a))
	_c[ck] = m
	return m


static func sprite(atlas_name: String) -> ShaderMaterial:
	var ck := "sp:" + atlas_name
	if _c.has(ck):
		return _c[ck]
	if _sprite_shader == null:
		_sprite_shader = load("res://shaders/sprite.gdshader")
	var m := ShaderMaterial.new()
	m.shader = _sprite_shader
	m.set_shader_parameter("atlas", Tex.get_tex(atlas_name))
	_c[ck] = m
	return m


## 贴图的半透明 unshaded 材质（阴影、污渍、粒子）。每次调用返回新实例以便单独改颜色。
static func fx(tex_name: String, billboard: bool = false, color: Color = Color.WHITE) -> StandardMaterial3D:
	var m := StandardMaterial3D.new()
	m.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	m.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	m.cull_mode = BaseMaterial3D.CULL_DISABLED
	m.albedo_texture = Tex.get_tex(tex_name)
	m.albedo_color = color
	m.texture_filter = BaseMaterial3D.TEXTURE_FILTER_LINEAR
	if billboard:
		m.billboard_mode = BaseMaterial3D.BILLBOARD_ENABLED
	return m


static func shadow() -> StandardMaterial3D:
	var ck := "shadow"
	if _c.has(ck):
		return _c[ck]
	var m := fx("shadow")
	_c[ck] = m
	return m
